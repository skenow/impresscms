-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Darbinė stotis: localhost
-- Atlikimo laikas:  2007 m. Lapkričio 12 d.  13:42
-- Serverio versija: 5.0.45
-- PHP versija: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Duombazė: `zarilia`
--

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_addons`
--

CREATE TABLE `cztsd_addons` (
  `mid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(150) NOT NULL default '',
  `version` smallint(5) unsigned NOT NULL default '100',
  `last_update` int(10) unsigned NOT NULL default '0',
  `weight` smallint(3) unsigned NOT NULL default '0',
  `isactive` tinyint(1) unsigned NOT NULL default '0',
  `dirname` varchar(25) NOT NULL default '',
  `hasmain` tinyint(1) unsigned NOT NULL default '0',
  `hasadmin` tinyint(1) unsigned NOT NULL default '0',
  `hassearch` tinyint(1) unsigned NOT NULL default '0',
  `hasconfig` tinyint(1) unsigned NOT NULL default '0',
  `hascomments` tinyint(1) unsigned NOT NULL default '0',
  `hasnotification` tinyint(1) unsigned NOT NULL default '0',
  `hasage` tinyint(1) unsigned NOT NULL default '0',
  `hasmimetype` tinyint(1) unsigned NOT NULL default '0',
  `hassubmit` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`mid`),
  KEY `hasmain` (`hasmain`),
  KEY `hasadmin` (`hasadmin`),
  KEY `hassearch` (`hassearch`),
  KEY `hasnotification` (`hasnotification`),
  KEY `dirname` (`dirname`),
  KEY `name` (`name`(15))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_addons`
--

INSERT INTO `cztsd_addons` (`mid`, `name`, `version`, `last_update`, `weight`, `isactive`, `dirname`, `hasmain`, `hasadmin`, `hassearch`, `hasconfig`, `hascomments`, `hasnotification`, `hasage`, `hasmimetype`, `hassubmit`) VALUES
(1, 'System', 1, 1194864177, 0, 1, 'system', 0, 1, 0, 0, 0, 0, 0, 0, 0),
(7, 'News', 1, 1194864201, 1, 1, 'news', 1, 1, 1, 1, 1, 1, 0, 0, 0),
(8, 'cpTools', 0, 1192190406, 1, 1, 'cpTools', 0, 1, 0, 0, 0, 0, 0, 0, 0),
(9, 'Advertisement Manager', 1, 1192190414, 1, 1, 'advertisement', 1, 1, 0, 0, 0, 0, 0, 0, 0),
(10, 'Personal Messaging System', 1, 1192190443, 1, 1, 'messages', 1, 1, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_age`
--

CREATE TABLE `cztsd_age` (
  `age_id` int(5) NOT NULL auto_increment,
  `age_itemid` int(11) NOT NULL default '0',
  `age_uid` int(5) NOT NULL default '0',
  `age_agreed` tinyint(1) NOT NULL default '0',
  `age_date` int(11) NOT NULL default '0',
  `age_gdate` date NOT NULL default '0000-00-00',
  `age_ip` varchar(15) NOT NULL default '',
  `age_mid` int(5) NOT NULL default '0',
  `age_dtitle` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`age_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_age`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_avatar`
--

CREATE TABLE `cztsd_avatar` (
  `avatar_id` mediumint(8) unsigned NOT NULL auto_increment,
  `avatar_file` varchar(30) NOT NULL default '',
  `avatar_name` varchar(100) NOT NULL default '',
  `avatar_mimetype` varchar(30) NOT NULL default '',
  `avatar_created` int(10) NOT NULL default '0',
  `avatar_display` tinyint(1) unsigned NOT NULL default '0',
  `avatar_weight` smallint(5) unsigned NOT NULL default '0',
  `avatar_type` char(1) NOT NULL default '',
  `avatar_uid` mediumint(8) NOT NULL default '0',
  `avatar_usercount` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`avatar_id`),
  KEY `avatar_type` (`avatar_type`,`avatar_display`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_avatar`
--

INSERT INTO `cztsd_avatar` (`avatar_id`, `avatar_file`, `avatar_name`, `avatar_mimetype`, `avatar_created`, `avatar_display`, `avatar_weight`, `avatar_type`, `avatar_uid`, `avatar_usercount`) VALUES
(5, 'cavt4721dd426fa31.jpg', 'MekDrop', 'image/jpeg', 1193401666, 1, 0, 'C', 0, 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_avatar_seq`
--

CREATE TABLE `cztsd_avatar_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_avatar_seq`
--

INSERT INTO `cztsd_avatar_seq` (`id`) VALUES
(5);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_avatar_user_link`
--

CREATE TABLE `cztsd_avatar_user_link` (
  `avatar_id` mediumint(8) unsigned NOT NULL default '0',
  `user_id` mediumint(8) unsigned NOT NULL default '0',
  KEY `avatar_user_id` (`avatar_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_avatar_user_link`
--

INSERT INTO `cztsd_avatar_user_link` (`avatar_id`, `user_id`) VALUES
(5, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_block_addon_link`
--

CREATE TABLE `cztsd_block_addon_link` (
  `block_id` mediumint(8) unsigned NOT NULL default '0',
  `addon_id` smallint(5) NOT NULL default '0',
  KEY `addon_id` (`addon_id`),
  KEY `block_id` (`block_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_block_addon_link`
--

INSERT INTO `cztsd_block_addon_link` (`block_id`, `addon_id`) VALUES
(54, -1),
(52, -1),
(50, -1),
(48, -1),
(46, 0),
(45, -1),
(37, -1),
(40, -1),
(35, -1),
(33, -1),
(43, -1),
(36, -1),
(39, -1),
(44, -1),
(53, -1),
(51, -1),
(49, -1),
(47, -1),
(41, -1),
(38, -1),
(42, 0),
(34, -1),
(55, -1),
(0, -1),
(0, 0),
(0, 7),
(0, 9),
(0, 10),
(43, 0),
(43, 7),
(43, 9),
(43, 10);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_category`
--

CREATE TABLE `cztsd_category` (
  `category_id` mediumint(8) NOT NULL auto_increment,
  `category_pid` mediumint(8) NOT NULL default '0',
  `category_sid` mediumint(3) NOT NULL default '0',
  `category_title` varchar(150) NOT NULL default '',
  `category_description` text NOT NULL,
  `category_image` varchar(150) NOT NULL default '',
  `category_weight` tinyint(1) NOT NULL default '0',
  `category_display` tinyint(1) NOT NULL default '1',
  `category_published` int(11) NOT NULL default '0',
  `category_imageside` varchar(4) NOT NULL default 'left',
  `category_type` varchar(10) NOT NULL default '',
  `category_header` varchar(150) NOT NULL default '',
  `category_footer` varchar(150) NOT NULL default '',
  `category_body` text NOT NULL,
  UNIQUE KEY `category_id` (`category_id`),
  KEY `category_title` (`category_display`,`category_published`,`category_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_category`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_config`
--

CREATE TABLE `cztsd_config` (
  `conf_id` smallint(5) unsigned NOT NULL auto_increment,
  `conf_modid` smallint(5) unsigned NOT NULL default '0',
  `conf_catid` smallint(5) unsigned NOT NULL default '0',
  `conf_sectid` smallint(5) unsigned NOT NULL default '1',
  `conf_name` varchar(25) NOT NULL default '',
  `conf_title` varchar(30) NOT NULL default '',
  `conf_value` text NOT NULL,
  `conf_desc` text NOT NULL,
  `conf_formtype` varchar(15) NOT NULL default '',
  `conf_valuetype` varchar(10) NOT NULL default '',
  `conf_order` smallint(5) unsigned NOT NULL default '0',
  `conf_required` tinyint(2) NOT NULL default '0',
  `conf_source` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`conf_id`),
  KEY `conf_mod_cat_id` (`conf_modid`,`conf_catid`),
  KEY `conf_source` (`conf_source`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25816 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_config`
--

INSERT INTO `cztsd_config` (`conf_id`, `conf_modid`, `conf_catid`, `conf_sectid`, `conf_name`, `conf_title`, `conf_value`, `conf_desc`, `conf_formtype`, `conf_valuetype`, `conf_order`, `conf_required`, `conf_source`) VALUES
(1, 0, 1, 1, 'sitename', '_MD_AM_SITENAME', 'Zarilia', '_MD_AM_SITENAMEDSC', 'textbox', 'text', 0, 0, ''),
(2, 0, 1, 1, 'slogan', '_MD_AM_SLOGAN', '', '_MD_AM_SLOGANDSC', 'textbox', 'text', 2, 0, ''),
(3, 0, 13, 1, 'language', '_MD_AM_LANGUAGE', 'english', '_MD_AM_LANGUAGEDSC', 'language', 'other', 4, 0, ''),
(4, 0, 1, 1, 'startpage', '_MD_AM_STARTPAGE', 'news', '_MD_AM_STARTPAGEDSC', 'startpage', 'other', 6, 0, ''),
(5, 0, 13, 1, 'server_TZ', '_MD_AM_SERVERTZ', '3', '_MD_AM_SERVERTZDSC', 'select', 'float', 8, 0, 'timezone'),
(6, 0, 13, 1, 'default_TZ', '_MD_AM_DEFAULTTZ', '3', '_MD_AM_DEFAULTTZDSC', 'select', 'float', 10, 0, 'timezone'),
(7, 0, 1, 1, 'theme_set', '_MD_AM_DTHEME', 'default', '_MD_AM_DTHEMEDSC', 'theme', 'other', 12, 0, ''),
(8, 0, 1, 1, 'anonymous', '_MD_AM_ANONNAME', 'Anonymous', '_MD_AM_ANONNAMEDSC', 'textbox', 'text', 15, 0, ''),
(9, 0, 15, 1, 'gzip_compression', '_MD_AM_USEGZIP', '0', '_MD_AM_USEGZIPDSC', 'yesno', 'int', 16, 0, ''),
(10, 0, 15, 1, 'usercookie', '_MD_AM_USERCOOKIE', '', '_MD_AM_USERCOOKIEDSC', 'textbox', 'text', 18, 0, ''),
(11, 0, 15, 1, 'session_expire', '_MD_AM_SESSEXPIRE', '15', '_MD_AM_SESSEXPIREDSC', 'textbox', 'int', 22, 0, ''),
(13, 0, 15, 1, 'debug_mode', '_MD_AM_DEBUGMODE', 'a:1:{i:0;s:1:"0";}', '_MD_AM_DEBUGMODEDSC', 'select_multi', 'array', 0, 0, 'debug.modes'),
(14, 0, 15, 1, 'my_ip', '_MD_AM_MYIP', '127.0.0.1', '_MD_AM_MYIPDSC', 'textbox', 'text', 29, 0, ''),
(15, 0, 15, 1, 'use_ssl', '_MD_AM_USESSL', '0', '_MD_AM_USESSLDSC', 'yesno', 'int', 30, 0, ''),
(16, 0, 15, 1, 'session_name', '_MD_AM_SESSNAME', 'zarilia_session', '_MD_AM_SESSNAMEDSC', 'textbox', 'text', 20, 0, ''),
(17, 0, 2, 1, 'minpass', '_MD_AM_MINPASS', '5', '_MD_AM_MINPASSDSC', 'textbox', 'int', 2, 0, ''),
(18, 0, 2, 1, 'minuname', '_MD_AM_MINUNAME', '3', '_MD_AM_MINUNAMEDSC', 'textbox', 'int', 2, 0, ''),
(19, 0, 2, 1, 'new_user_notify', '_MD_AM_NEWUNOTIFY', '1', '_MD_AM_NEWUNOTIFYDSC', 'yesno', 'int', 4, 0, ''),
(20, 0, 2, 1, 'new_user_notify_group', '_MD_AM_NOTIFYTO', '1', '_MD_AM_NOTIFYTODSC', 'group', 'int', 6, 0, ''),
(21, 0, 2, 1, 'activation_type', '_MD_AM_ACTVTYPE', '0', '_MD_AM_ACTVTYPEDSC', 'select', 'int', 8, 0, ''),
(22, 0, 2, 1, 'activation_group', '_MD_AM_ACTVGROUP', '1', '_MD_AM_ACTVGROUPDSC', 'group', 'int', 10, 0, ''),
(23, 0, 2, 1, 'uname_test_level', '_MD_AM_UNAMELVL', '0', '_MD_AM_UNAMELVLDSC', 'select', 'int', 12, 0, ''),
(24, 0, 2, 1, 'avatar_allow_upload', '_MD_AM_AVATARALLOW', '1', '_MD_AM_AVATARALWDSC', 'yesno', 'int', 14, 0, ''),
(27, 0, 2, 1, 'avatar_width', '_MD_AM_AVATARW', '80', '_MD_AM_AVATARWDSC', 'textbox', 'int', 16, 0, ''),
(28, 0, 2, 1, 'avatar_height', '_MD_AM_AVATARH', '80', '_MD_AM_AVATARHDSC', 'textbox', 'int', 18, 0, ''),
(29, 0, 2, 1, 'avatar_maxsize', '_MD_AM_AVATARMAX', '35000', '_MD_AM_AVATARMAXDSC', 'textbox', 'int', 20, 0, ''),
(30, 0, 1, 1, 'adminmail', '_MD_AM_ADMINML', 'admin@this.site', '_MD_AM_ADMINMLDSC', 'textbox', 'text', 3, 0, ''),
(31, 0, 2, 1, 'self_delete', '_MD_AM_SELFDELETE', '1', '_MD_AM_SELFDELETEDSC', 'yesno', 'int', 22, 0, ''),
(32, 0, 1, 1, 'com_mode', '_MD_AM_COMMODE', 'flat', '_MD_AM_COMMODEDSC', 'select', 'text', 34, 0, 'comments.display'),
(33, 0, 1, 1, 'com_order', '_MD_AM_COMORDER', '0', '_MD_AM_COMORDERDSC', 'select', 'int', 36, 0, ''),
(34, 0, 2, 1, 'bad_unames', '_MD_AM_BADUNAMES', 'a:3:{i:0;s:9:"webmaster";i:1;s:14:"^administrator";i:2;s:6:"^admin";}', '_MD_AM_BADUNAMESDSC', 'multitext', 'array', 24, 0, ''),
(35, 0, 2, 1, 'bad_emails', '_MD_AM_BADEMAILS', 'a:2:{i:0;s:15:"yourwebsite.com";i:1;s:11:"zarilia.com";}', '_MD_AM_BADEMAILSDSC', 'multitext', 'array', 26, 0, ''),
(36, 0, 2, 1, 'maxuname', '_MD_AM_MAXUNAME', '25', '_MD_AM_MAXUNAMEDSC', 'textbox', 'int', 3, 0, ''),
(37, 0, 1, 1, 'bad_ips', '_MD_AM_BADIPS', 'a:1:{i:0;s:9:"localhost";}', '_MD_AM_BADIPSDSC', 'multitext', 'array', 42, 0, ''),
(38, 0, 3, 1, 'meta_keywords', '_MD_AM_METAKEY', 'Zarilia, zarilia', '_MD_AM_METAKEYDSC', 'textarea', 'text', 0, 0, ''),
(39, 0, 3, 1, 'meta_footer', '_MD_AM_FOOTER', 'Powered by Zarilia Beta V1.0 CMS', '_MD_AM_FOOTERDSC', 'textarea', 'text', 20, 0, ''),
(40, 0, 4, 1, 'censor_enable', '_MD_AM_DOCENSOR', '0', '_MD_AM_DOCENSORDSC', 'yesno', 'int', 0, 0, ''),
(41, 0, 4, 1, 'censor_words', '_MD_AM_CENSORWRD', 'a:1:{i:0;s:4:"shit";}', '_MD_AM_CENSORWRDDSC', 'multitext', 'array', 1, 0, ''),
(42, 0, 4, 1, 'censor_replace', '_MD_AM_CENSORRPLC', '#OOPS#', '_MD_AM_CENSORRPLCDSC', 'textbox', 'text', 2, 0, ''),
(43, 0, 3, 1, 'meta_robots', '_MD_AM_METAROBOTS', 'index,follow', '_MD_AM_METAROBOTSDSC', 'select', 'text', 2, 0, ''),
(44, 0, 5, 1, 'enable_search', '_MD_AM_DOSEARCH', '1', '_MD_AM_DOSEARCHDSC', 'yesno', 'int', 0, 0, ''),
(45, 0, 5, 1, 'keyword_min', '_MD_AM_MINSEARCH', '5', '_MD_AM_MINSEARCHDSC', 'textbox', 'int', 1, 0, ''),
(46, 0, 2, 1, 'avatar_minposts', '_MD_AM_AVATARMP', '0', '_MD_AM_AVATARMPDSC', 'textbox', 'int', 15, 0, ''),
(47, 0, 1, 1, 'enable_badips', '_MD_AM_DOBADIPS', '0', '_MD_AM_DOBADIPSDSC', 'yesno', 'int', 40, 0, ''),
(48, 0, 3, 1, 'meta_rating', '_MD_AM_METARATING', 'general', '_MD_AM_METARATINGDSC', 'select', 'text', 4, 0, ''),
(49, 0, 3, 1, 'meta_author', '_MD_AM_METAAUTHOR', 'Zarilia', '_MD_AM_METAAUTHORDSC', 'textbox', 'text', 6, 0, ''),
(50, 0, 3, 1, 'meta_copyright', '_MD_AM_METACOPYR', 'Copyright ?????? 2007', '_MD_AM_METACOPYRDSC', 'textbox', 'text', 8, 0, ''),
(51, 0, 3, 1, 'meta_description', '_MD_AM_METADESC', 'Zarilia - Dynamic Object Oriented content Management System and Web Application Framework', '_MD_AM_METADESCDSC', 'textarea', 'text', 1, 0, ''),
(52, 0, 2, 1, 'allow_chgmail', '_MD_AM_ALLWCHGMAIL', '0', '_MD_AM_ALLWCHGMAILDSC', 'yesno', 'int', 3, 0, ''),
(53, 0, 15, 1, 'use_mysession', '_MD_AM_USEMYSESS', '0', '_MD_AM_USEMYSESSDSC', 'yesno', 'int', 19, 0, ''),
(54, 0, 2, 1, 'reg_dispdsclmr', '_MD_AM_DSPDSCLMR', '1', '_MD_AM_DSPDSCLMRDSC', 'yesno', 'int', 30, 0, ''),
(55, 0, 2, 1, 'reg_disclaimer', '_MD_AM_REGDSCLMR', '<div class="info">     Visi žemiau i??vardinti punktai - tai tinklalapio taisykl?s. Nor?dami užsiregistruoti turite su jomis sutikti. O jeigu sutikus ateityje, kuri? nors taisykl? pažeisite, gali sulaukti bausm?s. <br /><br /><strong>Terminai</strong><ol><li>Lankytojas - asmuo, užsuk?s ? tinklalap?.</li><li>Registruotas vartotojas - vartotojas, kuris užsiregistravo ??iame tinklalapyje.</li><li>Vartotoj? grup? - tai registruotot? vartotoj? grup? turinti tam tikras teises.</li><li>Administracija - žmoni? priži?rin??i? ??i? svetain? komanda.</li><li>Skycommunity.lt projektas - projektas, kuris yra globojamas SkyCommunity.lt kolektyvo.</li></ol><strong>Registruot? vartotoj? teis?s bei ?sipareigojimai:</strong><ol><li>Kiekvienas tinklalapio lankytojas gali b?ti registruotu jo vartotoju.</li><li>Kiekvienas registruotas vartotojas gali priklausyti kuri? nors i?? tinklalapyje esan??i? vartotoj? grupi?.</li><li>Registruotas vartotojas turi teis? naudotis papildomomis svetain?s galimyb?mis (pvz. komentavimu).</li><li>Registruotas vartotojas už prasižengimus gali prarasti galimyb? naudotis papildomomis tinklalapio paslaugomis.</li></ol><strong>Administracijos teis?s ir ?pareigojimai:</strong><ol><li>Trinti komentarus, ar kit? vartotoj? sukurt? svetain?s turin?, kuris pažeidžia taisykles.</li><li>Redaguoti komentarus, kurie dalinai pažeidžia turin?.</li><li>Bausti registruotus vartotojus, už j? prasižengimus.</li><li>Bet kada keisti tinklalapio taisykles apie tai prie?? tai paskelbus vie??ai.</li><li>Administracija neprisiima jokios teisin?s atsakomyb?s už vartotoj? turin?, kuris pažeidin?ja ?statymus.</li></ol><strong>Draudžiama:</strong><ol><li>Keiktis.</li><li>Kitus ?žeidin?ti, ty??iotis, kurstyti neapykant?.</li><li>Skelbti tiesiogines nuorodas ? piratin? intelektualin? produkcij?.</li><li>Ra??yti internetini? žaidim? adresus, kuriuos nuspaud? kiti vartotojai uždirbt? nuorodos savininkui ta??k? žaidime.</li><li>Floodinti (pvz. ra??yti visi??kai ne ? tem? atsakymus/komentarus).</li><li>Reklamuoti svetaines, produktus, be svetain?s administracijos žinios.</li><li>Skelbti klaiding? informacij?.</li><li>Bet k?, kas pažeidžia LR ?statymus.</li></ol><strong>SkyCommunity.lt projektai:</strong><br /></div><ol><li>SkyCommunity.lt komanda neprisiima pilnos atsakomyb?s už j? turin?.</li><li>Kiekvienas projektas j? savininkams pageidaujant, bei neprie??taraujant nei vienam i?? esam? SkyCommunity.lt komandos nari?, gali tapti nauju SkyCommunity.lt projektu.</li><li>Kiekvienas??SkyCommunity.lt projektas gali tur?ti papildom? taisykli?, kuri? taip pat reikia laikytis. </li><li>Visos ??ia i??vardintos taisykl?s galioja ir SkyCommunity.lt projektams.</ol>', '_MD_AM_REGDSCLMRDSC', 'htmltextarea', 'text', 32, 0, ''),
(56, 0, 2, 1, 'allow_register', '_MD_AM_ALLOWREG', '1', '_MD_AM_ALLOWREGDSC', 'yesno', 'int', 0, 0, ''),
(57, 0, 1, 1, 'theme_fromfile', '_MD_AM_THEMEFILE', '1', '_MD_AM_THEMEFILEDSC', 'yesno', 'int', 13, 0, ''),
(58, 0, 1, 1, 'closesite', '_MD_AM_CLOSESITE', '0', '_MD_AM_CLOSESITEDSC', 'yesno', 'int', 26, 0, ''),
(59, 0, 1, 1, 'closesite_okgrp', '_MD_AM_CLOSESITEOK', 'a:1:{i:0;s:1:"1";}', '_MD_AM_CLOSESITEOKDSC', 'group_multi', 'array', 27, 0, ''),
(60, 0, 1, 1, 'closesite_text', '_MD_AM_CLOSESITETXT', 'The site is currently closed for maintainance. Please come back later.', '_MD_AM_CLOSESITETXTDSC', 'textarea', 'text', 28, 0, ''),
(61, 0, 15, 1, 'sslpost_name', '_MD_AM_SSLPOST', 'zarilia_ssl', '_MD_AM_SSLPOSTDSC', 'textbox', 'text', 31, 0, ''),
(62, 0, 1, 1, 'addon_cache', '_MD_AM_MODCACHE', 'a:3:{i:7;s:1:"0";i:9;s:1:"0";i:10;s:1:"0";}', '_MD_AM_MODCACHEDSC', 'addon_cache', 'array', 50, 0, ''),
(24049, 0, 1, 1, 'gatherstats', '_MD_AM_GATHERSTATS', '0', '_MD_AM_GATHERSTATS_DSC', 'yesno', 'int', 10, 0, ''),
(63, 0, 1, 1, 'template_set', '_MD_AM_DTPLSET', 'default', '_MD_AM_DTPLSETDSC', 'tplset', 'other', 14, 0, ''),
(64, 0, 6, 1, 'mailmethod', '_MD_AM_MAILERMETHOD', 'mail', '_MD_AM_MAILERMETHODDESC', 'select', 'text', 4, 0, ''),
(65, 0, 6, 1, 'smtphost', '_MD_AM_SMTPHOST', 'a:1:{i:0;s:0:"";}', '_MD_AM_SMTPHOSTDESC', 'multitext', 'array', 6, 0, ''),
(66, 0, 6, 1, 'smtpuser', '_MD_AM_SMTPUSER', '', '_MD_AM_SMTPUSERDESC', 'textbox', 'text', 7, 0, ''),
(67, 0, 6, 1, 'smtppass', '_MD_AM_SMTPPASS', '', '_MD_AM_SMTPPASSDESC', 'password', 'text', 8, 0, ''),
(68, 0, 6, 1, 'sendmailpath', '_MD_AM_SENDMAILPATH', '/usr/sbin/sendmail', '_MD_AM_SENDMAILPATHDESC', 'textbox', 'text', 5, 0, ''),
(69, 0, 6, 1, 'from', '_MD_AM_MAILFROM', '', '_MD_AM_MAILFROMDESC', 'textbox', 'text', 1, 0, ''),
(70, 0, 6, 1, 'fromname', '_MD_AM_MAILFROMNAME', '', '_MD_AM_MAILFROMNAMEDESC', 'textbox', 'text', 2, 0, ''),
(71, 0, 15, 1, 'sslloginlink', '_MD_AM_SSLLINK', 'https://', '_MD_AM_SSLLINKDSC', 'textbox', 'text', 33, 0, ''),
(72, 0, 1, 1, 'theme_set_allowed', '_MD_AM_THEMEOK', 'a:0:{}', '_MD_AM_THEMEOKDSC', 'theme_multi', 'array', 13, 0, ''),
(73, 0, 6, 1, 'fromuid', '_MD_AM_MAILFROMUID', '1', '_MD_AM_MAILFROMUIDDESC', 'user', 'int', 3, 0, ''),
(25592, 0, 2, 1, 'showimagetype', '_MD_AM_SHOWIMAGETYPE', '3', '_MD_AM__SHOWIMAGETYPE', 'select', 'int', 101, 0, ''),
(22790, 0, 2, 1, 'user_restrict', '_MD_AM_USER_RESTRICT', '0', '_MD_AM_USER_RESTRICTDSC', 'yesno', 'int', 1, 0, ''),
(22791, 0, 2, 1, 'duplicate_login', '_MD_AM_USER_LRESTRICT', '0', '_MD_AM_USER_LRESTRICTDSC', 'yesno', 'int', 2, 0, ''),
(22792, 0, 11, 1, 'actual_age', '_MD_AM_COPPAAGE', '13', '_MD_AM_COPPAAGE_DSC', 'textbox', 'int', 1, 0, ''),
(22793, 0, 11, 1, 'coppa_directtext', '_MD_AM_COPPA_DIRECTTEXT', '<p>				:)			</p>', '_MD_AM_COPPA_DIRECTTEXT_DSC', 'htmltextarea', 'text', 103, 0, ''),
(20404, 0, 15, 1, 'debug_mode_okgrp', '_MD_AM_DEBUGMODEOK', 'a:1:{i:0;s:1:"1";}', '_MD_AM_DEBUGMODEOKDSC', 'group_multi', 'array', 2, 0, ''),
(20403, 0, 15, 1, 'debug_level', '_MD_AM_DEBUGLEVEL', '6143', '_MD_AM_DEBUGLEVELDSC', 'select', 'text', 1, 0, ''),
(20405, 0, 13, 1, 'timestamp', '_MD_AM_TIME', 'm/d/Y H:i', '_MD_AM_TIMEDESC', 'textbox', 'text', 11, 0, ''),
(22784, 0, 11, 1, 'show_coppa', '_MD_AM_COPPA_REGISTER', '0', '_MD_AM_COPPA_REGISTER_DSC', 'yesno', 'int', 0, 0, ''),
(22785, 0, 11, 1, 'coppa_email', '_MD_AM_COPPA_EMAIL', '', '_MD_AM_COPPA_EMAIL_DSC', 'textbox', 'textbox', 1, 0, ''),
(22786, 0, 11, 1, 'coppa_fax', '_MD_AM_COPPA_FAX', '', '_MD_AM_COPPA_FAX_DSC', 'textbox', 'textbox', 2, 0, ''),
(22787, 0, 11, 1, 'coppa_text', '_MD_AM_COPPA_TEXT', '<p>				_MD_AM_COPPA_FAX_DSC			</p>', '_MD_AM_COPPA_TEXT_DSC', 'htmltextarea', 'text', 3, 0, ''),
(22839, 0, 8, 1, 'img_prefix', '_MD_AM_IMGPREFIX', 'img', '_MD_AM_IMGPREFIX_DSC', 'textbox', 'text', 0, 0, ''),
(22840, 0, 2, 1, 'use_img_ver', '_MD_AM_IMGVER', '0', '_MD_AM_IMGVER_DSC', 'yesno', 'int', 99, 0, ''),
(23226, 0, 14, 1, 'ldap_uid_attr', '_MD_AM_LDAP_UID_ATTR', 'uid', '_MD_AM_LDAP_UID_ATTR_DESC', 'textbox', 'text', 60, 0, ''),
(23225, 0, 14, 1, 'ldap_base_dn', '_MD_AM_LDAP_BASE_DN', 'ou=Employees,o=Company', '_MD_AM_LDAP_BASE_DN_DESC', 'textbox', 'text', 59, 0, ''),
(23224, 0, 14, 1, 'ldap_server', '_MD_AM_LDAP_SERVER', 'your directory server', '_MD_AM_LDAP_SERVER_DESC', 'textbox', 'text', 58, 0, ''),
(23223, 0, 14, 1, 'ldap_port', '_MD_AM_LDAP_PORT', '389', '_MD_AM_LDAP_PORT', 'textbox', 'int', 57, 0, ''),
(23222, 0, 14, 1, 'ldap_givenname_attr', '_MD_AM_LDAP_GIVENNAME_ATTR', 'givenname', '_MD_AM_LDAP_GIVENNAME_ATTR_DSC', 'textbox', 'text', 56, 0, ''),
(23221, 0, 14, 1, 'ldap_surname_attr', '_MD_AM_LDAP_SURNAME_ATTR', 'sn', '_MD_AM_LDAP_SURNAME_ATTR_DESC', 'textbox', 'text', 55, 0, ''),
(23220, 0, 14, 1, 'ldap_name_attr', '_MD_AM_LDAP_NAME_ATTR', 'cn', '_MD_AM_LDAP_NAME_ATTR_DESC', 'textbox', 'text', 54, 0, ''),
(23219, 0, 14, 1, 'ldap_mail_attr', '_MD_AM_LDAP_MAIL_ATTR', 'mail', '_MD_AM_LDAP_MAIL_ATTR_DESC', 'textbox', 'text', 53, 0, ''),
(23218, 0, 14, 1, 'auth_method', '_MD_AM_AUTHMETHOD', 'zarilia', '_MD_AM_AUTHMETHODDESC', 'select', 'text', 52, 0, ''),
(23227, 0, 14, 1, 'ldap_uid_asdn', '_MD_AM_LDAP_UID_ASDN', '0', '_MD_AM_LDAP_UID_ASDN_DESC', 'yesno', 'int', 61, 0, ''),
(23228, 0, 14, 1, 'ldap_manager_dn', '_MD_AM_LDAP_MANAGER_DN', 'manager_dn', '_MD_AM_LDAP_MANAGER_DN_DESC', 'textbox', 'text', 62, 0, ''),
(23229, 0, 14, 1, 'ldap_manager_pass', '_MD_AM_LDAP_MANAGER_PASS', 'manager_pass', '_MD_AM_LDAP_MANAGER_PASS_DESC', 'textbox', 'text', 63, 0, ''),
(23230, 0, 14, 1, 'ldap_version', '_MD_AM_LDAP_VERSION', '3', '_MD_AM_LDAP_VERSION_DESC', 'textbox', 'text', 64, 0, ''),
(23974, 0, 1, 1, 'quickredirect', '_MD_AM_QUICKREDIRECT', '0', '_MD_AM_QUICKREDIRECTDSC', 'yesno', 'int', 99, 0, ''),
(23975, 0, 1, 1, 'useshorturls', '_MD_AM_SHORTURL', '0', '_MD_AM_SHORTURLDSC', 'yesno', 'int', 100, 0, ''),
(24086, 0, 1, 1, 'admin_default', '_MD_AM_AEDITOR', 'textarea', '_MD_AM_AEDITORDSC', 'editor', 'text', 110, 0, ''),
(24088, 0, 1, 1, 'user_default', '_MD_AM_UEDITOR', 'textarea', '_MD_AM_UEDITORDSC', 'editor', 'text', 112, 0, ''),
(24087, 0, 1, 1, 'user_select', '_MD_AM_UCHOICE', 'a:1:{i:0;s:8:"textarea";}', '_MD_AM_UCHOICEDSC', 'editor_multi', 'array', 111, 0, ''),
(24089, 0, 1, 1, 'rows', '_MD_AM_DEFAULTROWS', '15', '_MD_AM_DEFAULTROWSDSC', 'textbox', 'int', 113, 0, ''),
(24090, 0, 1, 1, 'cols', '_MD_AM_DEFAULTCOLS', '75', '_MD_AM_DEFAULTCOLSDSC', 'textbox', 'int', 114, 0, ''),
(24091, 0, 1, 1, 'width', '_MD_AM_DEFAULTWIDTH', '200', '_MD_AM_DEFAULTWIDTHDSC', 'textbox', 'text', 115, 0, ''),
(24092, 0, 1, 1, 'height', '_MD_AM_DEFAULTHEIGHT', '100', '_MD_AM_DEFAULTHEIGHTDSC', 'textbox', 'text', 116, 0, ''),
(24093, 0, 13, 1, 'charset', '_MD_AM_CHARSET', 'utf-8', '_MD_AM_CHARSETDSC', 'select', 'textbox', 0, 0, ''),
(24094, 0, 13, 1, 'multibyte', '_MD_AM_MULTIBYTE', '1', '_MD_AM_MULTIBYTEDSC', 'yesno', 'int', 2, 0, ''),
(24095, 0, 3, 1, 'metalang', '_MD_AM_LANGUAGE', 'english', '_MD_AM_LANGUAGEDSC', 'language', 'text', 0, 0, ''),
(24134, 0, 7, 1, 'allow_pm', '_MD_AM_ALLOWPM', '0', '_MD_AM_ALLOWPMDSC', 'yesno', 'int', 0, 0, ''),
(24197, 0, 7, 1, 'message_okgrp', '_MD_AM_MESSAGE_GROUP', 'a:5:{i:0;s:1:"1";i:1;s:1:"2";i:2;s:1:"4";i:3;s:1:"5";i:4;s:1:"6";}', '_MD_AM_MESSAGE_DSC', 'group_multi', 'array', 4, 0, ''),
(75, 0, 16, 1, 'events_enable', '_MD_AM_EVENTSENABLE', '1', '_MD_AM_EVENTSENABLE_DESC', 'yesno', 'int', 0, 1, ''),
(24214, 0, 16, 1, 'events_system', '_MD_AM_EVENTSSYSTEM', 'internal', '_MD_AM_EVENTSSYSTEM_DESC', 'select', 'text', 0, 1, ''),
(24215, 0, 16, 1, 'events_helper', '_MD_AM_EVENTSHELPER', '', '_MD_AM_EVENTSHELPER_DESC', 'text', 'text', 0, 1, ''),
(24216, 0, 16, 1, 'events_helper_arguments', '_MD_AM_EVENTSHCMD', '', '_MD_AM_EVENTSHCMD_DESC', '', '', 0, 0, ''),
(25591, 0, 2, 1, 'showimagever', '_MD_AM_SHOWIMAGEVER', '0', '_MD_AM_SHOWIMAGEVERDSC', 'yesno', 'int', 100, 0, ''),
(25593, 0, 2, 1, 'pass_level', '_MD_AM_PASSLEVEL', '60', '_MD_AM_PASSLEVEL_DESC', 'select', 'int', 1, 0, ''),
(25594, 0, 15, 1, 'gzip_compression_level', '_MD_AM_COMPRESSIONLVL', 'a:1:{i:0;s:1:"0";}', '_MD_AM_COMPRESSIONLVL_DESC', 'select_multi', 'array', 17, 0, ''),
(25705, 20, 0, 0, 'notification_enabled', '_NOT_CONFIG_ENABLE', '3', '_NOT_CONFIG_ENABLEDSC', 'select', 'int', 0, 0, ''),
(25706, 20, 0, 0, 'notification_events', '_NOT_CONFIG_EVENTS', 'a:8:{i:0;s:15:"thread-new_post";i:1;s:15:"thread-bookmark";i:2;s:16:"forum-new_thread";i:3;s:14:"forum-new_post";i:4;s:14:"forum-bookmark";i:5;s:16:"global-new_forum";i:6;s:15:"global-new_post";i:7;s:19:"global-new_fullpost";}', '_NOT_CONFIG_EVENTSDSC', 'select_multi', 'array', 1, 0, ''),
(25810, 7, 0, 0, 'mimetypes', '_MI_NEWS_MIME_TYPES', 'image/gif\r\nimage/jpeg\r\nimage/pjpeg\r\nimage/x-png\r\nimage/png\r\napplication/x-zip-compressed\r\napplication/zip\r\napplication/pdf\r\napplication/x-gtar\r\napplication/x-tar', '', 'textarea', 'text', 29, 0, ''),
(25809, 7, 0, 0, 'advertisement', '_MI_NEWS_ADVERTISEMENT', '', '_MI_NEWS_ADV_DESCR', 'textarea', 'text', 28, 0, ''),
(25808, 7, 0, 0, 'firefox_microsummaries', '_MI_NEWS_FF_MICROFORMAT', '0', '_MI_NEWS_FF_MICROFORMAT_DSC', 'yesno', 'int', 27, 0, ''),
(25807, 7, 0, 0, 'bookmarkme', '_MI_NEWS_BOOKMARK_ME', '0', '_MI_NEWS_BOOKMARK_ME_DSC', 'yesno', 'int', 26, 0, ''),
(25806, 7, 0, 0, 'dublincore', '_MI_NEWS_DUBLINCORE', '0', '_MI_NEWS_DUBLINCORE_DSC', 'yesno', 'int', 25, 0, ''),
(25805, 7, 0, 0, 'footNoteLinks', '_MI_NEWS_FOOTNOTES', '1', '', 'yesno', 'int', 24, 0, ''),
(25804, 7, 0, 0, 'tabskin', '_MI_NEWS_TABS_SKIN', '3', '_MI_NEWS_TABS_SKIN_DESC', 'select', 'int', 23, 0, ''),
(25803, 7, 0, 0, 'sitenavbar', '_MI_NEWS_SITE_NAVBAR', '0', '_MI_NEWS_SITE_NAVBAR_DESC', 'yesno', 'int', 22, 0, ''),
(25802, 7, 0, 0, 'infotips', '_MI_NEWS_INFOTIPS', '0', '_MI_NEWS_INFOTIPS_DES', 'textbox', 'int', 21, 0, ''),
(25801, 7, 0, 0, 'highlightcolor', '_MI_NEWS_HIGH_COLOR', '#FFFF80', '_MI_NEWS_HIGH_COLOR_DES', 'textbox', 'text', 20, 0, ''),
(25800, 7, 0, 0, 'keywordshighlight', '_MI_NEWS_KEYWORDS_HIGH', '0', '_MI_NEWS_KEYWORDS_HIGH_DESC', 'yesno', 'int', 19, 0, ''),
(25799, 7, 0, 0, 'form_options', '_MI_NEWS_FORM_OPTIONS', 'dhtml', '_MI_NEWS_FORM_OPTIONS_DESC', 'select', 'text', 18, 0, ''),
(25798, 7, 0, 0, 'metadata', '_MI_NEWS_META_DATA', '0', '_MI_NEWS_META_DATA_DESC', 'yesno', 'int', 17, 0, ''),
(25797, 7, 0, 0, 'topicsrss', '_MI_NEWS_TOPICS_RSS', '0', '_MI_NEWS_TOPICS_RSS_DESC', 'yesno', 'int', 16, 0, ''),
(25796, 7, 0, 0, 'ratenews', '_MI_NEWS_RATE_NEWS', '0', '', 'yesno', 'int', 15, 0, ''),
(25795, 7, 0, 0, 'authoredit', '_MI_NEWS_AUTHOR_EDIT', '1', '_MI_NEWS_AUTHOR_EDIT_DESC', 'yesno', 'int', 14, 0, ''),
(25794, 7, 0, 0, 'showsummarytable', '_MI_NEWS_SUMMARY_SHOW', '0', '_MI_NEWS_SUMMARY_SHOW_DESC', 'yesno', 'int', 13, 0, ''),
(25793, 7, 0, 0, 'showprevnextlink', '_MI_NEWS_PREVNEX_LINK', '0', '_MI_NEWS_PREVNEX_LINK_DESC', 'yesno', 'int', 12, 0, ''),
(25792, 7, 0, 0, 'newsbythisauthor', '_MI_NEWSBYTHISAUTHOR', '0', '_MI_NEWSBYTHISAUTHORDSC', 'yesno', 'int', 11, 0, ''),
(25791, 7, 0, 0, 'restrictindex', '_MI_RESTRICTINDEX', '0', '_MI_RESTRICTINDEXDSC', 'yesno', 'int', 10, 0, ''),
(25790, 7, 0, 0, 'maxuploadsize', '_MI_UPLOADFILESIZE', '1048576', '_MI_UPLOADFILESIZE_DESC', 'textbox', 'int', 9, 0, ''),
(25789, 7, 0, 0, 'uploadgroups', '_MI_UPLOADGROUPS', '2', '_MI_UPLOADGROUPS_DESC', 'select', 'int', 8, 0, ''),
(25788, 7, 0, 0, 'storycountadmin', '_MI_STORYCOUNTADMIN', '10', '_MI_STORYCOUNTADMIN_DESC', 'select', 'int', 7, 0, ''),
(25787, 7, 0, 0, 'columnmode', '_MI_COLUMNMODE', '1', '_MI_COLUMNMODE_DESC', 'select', 'int', 6, 0, ''),
(25786, 7, 0, 0, 'displayname', '_MI_NAMEDISPLAY', '1', '_MI_ADISPLAYNAMEDSC', 'select', 'int', 5, 0, ''),
(25785, 7, 0, 0, 'newsdisplay', '_MI_NEWSDISPLAY', 'Classic', '_MI_NEWSDISPLAYDESC', 'select', 'text', 4, 0, ''),
(25781, 7, 0, 0, 'storyhome', '_MI_STORYHOME', '5', '_MI_STORYHOMEDSC', 'select', 'int', 0, 0, ''),
(25782, 7, 0, 0, 'dateformat', '_MI_NEWS_DATEFORMAT', 'Y.m.d H:i', '_MI_NEWS_DATEFORMAT_DESC', 'textbox', 'text', 1, 0, ''),
(25783, 7, 0, 0, 'displaynav', '_MI_DISPLAYNAV', '0', '_MI_DISPLAYNAVDSC', 'yesno', 'int', 2, 0, ''),
(25784, 7, 0, 0, 'autoapprove', '_MI_AUTOAPPROVE', '1', '_MI_AUTOAPPROVEDSC', 'yesno', 'int', 3, 0, ''),
(25811, 7, 0, 0, 'enhanced_pagenav', '_MI_NEWS_ENHANCED_PAGENAV', '0', '_MI_NEWS_ENHANCED_PAGENAV_DSC', 'yesno', 'int', 30, 0, ''),
(25812, 7, 0, 0, 'com_rule', '_CM_COMRULES', '1', '', 'select', 'int', 31, 0, ''),
(25813, 7, 0, 0, 'com_anonpost', '_CM_COMANONPOST', '0', '', 'yesno', 'int', 32, 0, ''),
(25814, 7, 0, 0, 'notification_enabled', '_NOT_CONFIG_ENABLE', '0', '_NOT_CONFIG_ENABLEDSC', 'select', 'int', 33, 0, ''),
(25815, 7, 0, 0, 'notification_events', '_NOT_CONFIG_EVENTS', 'a:8:{i:0;s:19:"global-new_category";i:1;s:19:"global-story_submit";i:2;s:16:"global-new_story";i:3;s:13:"story-comment";i:4;s:20:"story-comment_submit";i:5;s:14:"story-bookmark";i:6;s:18:"category-new_story";i:7;s:17:"category-bookmark";}', '_NOT_CONFIG_EVENTSDSC', 'select_multi', 'array', 34, 0, '');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_configcategory`
--

CREATE TABLE `cztsd_configcategory` (
  `confcat_id` smallint(5) unsigned NOT NULL auto_increment,
  `confcat_name` varchar(25) NOT NULL default '',
  `confcat_order` smallint(5) unsigned NOT NULL default '0',
  `confcat_display` smallint(5) NOT NULL default '1',
  PRIMARY KEY  (`confcat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_configcategory`
--

INSERT INTO `cztsd_configcategory` (`confcat_id`, `confcat_name`, `confcat_order`, `confcat_display`) VALUES
(1, '_MD_AM_GENERAL', 0, 1),
(2, '_MD_AM_USERSETTINGS', 2, 1),
(3, '_MD_AM_METAFOOTER', 4, 1),
(4, '_MD_AM_CENSOR', 3, 1),
(5, '_MD_AM_SEARCH', 5, 1),
(6, '_MD_AM_MAILER', 6, 1),
(7, '_MD_AM_MESSAGE', 7, 0),
(8, '_MD_AM_THUMBNAILS', 8, 0),
(10, '_MD_AM_MIMETYPES', 9, 0),
(11, '_MD_AM_COPPA', 10, 1),
(13, '_MD_AM_LOCALE', 1, 1),
(14, '_MD_AM_AUTHENTICATION', 11, 1),
(15, '_MD_AM_SERVER', 2, 1),
(16, '_MD_AM_EVENTS', 0, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_configoption`
--

CREATE TABLE `cztsd_configoption` (
  `confop_id` mediumint(8) unsigned NOT NULL auto_increment,
  `confop_name` varchar(255) NOT NULL default '',
  `confop_value` varchar(255) NOT NULL default '',
  `conf_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`confop_id`),
  KEY `conf_id` (`conf_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=245 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_configoption`
--

INSERT INTO `cztsd_configoption` (`confop_id`, `confop_name`, `confop_value`, `conf_id`) VALUES
(1, '_MD_AM_DEBUGMODE0', '0', 13),
(2, '_MD_AM_DEBUGMODE1', '1', 13),
(3, '_MD_AM_DEBUGMODE2', '2', 13),
(4, '_MD_AM_DEBUGMODE3', '3', 13),
(5, '_MD_AM_DEBUGMODE4', '4', 13),
(6, '_MD_AM_DEBUGMODE5', '5', 13),
(7, '_MD_AM_DEBUGMODE6', '6', 13),
(8, 'Compact', '3', 21034),
(9, 'Threaded', '2', 21034),
(10, 'Flat', '1', 21034),
(11, 'Error', 'E_ERROR', 20403),
(12, 'Warning', 'E_WARNING', 20403),
(13, 'Parsing Error', 'E_PARSE', 20403),
(14, 'Notice', 'E_NOTICE', 20403),
(15, 'Core Error', 'E_CORE_ERROR', 20403),
(16, 'Core Warning', 'E_CORE_WARNING', 20403),
(17, 'Compile Error', 'E_COMPILE_ERROR', 20403),
(18, 'Compile Warning', 'E_COMPILE_WARNING', 20403),
(19, 'User Error', 'E_USER_ERROR', 20403),
(20, 'User Warning', 'E_USER_WARNING', 20403),
(21, 'User Notice', 'E_USER_NOTICE', 20403),
(22, 'Runtime Notice', 'E_STRICT', 20403),
(23, 'Default (All Errors)', 'E_ALL', 20403),
(24, '_NESTED', 'nest', 32),
(25, '_FLAT', 'flat', 32),
(26, '_THREADED', 'thread', 32),
(27, '_OLDESTFIRST', '0', 33),
(28, '_NEWESTFIRST', '1', 33),
(29, '_MD_AM_USERACTV', '0', 21),
(30, '_MD_AM_AUTOACTV', '1', 21),
(31, '_MD_AM_ADMINACTV', '2', 21),
(32, '_MD_AM_STRICT', '0', 23),
(33, '_MD_AM_MEDIUM', '1', 23),
(34, '_MD_AM_LIGHT', '2', 23),
(35, '_MD_AM_INDEXFOLLOW', 'index,follow', 43),
(36, '_MD_AM_NOINDEXFOLLOW', 'noindex,follow', 43),
(37, '_MD_AM_INDEXNOFOLLOW', 'index,nofollow', 43),
(38, '_MD_AM_NOINDEXNOFOLLOW', 'noindex,nofollow', 43),
(39, '_MD_AM_METAOGEN', 'general', 48),
(40, '_MD_AM_METAO14YRS', '14 years', 48),
(41, '_MD_AM_METAOREST', 'restricted', 48),
(42, '_MD_AM_METAOMAT', 'mature', 48),
(43, 'PHP mail()', 'mail', 64),
(44, 'sendmail', 'sendmail', 64),
(45, 'SMTP', 'smtp', 64),
(46, 'SMTPAuth', 'smtpauth', 64),
(47, 'Zarilia', 'zarilia', 23218),
(48, 'LDAP', 'ldap', 23218),
(49, '_MD_AM_EVENTSSYSTEMINTERNAL', 'internal', 24214),
(50, '_MD_AM_EVENTSSYSTEMAT', 'at', 24214),
(51, '_MD_AM_EVENTSSYSTEMCRONTAB', 'crontab', 24214),
(52, 'Numeric Verification (no background Image)', '1', 25592),
(53, 'AlphaNumeric Verification (no background Image)', '2', 25592),
(54, 'AlphaNumeric Verification (With Background Image)', '3', 25592),
(55, '_MD_AM_PASSLEVEL1', '20', 25593),
(56, '_MD_AM_PASSLEVEL2', '40', 25593),
(57, '_MD_AM_PASSLEVEL3', '60', 25593),
(58, '_MD_AM_PASSLEVEL4', '80', 25593),
(59, '_MD_AM_PASSLEVEL5', '95', 25593),
(60, 'Turn Off', '0', 25594),
(61, 'level 1', '1', 25594),
(62, 'level 2', '2', 25594),
(63, 'level 3', '3', 25594),
(64, 'level 4', '4', 25594),
(65, 'level 5', '5', 25594),
(66, 'level 6', '6', 25594),
(67, 'level 7', '7', 25594),
(68, 'level 8', '8', 25594),
(69, 'level 9', '9', 25594),
(202, '5', '5', 25787),
(201, '4', '4', 25787),
(200, '3', '3', 25787),
(228, 'ZDnet stiliaus', '8', 25804),
(227, 'Apvalainas', '7', 25804),
(226, 'Paprastas', '6', 25804),
(225, 'MacOS', '5', 25804),
(224, 'Aplankalo', '4', 25804),
(223, 'Klasikinis', '3', 25804),
(222, 'KÅ«ginis', '2', 25804),
(221, 'Juostos Stiliaus', '1', 25804),
(220, 'Tiny Editor', 'tinyeditor', 25799),
(219, 'FCK Redaktorius', 'fck', 25799),
(216, 'Spaw Redaktorius', 'spaw', 25799),
(215, 'CompaktiÅ¡kas', 'textarea', 25799),
(218, 'Koivi Redaktorius', 'koivi', 25799),
(217, 'HtmlArea Redaktorius', 'htmlarea', 25799),
(214, 'DHTML', 'dhtml', 25799),
(213, '_MI_UPLOAD_GROUP3', '3', 25789),
(212, '_MI_UPLOAD_GROUP2', '2', 25789),
(211, '_MI_UPLOAD_GROUP1', '1', 25789),
(210, '40', '40', 25788),
(209, '35', '35', 25788),
(208, '30', '30', 25788),
(207, '25', '25', 25788),
(206, '20', '20', 25788),
(205, '15', '15', 25788),
(204, '10', '10', 25788),
(203, '5', '5', 25788),
(199, '2', '2', 25787),
(198, '1', '1', 25787),
(197, '_MI_DISPLAYNAME3', '3', 25786),
(196, '_MI_DISPLAYNAME2', '2', 25786),
(195, '_MI_DISPLAYNAME1', '1', 25786),
(194, '_MI_NEWSBYTOPIC', 'Bytopic', 25785),
(193, '_MI_NEWSCLASSIC', 'Classic', 25785),
(192, '30', '30', 25781),
(191, '25', '25', 25781),
(190, '20', '20', 25781),
(189, '15', '15', 25781),
(188, '10', '10', 25781),
(187, '5', '5', 25781),
(229, '_CM_COMNOCOM', '0', 25812),
(230, '_CM_COMAPPROVEALL', '1', 25812),
(231, '_CM_COMAPPROVEUSER', '2', 25812),
(232, '_CM_COMAPPROVEADMIN', '3', 25812),
(233, '_NOT_CONFIG_DISABLE', '0', 25814),
(234, '_NOT_CONFIG_ENABLEBLOCK', '1', 25814),
(235, '_NOT_CONFIG_ENABLEINLINE', '2', 25814),
(236, '_NOT_CONFIG_ENABLEBOTH', '3', 25814),
(237, 'Globaliniai : Nauja Tema', 'global-new_category', 25815),
(238, 'Globaliniai : Priduotas naujas straipsnis', 'global-story_submit', 25815),
(239, 'Globaliniai : Naujas Straipsnis', 'global-new_story', 25815),
(240, 'Straipsnis : PridÄ—tas komentaras', 'story-comment', 25815),
(241, 'Straipsnis : Komentaras pateiktas', 'story-comment_submit', 25815),
(242, 'Straipsnis : Å½ymeklis', 'story-bookmark', 25815),
(243, ':', 'category-new_story', 25815),
(244, ': Å½ymeklis', 'category-bookmark', 25815);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_configoption_seq`
--

CREATE TABLE `cztsd_configoption_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_configoption_seq`
--

INSERT INTO `cztsd_configoption_seq` (`id`) VALUES
(244);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_config_seq`
--

CREATE TABLE `cztsd_config_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_config_seq`
--

INSERT INTO `cztsd_config_seq` (`id`) VALUES
(25815);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_content`
--

CREATE TABLE `cztsd_content` (
  `content_id` int(11) unsigned NOT NULL auto_increment,
  `content_sid` int(11) unsigned NOT NULL default '0',
  `content_cid` int(11) unsigned NOT NULL default '0',
  `content_uid` int(11) unsigned NOT NULL default '0',
  `content_alias` varchar(100) NOT NULL default '',
  `content_created` int(11) unsigned NOT NULL default '0',
  `content_published` int(11) unsigned NOT NULL default '0',
  `content_updated` int(11) unsigned NOT NULL default '0',
  `content_expired` int(11) unsigned NOT NULL default '0',
  `content_title` varchar(100) NOT NULL default '',
  `content_subtitle` varchar(100) NOT NULL default '',
  `content_intro` text NOT NULL,
  `content_body` mediumtext NOT NULL,
  `content_images` text NOT NULL,
  `content_summary` text NOT NULL,
  `content_counter` int(11) NOT NULL default '0',
  `content_type` varchar(10) NOT NULL default 'static',
  `content_hits` int(11) NOT NULL default '0',
  `content_version` decimal(3,2) NOT NULL default '0.00',
  `content_approved` smallint(1) NOT NULL default '0',
  `content_meta` text NOT NULL,
  `content_keywords` text NOT NULL,
  `content_weight` tinyint(5) NOT NULL default '0',
  `content_display` tinyint(1) NOT NULL default '1',
  `content_spotlight` tinyint(1) NOT NULL default '0',
  `content_spotlightmain` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`content_id`),
  KEY `idx_sid` (`content_sid`),
  KEY `idx_cid` (`content_cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_content`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_category`
--

CREATE TABLE `cztsd_en_category` (
  `category_id` mediumint(8) NOT NULL auto_increment,
  `category_pid` mediumint(8) NOT NULL default '0',
  `category_sid` mediumint(3) NOT NULL default '0',
  `category_title` varchar(150) NOT NULL default '',
  `category_description` text NOT NULL,
  `category_image` varchar(150) NOT NULL default '',
  `category_weight` tinyint(1) NOT NULL default '0',
  `category_display` tinyint(1) NOT NULL default '1',
  `category_published` int(11) NOT NULL default '0',
  `category_imageside` varchar(4) NOT NULL default 'left',
  `category_type` varchar(10) NOT NULL default '',
  `category_header` varchar(150) NOT NULL default '',
  `category_footer` varchar(150) NOT NULL default '',
  `category_body` text NOT NULL,
  UNIQUE KEY `category_id` (`category_id`),
  KEY `category_title` (`category_display`,`category_published`,`category_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_category`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_content`
--

CREATE TABLE `cztsd_en_content` (
  `content_id` int(11) unsigned NOT NULL auto_increment,
  `content_sid` int(11) unsigned NOT NULL default '0',
  `content_cid` int(11) unsigned NOT NULL default '0',
  `content_uid` int(11) unsigned NOT NULL default '0',
  `content_alias` varchar(100) NOT NULL default '',
  `content_created` int(11) unsigned NOT NULL default '0',
  `content_published` int(11) unsigned NOT NULL default '0',
  `content_updated` int(11) unsigned NOT NULL default '0',
  `content_expired` int(11) unsigned NOT NULL default '0',
  `content_title` varchar(100) NOT NULL default '',
  `content_subtitle` varchar(100) NOT NULL default '',
  `content_intro` text NOT NULL,
  `content_body` mediumtext NOT NULL,
  `content_images` text NOT NULL,
  `content_summary` text NOT NULL,
  `content_counter` int(11) NOT NULL default '0',
  `content_type` varchar(10) NOT NULL default 'static',
  `content_hits` int(11) NOT NULL default '0',
  `content_version` decimal(3,2) NOT NULL default '0.00',
  `content_approved` smallint(1) NOT NULL default '0',
  `content_meta` text NOT NULL,
  `content_keywords` text NOT NULL,
  `content_weight` tinyint(5) NOT NULL default '0',
  `content_display` tinyint(1) NOT NULL default '1',
  `content_spotlight` tinyint(1) NOT NULL default '0',
  `content_spotlightmain` tinyint(1) NOT NULL default '0',
  `content_status` int(11) NOT NULL,
  PRIMARY KEY  (`content_id`),
  KEY `idx_sid` (`content_sid`),
  KEY `idx_cid` (`content_cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_content`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_menus`
--

CREATE TABLE `cztsd_en_menus` (
  `menu_id` int(11) NOT NULL auto_increment,
  `menu_pid` int(11) default '0',
  `menu_type` varchar(25) default NULL,
  `menu_title` varchar(100) default NULL,
  `menu_link` varchar(255) default NULL,
  `menu_image` varchar(255) default NULL,
  `menu_weight` int(3) default '0',
  `menu_mid` int(3) default '0',
  `menu_name` varchar(35) NOT NULL default '',
  `menu_sectionid` int(3) NOT NULL default '0',
  `menu_display` tinyint(1) default '0',
  `menu_target` varchar(20) default NULL,
  `menu_class` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`menu_id`),
  KEY `menu_type` (`menu_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_menus`
--

INSERT INTO `cztsd_en_menus` (`menu_id`, `menu_pid`, `menu_type`, `menu_title`, `menu_link`, `menu_image`, `menu_weight`, `menu_mid`, `menu_name`, `menu_sectionid`, `menu_display`, `menu_target`, `menu_class`) VALUES
(1, 0, 'usermenu', 'My Account', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 1, 0, '', 0, 1, '', '0'),
(2, 0, 'usermenu', 'Logout', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 3, 0, '', 0, 1, '', '0'),
(3, 0, 'usermenu', 'Administrator Area', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(5, 0, 'mainmenu', 'Home', '{X_SITEURL}', '', 0, 0, '', 0, 1, '', ''),
(6, 0, 'topmenu', 'Home', '{X_SITEURL}', '', 0, 0, '', 0, 1, '', ''),
(37, 0, 'usermenu', 'Notifications', '{X_SITEURL}/index.php?page_type=notifications', '', 2, 0, '', 0, 1, '', ''),
(40, 0, 'topmenu', 'Users Menu', '', '', 2, 0, '', 0, 1, '', ''),
(41, 0, 'footermenu', 'Register', '{X_SITEURL}/index.php?page_type=register', '', 0, 0, '', 0, 1, '', ''),
(42, 40, 'topmenu', 'Administrator Area', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(44, 40, 'topmenu', 'My Account', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 2, 0, '', 0, 1, '', ''),
(45, 40, 'topmenu', 'Notifications', '{X_SITEURL}/index.php?page_type=notifications', '', 3, 0, '', 0, 1, '', ''),
(47, 40, 'topmenu', 'Logout', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 4, 0, '', 0, 1, '', '0');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_profilecategory`
--

CREATE TABLE `cztsd_en_profilecategory` (
  `profilecat_id` smallint(5) unsigned NOT NULL auto_increment,
  `profilecat_name` varchar(25) NOT NULL default '',
  `profilecat_order` smallint(5) unsigned NOT NULL default '0',
  `profilecat_desc` text NOT NULL,
  `profilecat_display` smallint(2) NOT NULL default '1',
  PRIMARY KEY  (`profilecat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_profilecategory`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_rss`
--

CREATE TABLE `cztsd_en_rss` (
  `rss_id` smallint(3) unsigned NOT NULL auto_increment,
  `rss_name` varchar(255) NOT NULL default '',
  `rss_url` varchar(255) NOT NULL default '',
  `rss_rssurl` varchar(255) NOT NULL default '',
  `rss_encoding` varchar(15) NOT NULL default '',
  `rss_cachetime` mediumint(8) unsigned NOT NULL default '3600',
  `rss_asblock` tinyint(1) unsigned NOT NULL default '0',
  `rss_display` tinyint(1) unsigned NOT NULL default '0',
  `rss_weight` smallint(3) unsigned NOT NULL default '0',
  `rss_mainfull` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainimg` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_blockimg` tinyint(1) unsigned NOT NULL default '0',
  `rss_blockmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_xml` text NOT NULL,
  `rss_updated` int(10) NOT NULL default '0',
  PRIMARY KEY  (`rss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_rss`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_section`
--

CREATE TABLE `cztsd_en_section` (
  `section_id` mediumint(8) NOT NULL auto_increment,
  `section_title` varchar(150) NOT NULL default '',
  `section_image` varchar(150) NOT NULL default '',
  `section_weight` tinyint(1) NOT NULL default '0',
  `section_display` enum('0','1') NOT NULL default '1',
  `section_published` int(11) NOT NULL default '0',
  `section_imageside` varchar(4) NOT NULL default 'left',
  `section_description` text NOT NULL,
  `section_type` varchar(10) NOT NULL default '',
  `section_is` tinyint(1) NOT NULL default '1',
  UNIQUE KEY `section_id` (`section_id`),
  KEY `section_title` (`section_display`,`section_published`,`section_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_section`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_stories`
--

CREATE TABLE `cztsd_en_stories` (
  `storyid` int(8) unsigned NOT NULL auto_increment,
  `uid` int(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `created` int(10) unsigned NOT NULL default '0',
  `published` int(10) unsigned NOT NULL default '0',
  `expired` int(10) unsigned NOT NULL default '0',
  `hostname` varchar(20) NOT NULL default '',
  `nohtml` tinyint(1) NOT NULL default '0',
  `nosmiley` tinyint(1) NOT NULL default '0',
  `hometext` text NOT NULL,
  `bodytext` text NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `counter` int(8) unsigned NOT NULL default '0',
  `topicid` smallint(4) unsigned NOT NULL default '1',
  `ihome` tinyint(1) NOT NULL default '0',
  `notifypub` tinyint(1) NOT NULL default '0',
  `story_type` varchar(5) NOT NULL default '',
  `topicdisplay` tinyint(1) NOT NULL default '0',
  `topicalign` char(1) NOT NULL default 'R',
  `comments` smallint(5) unsigned NOT NULL default '0',
  `rating` double(6,4) NOT NULL default '0.0000',
  `votes` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`storyid`),
  KEY `idxstoriestopic` (`topicid`),
  KEY `ihome` (`ihome`),
  KEY `uid` (`uid`),
  KEY `published_ihome` (`published`,`ihome`),
  KEY `title` (`title`(40)),
  KEY `created` (`created`),
  FULLTEXT KEY `search` (`title`,`hometext`,`bodytext`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_stories`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_stories_files`
--

CREATE TABLE `cztsd_en_stories_files` (
  `fileid` int(8) unsigned NOT NULL auto_increment,
  `filerealname` varchar(255) NOT NULL default '',
  `storyid` int(8) unsigned NOT NULL default '0',
  `date` int(10) NOT NULL default '0',
  `mimetype` varchar(64) NOT NULL default '',
  `downloadname` varchar(255) NOT NULL default '',
  `counter` int(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`fileid`),
  KEY `storyid` (`storyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_stories_files`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_stories_votedata`
--

CREATE TABLE `cztsd_en_stories_votedata` (
  `ratingid` int(11) unsigned NOT NULL auto_increment,
  `storyid` int(8) unsigned NOT NULL default '0',
  `ratinguser` int(11) NOT NULL default '0',
  `rating` tinyint(3) unsigned NOT NULL default '0',
  `ratinghostname` varchar(60) NOT NULL default '',
  `ratingtimestamp` int(10) NOT NULL default '0',
  PRIMARY KEY  (`ratingid`),
  KEY `ratinguser` (`ratinguser`),
  KEY `ratinghostname` (`ratinghostname`),
  KEY `storyid` (`storyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_stories_votedata`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_en_topics`
--

CREATE TABLE `cztsd_en_topics` (
  `topic_id` smallint(4) unsigned NOT NULL auto_increment,
  `topic_pid` smallint(4) unsigned NOT NULL default '0',
  `topic_imgurl` varchar(20) NOT NULL default '',
  `topic_title` varchar(255) NOT NULL default '',
  `menu` tinyint(1) NOT NULL default '0',
  `topic_frontpage` tinyint(1) NOT NULL default '1',
  `topic_rssurl` varchar(255) NOT NULL default '',
  `topic_description` text NOT NULL,
  `topic_color` varchar(6) NOT NULL default '000000',
  PRIMARY KEY  (`topic_id`),
  KEY `pid` (`topic_pid`),
  KEY `topic_title` (`topic_title`),
  KEY `menu` (`menu`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_en_topics`
--

INSERT INTO `cztsd_en_topics` (`topic_id`, `topic_pid`, `topic_imgurl`, `topic_title`, `menu`, `topic_frontpage`, `topic_rssurl`, `topic_description`, `topic_color`) VALUES
(1, 0, 'xoops.gif', 'ZARILIA', 0, 1, '', '', '000000');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_errors`
--

CREATE TABLE `cztsd_errors` (
  `errors_id` mediumint(8) NOT NULL auto_increment,
  `errors_title` varchar(60) NOT NULL default '',
  `errors_description` text NOT NULL,
  `errors_no` mediumint(8) NOT NULL default '0',
  `errors_date` int(11) NOT NULL default '0',
  `errors_ip` varchar(20) NOT NULL default '',
  `errors_report` text NOT NULL,
  `errors_hash` varchar(40) NOT NULL default '',
  UNIQUE KEY `errors_id` (`errors_id`),
  KEY `errors_no` (`errors_date`,`errors_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_errors`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_events`
--

CREATE TABLE `cztsd_events` (
  `id` int(11) NOT NULL auto_increment,
  `NextTime` text NOT NULL,
  `RepeatNum` int(11) NOT NULL,
  `RepeatInterval` int(11) NOT NULL,
  `RepeatSystem` text NOT NULL,
  `Code` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_events`
--

INSERT INTO `cztsd_events` (`id`, `NextTime`, `RepeatNum`, `RepeatInterval`, `RepeatSystem`, `Code`) VALUES
(1, '1192074660', -1, 52, '2', 'echo ''a'';');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_events_seq`
--

CREATE TABLE `cztsd_events_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_events_seq`
--

INSERT INTO `cztsd_events_seq` (`id`) VALUES
(14);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_groups`
--

CREATE TABLE `cztsd_groups` (
  `groupid` smallint(5) unsigned NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `description` text NOT NULL,
  `group_type` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`groupid`),
  KEY `group_type` (`group_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_groups`
--

INSERT INTO `cztsd_groups` (`groupid`, `name`, `description`, `group_type`) VALUES
(1, 'Webmasters', 'Webmasters of this site', 'Admin'),
(2, 'Registered Users', 'Registered Users Group', 'User'),
(3, 'Anonymous Users', 'Anonymous Users Group', 'Anonymous'),
(4, 'Moderator', 'These are Moderators for your website', 'Moderator'),
(5, 'Submitters', 'This group can submit articles to your website', 'Submitter'),
(6, 'Subscription', 'Subscribed users to your website.', 'Subscribed'),
(7, 'Banned', 'These are the users that you have banned from entering your website.', 'Banned');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_groups_seq`
--

CREATE TABLE `cztsd_groups_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_groups_seq`
--

INSERT INTO `cztsd_groups_seq` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_groups_users_link`
--

CREATE TABLE `cztsd_groups_users_link` (
  `linkid` mediumint(8) unsigned NOT NULL auto_increment,
  `groupid` smallint(5) unsigned NOT NULL default '0',
  `uid` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`linkid`),
  KEY `groupid_uid` (`groupid`,`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_groups_users_link`
--

INSERT INTO `cztsd_groups_users_link` (`linkid`, `groupid`, `uid`) VALUES
(98, 1, 1),
(100, 4, 1),
(101, 5, 1),
(102, 6, 1),
(99, 2, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_groups_users_link_seq`
--

CREATE TABLE `cztsd_groups_users_link_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_groups_users_link_seq`
--

INSERT INTO `cztsd_groups_users_link_seq` (`id`) VALUES
(102);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_group_permission`
--

CREATE TABLE `cztsd_group_permission` (
  `gperm_id` int(10) unsigned NOT NULL auto_increment,
  `gperm_groupid` smallint(5) unsigned NOT NULL default '0',
  `gperm_itemid` mediumint(8) unsigned NOT NULL default '0',
  `gperm_modid` mediumint(5) unsigned NOT NULL default '0',
  `gperm_name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`gperm_id`),
  KEY `groupid` (`gperm_groupid`),
  KEY `itemid` (`gperm_itemid`),
  KEY `gperm_modid` (`gperm_modid`,`gperm_name`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1076 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_group_permission`
--

INSERT INTO `cztsd_group_permission` (`gperm_id`, `gperm_groupid`, `gperm_itemid`, `gperm_modid`, `gperm_name`) VALUES
(1, 1, 1, 1, 'system_admin'),
(2, 1, 2, 1, 'system_admin'),
(3, 1, 3, 1, 'system_admin'),
(4, 1, 4, 1, 'system_admin'),
(5, 1, 5, 1, 'system_admin'),
(6, 1, 7, 1, 'system_admin'),
(7, 1, 8, 1, 'system_admin'),
(8, 1, 9, 1, 'system_admin'),
(9, 1, 10, 1, 'system_admin'),
(10, 1, 11, 1, 'system_admin'),
(11, 1, 12, 1, 'system_admin'),
(12, 1, 14, 1, 'system_admin'),
(13, 1, 15, 1, 'system_admin'),
(14, 1, 18, 1, 'system_admin'),
(15, 1, 19, 1, 'system_admin'),
(16, 1, 21, 1, 'system_admin'),
(17, 1, 22, 1, 'system_admin'),
(18, 1, 23, 1, 'system_admin'),
(19, 1, 24, 1, 'system_admin'),
(20, 1, 25, 1, 'system_admin'),
(21, 1, 26, 1, 'system_admin'),
(22, 1, 27, 1, 'system_admin'),
(23, 1, 28, 1, 'system_admin'),
(24, 1, 29, 1, 'system_admin'),
(25, 1, 30, 1, 'system_admin'),
(26, 1, 31, 1, 'system_admin'),
(27, 1, 32, 1, 'system_admin'),
(28, 1, 33, 1, 'system_admin'),
(465, 3, 5, 1, 'menu_read'),
(464, 2, 5, 1, 'menu_read'),
(463, 1, 5, 1, 'menu_read'),
(32, 1, 3, 1, 'menu_read'),
(421, 2, 1, 1, 'menu_read'),
(420, 1, 1, 1, 'menu_read'),
(35, 1, 37, 1, 'menu_read'),
(36, 2, 37, 1, 'menu_read'),
(476, 7, 201, 1, 'menu_read'),
(427, 1, 2, 1, 'menu_read'),
(39, 1, 6, 1, 'menu_read'),
(40, 2, 6, 1, 'menu_read'),
(41, 3, 6, 1, 'menu_read'),
(42, 1, 42, 1, 'menu_read'),
(43, 1, 40, 1, 'menu_read'),
(44, 2, 40, 1, 'menu_read'),
(45, 1, 44, 1, 'menu_read'),
(46, 2, 44, 1, 'menu_read'),
(47, 1, 45, 1, 'menu_read'),
(48, 2, 45, 1, 'menu_read'),
(49, 1, 47, 1, 'menu_read'),
(50, 2, 47, 1, 'menu_read'),
(51, 1, 1, 1, 'addon_admin'),
(52, 2, 1, 1, 'addon_read'),
(53, 4, 1, 1, 'addon_read'),
(54, 5, 1, 1, 'addon_read'),
(55, 6, 1, 1, 'addon_read'),
(392, 2, 9, 1, 'addon_read'),
(391, 2, 9, 1, 'addon_admin'),
(390, 2, 9, 1, 'addon_read'),
(389, 2, 9, 1, 'addon_admin'),
(388, 1, 9, 1, 'addon_read'),
(387, 1, 9, 1, 'addon_admin'),
(386, 1, 9, 1, 'addon_read'),
(385, 1, 9, 1, 'addon_admin'),
(384, 6, 8, 1, 'addon_read'),
(383, 6, 8, 1, 'addon_admin'),
(382, 5, 8, 1, 'addon_read'),
(381, 5, 8, 1, 'addon_admin'),
(379, 4, 8, 1, 'addon_admin'),
(378, 2, 8, 1, 'addon_read'),
(377, 2, 8, 1, 'addon_admin'),
(376, 2, 8, 1, 'addon_read'),
(375, 2, 8, 1, 'addon_admin'),
(374, 1, 8, 1, 'addon_read'),
(372, 1, 8, 1, 'addon_read'),
(371, 1, 8, 1, 'addon_admin'),
(370, 6, 40, 1, 'block_read'),
(369, 6, 39, 1, 'block_read'),
(368, 6, 38, 1, 'block_read'),
(367, 6, 37, 1, 'block_read'),
(365, 6, 35, 1, 'block_read'),
(364, 6, 34, 1, 'block_read'),
(363, 6, 33, 1, 'block_read'),
(362, 6, 7, 1, 'addon_read'),
(361, 6, 7, 1, 'addon_admin'),
(360, 5, 40, 1, 'block_read'),
(358, 5, 38, 1, 'block_read'),
(357, 5, 37, 1, 'block_read'),
(356, 5, 36, 1, 'block_read'),
(355, 5, 35, 1, 'block_read'),
(354, 5, 34, 1, 'block_read'),
(353, 5, 33, 1, 'block_read'),
(351, 5, 7, 1, 'addon_admin'),
(350, 4, 40, 1, 'block_read'),
(349, 4, 39, 1, 'block_read'),
(348, 4, 38, 1, 'block_read'),
(347, 4, 37, 1, 'block_read'),
(346, 4, 36, 1, 'block_read'),
(344, 4, 34, 1, 'block_read'),
(343, 4, 33, 1, 'block_read'),
(342, 4, 7, 1, 'addon_read'),
(341, 4, 7, 1, 'addon_admin'),
(340, 2, 40, 1, 'block_read'),
(339, 2, 39, 1, 'block_read'),
(314, 1, 34, 1, 'block_read'),
(313, 1, 33, 1, 'block_read'),
(312, 1, 7, 1, 'addon_read'),
(311, 1, 7, 1, 'addon_admin'),
(310, 1, 40, 1, 'block_read'),
(309, 1, 39, 1, 'block_read'),
(307, 1, 37, 1, 'block_read'),
(306, 1, 36, 1, 'block_read'),
(305, 1, 35, 1, 'block_read'),
(304, 1, 34, 1, 'block_read'),
(303, 1, 33, 1, 'block_read'),
(302, 1, 7, 1, 'addon_read'),
(332, 2, 7, 1, 'addon_read'),
(331, 2, 7, 1, 'addon_admin'),
(330, 2, 40, 1, 'block_read'),
(329, 2, 39, 1, 'block_read'),
(328, 2, 38, 1, 'block_read'),
(322, 2, 7, 1, 'addon_read'),
(321, 2, 7, 1, 'addon_admin'),
(320, 1, 40, 1, 'block_read'),
(319, 1, 39, 1, 'block_read'),
(318, 1, 38, 1, 'block_read'),
(317, 1, 37, 1, 'block_read'),
(327, 2, 37, 1, 'block_read'),
(326, 2, 36, 1, 'block_read'),
(325, 2, 35, 1, 'block_read'),
(324, 2, 34, 1, 'block_read'),
(323, 2, 33, 1, 'block_read'),
(337, 2, 37, 1, 'block_read'),
(336, 2, 36, 1, 'block_read'),
(335, 2, 35, 1, 'block_read'),
(334, 2, 34, 1, 'block_read'),
(333, 2, 33, 1, 'block_read'),
(177, 1, 1, 1, 'addon_read'),
(380, 4, 8, 1, 'addon_read'),
(359, 5, 39, 1, 'block_read'),
(373, 1, 8, 1, 'addon_admin'),
(366, 6, 36, 1, 'block_read'),
(352, 5, 7, 1, 'addon_read'),
(345, 4, 35, 1, 'block_read'),
(338, 2, 38, 1, 'block_read'),
(308, 1, 38, 1, 'block_read'),
(301, 1, 7, 1, 'addon_admin'),
(315, 1, 35, 1, 'block_read'),
(316, 1, 36, 1, 'block_read'),
(393, 4, 9, 1, 'addon_admin'),
(394, 4, 9, 1, 'addon_read'),
(395, 5, 9, 1, 'addon_admin'),
(396, 5, 9, 1, 'addon_read'),
(397, 6, 9, 1, 'addon_admin'),
(398, 6, 9, 1, 'addon_read'),
(399, 1, 10, 1, 'addon_admin'),
(400, 1, 10, 1, 'addon_read'),
(401, 1, 41, 1, 'block_read'),
(402, 1, 10, 1, 'addon_admin'),
(403, 1, 10, 1, 'addon_read'),
(404, 1, 41, 1, 'block_read'),
(405, 2, 10, 1, 'addon_admin'),
(406, 2, 10, 1, 'addon_read'),
(407, 2, 41, 1, 'block_read'),
(408, 2, 10, 1, 'addon_admin'),
(409, 2, 10, 1, 'addon_read'),
(410, 2, 41, 1, 'block_read'),
(411, 4, 10, 1, 'addon_admin'),
(412, 4, 10, 1, 'addon_read'),
(413, 4, 41, 1, 'block_read'),
(414, 5, 10, 1, 'addon_admin'),
(415, 5, 10, 1, 'addon_read'),
(416, 5, 41, 1, 'block_read'),
(417, 6, 10, 1, 'addon_admin'),
(418, 6, 10, 1, 'addon_read'),
(419, 6, 41, 1, 'block_read'),
(422, 3, 1, 1, 'menu_read'),
(423, 4, 1, 1, 'menu_read'),
(424, 5, 1, 1, 'menu_read'),
(425, 6, 1, 1, 'menu_read'),
(426, 7, 1, 1, 'menu_read'),
(475, 6, 201, 1, 'menu_read'),
(474, 5, 201, 1, 'menu_read'),
(473, 4, 201, 1, 'menu_read'),
(472, 3, 201, 1, 'menu_read'),
(471, 2, 201, 1, 'menu_read'),
(470, 1, 201, 1, 'menu_read'),
(466, 4, 5, 1, 'menu_read'),
(467, 5, 5, 1, 'menu_read'),
(468, 6, 5, 1, 'menu_read'),
(469, 7, 5, 1, 'menu_read'),
(534, 7, 203, 1, 'menu_read'),
(513, 6, 202, 1, 'menu_read'),
(512, 5, 202, 1, 'menu_read'),
(511, 4, 202, 1, 'menu_read'),
(510, 3, 202, 1, 'menu_read'),
(509, 2, 202, 1, 'menu_read'),
(508, 1, 202, 1, 'menu_read'),
(533, 6, 203, 1, 'menu_read'),
(532, 5, 203, 1, 'menu_read'),
(531, 4, 203, 1, 'menu_read'),
(530, 3, 203, 1, 'menu_read'),
(529, 2, 203, 1, 'menu_read'),
(528, 1, 203, 1, 'menu_read'),
(541, 7, 204, 1, 'menu_read'),
(540, 6, 204, 1, 'menu_read'),
(539, 5, 204, 1, 'menu_read'),
(538, 4, 204, 1, 'menu_read'),
(537, 3, 204, 1, 'menu_read'),
(536, 2, 204, 1, 'menu_read'),
(535, 1, 204, 1, 'menu_read'),
(542, 1, 205, 1, 'menu_read'),
(543, 2, 205, 1, 'menu_read'),
(544, 3, 205, 1, 'menu_read'),
(545, 4, 205, 1, 'menu_read'),
(546, 5, 205, 1, 'menu_read'),
(547, 6, 205, 1, 'menu_read'),
(548, 7, 205, 1, 'menu_read'),
(549, 1, 206, 1, 'menu_read'),
(550, 2, 206, 1, 'menu_read'),
(551, 3, 206, 1, 'menu_read'),
(552, 4, 206, 1, 'menu_read'),
(553, 5, 206, 1, 'menu_read'),
(554, 6, 206, 1, 'menu_read'),
(555, 7, 206, 1, 'menu_read'),
(556, 1, 1, 1, 'content_read'),
(557, 2, 1, 1, 'content_read'),
(558, 3, 1, 1, 'content_read'),
(559, 4, 1, 1, 'content_read'),
(560, 5, 1, 1, 'content_read'),
(561, 6, 1, 1, 'content_read'),
(562, 7, 1, 1, 'content_read'),
(583, 7, 207, 1, 'menu_read'),
(582, 6, 207, 1, 'menu_read'),
(581, 5, 207, 1, 'menu_read'),
(580, 4, 207, 1, 'menu_read'),
(579, 3, 207, 1, 'menu_read'),
(578, 2, 207, 1, 'menu_read'),
(577, 1, 207, 1, 'menu_read'),
(606, 7, 1, 1, 'section_read'),
(605, 6, 1, 1, 'section_read'),
(604, 5, 1, 1, 'section_read'),
(603, 4, 1, 1, 'section_read'),
(602, 3, 1, 1, 'section_read'),
(601, 2, 1, 1, 'section_read'),
(600, 1, 1, 1, 'section_read'),
(607, 1, 1, 1, 'section_write'),
(592, 1, 2, 1, 'section_read'),
(593, 2, 2, 1, 'section_read'),
(594, 3, 2, 1, 'section_read'),
(595, 4, 2, 1, 'section_read'),
(596, 5, 2, 1, 'section_read'),
(597, 6, 2, 1, 'section_read'),
(598, 7, 2, 1, 'section_read'),
(599, 1, 2, 1, 'section_write'),
(611, 1, 0, 7, 'news_submit'),
(612, 2, 0, 7, 'news_submit'),
(613, 3, 0, 7, 'news_submit'),
(614, 4, 0, 7, 'news_submit'),
(615, 5, 0, 7, 'news_submit'),
(616, 6, 0, 7, 'news_submit'),
(650, 1, 0, 7, 'news_submit'),
(651, 2, 0, 7, 'news_submit'),
(652, 3, 0, 7, 'news_submit'),
(653, 4, 0, 7, 'news_submit'),
(654, 5, 0, 7, 'news_submit'),
(655, 6, 0, 7, 'news_submit'),
(656, 7, 0, 7, 'news_submit'),
(664, 1, 2, 1, 'content_read'),
(665, 2, 2, 1, 'content_read'),
(666, 3, 2, 1, 'content_read'),
(667, 4, 2, 1, 'content_read'),
(668, 5, 2, 1, 'content_read'),
(669, 6, 2, 1, 'content_read'),
(670, 7, 2, 1, 'content_read'),
(691, 7, 208, 1, 'menu_read'),
(690, 6, 208, 1, 'menu_read'),
(689, 5, 208, 1, 'menu_read'),
(688, 4, 208, 1, 'menu_read'),
(687, 3, 208, 1, 'menu_read'),
(686, 2, 208, 1, 'menu_read'),
(685, 1, 208, 1, 'menu_read'),
(692, 1, 210, 1, 'menu_read'),
(693, 2, 210, 1, 'menu_read'),
(694, 3, 210, 1, 'menu_read'),
(695, 4, 210, 1, 'menu_read'),
(696, 5, 210, 1, 'menu_read'),
(697, 6, 210, 1, 'menu_read'),
(698, 7, 210, 1, 'menu_read'),
(739, 1, 0, 7, 'news_submit'),
(740, 2, 0, 7, 'news_submit'),
(741, 3, 0, 7, 'news_submit'),
(742, 4, 0, 7, 'news_submit'),
(743, 5, 0, 7, 'news_submit'),
(744, 6, 0, 7, 'news_submit'),
(745, 7, 0, 7, 'news_submit'),
(755, 1, 0, 7, 'news_submit'),
(756, 2, 0, 7, 'news_submit'),
(757, 4, 0, 7, 'news_submit'),
(765, 1, 3, 1, 'section_read'),
(766, 2, 3, 1, 'section_read'),
(767, 3, 3, 1, 'section_read'),
(768, 4, 3, 1, 'section_read'),
(769, 5, 3, 1, 'section_read'),
(770, 6, 3, 1, 'section_read'),
(771, 7, 3, 1, 'section_read'),
(772, 1, 3, 1, 'section_write'),
(773, 1, 4, 1, 'content_read'),
(774, 2, 4, 1, 'content_read'),
(775, 3, 4, 1, 'content_read'),
(776, 4, 4, 1, 'content_read'),
(777, 5, 4, 1, 'content_read'),
(778, 6, 4, 1, 'content_read'),
(779, 7, 4, 1, 'content_read'),
(780, 1, 211, 1, 'menu_read'),
(781, 2, 211, 1, 'menu_read'),
(782, 3, 211, 1, 'menu_read'),
(783, 4, 211, 1, 'menu_read'),
(784, 5, 211, 1, 'menu_read'),
(785, 6, 211, 1, 'menu_read'),
(786, 7, 211, 1, 'menu_read'),
(787, 1, 5, 1, 'content_read'),
(788, 2, 5, 1, 'content_read'),
(789, 3, 5, 1, 'content_read'),
(790, 4, 5, 1, 'content_read'),
(791, 5, 5, 1, 'content_read'),
(792, 6, 5, 1, 'content_read'),
(793, 7, 5, 1, 'content_read'),
(794, 1, 212, 1, 'menu_read'),
(795, 2, 212, 1, 'menu_read'),
(796, 3, 212, 1, 'menu_read'),
(797, 4, 212, 1, 'menu_read'),
(798, 5, 212, 1, 'menu_read'),
(799, 6, 212, 1, 'menu_read'),
(800, 7, 212, 1, 'menu_read'),
(801, 1, 6, 1, 'content_read'),
(802, 2, 6, 1, 'content_read'),
(803, 3, 6, 1, 'content_read'),
(804, 4, 6, 1, 'content_read'),
(805, 5, 6, 1, 'content_read'),
(806, 6, 6, 1, 'content_read'),
(807, 7, 6, 1, 'content_read'),
(808, 1, 213, 1, 'menu_read'),
(809, 2, 213, 1, 'menu_read'),
(810, 3, 213, 1, 'menu_read'),
(811, 4, 213, 1, 'menu_read'),
(812, 5, 213, 1, 'menu_read'),
(813, 6, 213, 1, 'menu_read'),
(814, 7, 213, 1, 'menu_read'),
(815, 1, 7, 1, 'content_read'),
(816, 2, 7, 1, 'content_read'),
(817, 3, 7, 1, 'content_read'),
(818, 4, 7, 1, 'content_read'),
(819, 5, 7, 1, 'content_read'),
(820, 6, 7, 1, 'content_read'),
(821, 7, 7, 1, 'content_read'),
(822, 1, 214, 1, 'menu_read'),
(823, 2, 214, 1, 'menu_read'),
(824, 3, 214, 1, 'menu_read'),
(825, 4, 214, 1, 'menu_read'),
(826, 5, 214, 1, 'menu_read'),
(827, 6, 214, 1, 'menu_read'),
(828, 7, 214, 1, 'menu_read'),
(829, 1, 8, 1, 'content_read'),
(830, 2, 8, 1, 'content_read'),
(831, 3, 8, 1, 'content_read'),
(832, 4, 8, 1, 'content_read'),
(833, 5, 8, 1, 'content_read'),
(834, 6, 8, 1, 'content_read'),
(835, 7, 8, 1, 'content_read'),
(836, 1, 215, 1, 'menu_read'),
(837, 2, 215, 1, 'menu_read'),
(838, 3, 215, 1, 'menu_read'),
(839, 4, 215, 1, 'menu_read'),
(840, 5, 215, 1, 'menu_read'),
(841, 6, 215, 1, 'menu_read'),
(842, 7, 215, 1, 'menu_read'),
(974, 3, 43, 1, 'block_read'),
(973, 3, 1, 1, 'addon_read'),
(972, 3, 7, 1, 'addon_read'),
(873, 7, 209, 1, 'menu_read'),
(872, 6, 209, 1, 'menu_read'),
(871, 5, 209, 1, 'menu_read'),
(870, 4, 209, 1, 'menu_read'),
(869, 3, 209, 1, 'menu_read'),
(868, 2, 209, 1, 'menu_read'),
(867, 1, 209, 1, 'menu_read'),
(860, 1, 3, 1, 'content_read'),
(861, 2, 3, 1, 'content_read'),
(862, 3, 3, 1, 'content_read'),
(863, 4, 3, 1, 'content_read'),
(864, 5, 3, 1, 'content_read'),
(865, 6, 3, 1, 'content_read'),
(866, 7, 3, 1, 'content_read'),
(874, 1, 42, 1, 'block_read'),
(875, 1, 42, 1, 'block_read'),
(876, 2, 42, 1, 'block_read'),
(877, 2, 42, 1, 'block_read'),
(878, 4, 42, 1, 'block_read'),
(879, 5, 42, 1, 'block_read'),
(880, 6, 42, 1, 'block_read'),
(881, 1, 43, 1, 'block_read'),
(882, 1, 43, 1, 'block_read'),
(883, 2, 43, 1, 'block_read'),
(884, 2, 43, 1, 'block_read'),
(885, 4, 43, 1, 'block_read'),
(886, 5, 43, 1, 'block_read'),
(887, 6, 43, 1, 'block_read'),
(888, 1, 44, 1, 'block_read'),
(889, 1, 44, 1, 'block_read'),
(890, 2, 44, 1, 'block_read'),
(891, 2, 44, 1, 'block_read'),
(892, 4, 44, 1, 'block_read'),
(893, 5, 44, 1, 'block_read'),
(894, 6, 44, 1, 'block_read'),
(895, 1, 45, 1, 'block_read'),
(896, 1, 45, 1, 'block_read'),
(897, 2, 45, 1, 'block_read'),
(898, 2, 45, 1, 'block_read'),
(899, 4, 45, 1, 'block_read'),
(900, 5, 45, 1, 'block_read'),
(901, 6, 45, 1, 'block_read'),
(902, 1, 46, 1, 'block_read'),
(903, 1, 46, 1, 'block_read'),
(904, 2, 46, 1, 'block_read'),
(905, 2, 46, 1, 'block_read'),
(906, 4, 46, 1, 'block_read'),
(907, 5, 46, 1, 'block_read'),
(908, 6, 46, 1, 'block_read'),
(909, 1, 47, 1, 'block_read'),
(910, 1, 47, 1, 'block_read'),
(911, 2, 47, 1, 'block_read'),
(912, 2, 47, 1, 'block_read'),
(913, 4, 47, 1, 'block_read'),
(914, 5, 47, 1, 'block_read'),
(915, 6, 47, 1, 'block_read'),
(916, 1, 48, 1, 'block_read'),
(917, 1, 48, 1, 'block_read'),
(918, 2, 48, 1, 'block_read'),
(919, 2, 48, 1, 'block_read'),
(920, 4, 48, 1, 'block_read'),
(921, 5, 48, 1, 'block_read'),
(922, 6, 48, 1, 'block_read'),
(923, 1, 49, 1, 'block_read'),
(924, 1, 49, 1, 'block_read'),
(925, 2, 49, 1, 'block_read'),
(926, 2, 49, 1, 'block_read'),
(927, 4, 49, 1, 'block_read'),
(928, 5, 49, 1, 'block_read'),
(929, 6, 49, 1, 'block_read'),
(930, 1, 50, 1, 'block_read'),
(931, 1, 50, 1, 'block_read'),
(932, 2, 50, 1, 'block_read'),
(933, 2, 50, 1, 'block_read'),
(934, 4, 50, 1, 'block_read'),
(935, 5, 50, 1, 'block_read'),
(936, 6, 50, 1, 'block_read'),
(937, 1, 51, 1, 'block_read'),
(938, 1, 51, 1, 'block_read'),
(939, 2, 51, 1, 'block_read'),
(940, 2, 51, 1, 'block_read'),
(941, 4, 51, 1, 'block_read'),
(942, 5, 51, 1, 'block_read'),
(943, 6, 51, 1, 'block_read'),
(944, 1, 52, 1, 'block_read'),
(945, 1, 52, 1, 'block_read'),
(946, 2, 52, 1, 'block_read'),
(947, 2, 52, 1, 'block_read'),
(948, 4, 52, 1, 'block_read'),
(949, 5, 52, 1, 'block_read'),
(950, 6, 52, 1, 'block_read'),
(951, 1, 53, 1, 'block_read'),
(952, 1, 53, 1, 'block_read'),
(953, 2, 53, 1, 'block_read'),
(954, 2, 53, 1, 'block_read'),
(955, 4, 53, 1, 'block_read'),
(956, 5, 53, 1, 'block_read'),
(957, 6, 53, 1, 'block_read'),
(958, 1, 54, 1, 'block_read'),
(959, 1, 54, 1, 'block_read'),
(960, 2, 54, 1, 'block_read'),
(961, 2, 54, 1, 'block_read'),
(962, 4, 54, 1, 'block_read'),
(963, 5, 54, 1, 'block_read'),
(964, 6, 54, 1, 'block_read'),
(965, 1, 55, 1, 'block_read'),
(966, 1, 55, 1, 'block_read'),
(967, 2, 55, 1, 'block_read'),
(968, 2, 55, 1, 'block_read'),
(969, 4, 55, 1, 'block_read'),
(970, 5, 55, 1, 'block_read'),
(971, 6, 55, 1, 'block_read');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_group_permission_seq`
--

CREATE TABLE `cztsd_group_permission_seq` (
  `id` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_group_permission_seq`
--

INSERT INTO `cztsd_group_permission_seq` (`id`) VALUES
(1075);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_imgset`
--

CREATE TABLE `cztsd_imgset` (
  `imgset_id` smallint(5) unsigned NOT NULL auto_increment,
  `imgset_name` varchar(50) NOT NULL default '',
  `imgset_refid` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`imgset_id`),
  KEY `imgset_refid` (`imgset_refid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_imgset`
--

INSERT INTO `cztsd_imgset` (`imgset_id`, `imgset_name`, `imgset_refid`) VALUES
(1, 'default', 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_imgsetimg`
--

CREATE TABLE `cztsd_imgsetimg` (
  `imgsetimg_id` mediumint(8) unsigned NOT NULL auto_increment,
  `imgsetimg_file` varchar(50) NOT NULL default '',
  `imgsetimg_body` blob NOT NULL,
  `imgsetimg_imgset` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`imgsetimg_id`),
  KEY `imgsetimg_imgset` (`imgsetimg_imgset`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_imgsetimg`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_imgset_tplset_link`
--

CREATE TABLE `cztsd_imgset_tplset_link` (
  `imgset_id` smallint(5) unsigned NOT NULL default '0',
  `tplset_name` varchar(50) NOT NULL default '',
  KEY `tplset_name` (`tplset_name`(10))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_imgset_tplset_link`
--

INSERT INTO `cztsd_imgset_tplset_link` (`imgset_id`, `tplset_name`) VALUES
(1, 'default');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_languages`
--

CREATE TABLE `cztsd_languages` (
  `id` int(11) NOT NULL auto_increment,
  `sname` char(2) NOT NULL default '',
  `fname` varchar(20) NOT NULL default '',
  `flag` text NOT NULL,
  `enabled` int(1) NOT NULL default '0',
  `visible` int(1) NOT NULL default '0',
  `path` text NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `sname` (`sname`),
  UNIQUE KEY `fname` (`fname`),
  KEY `enabled` (`enabled`),
  KEY `visible` (`visible`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_languages`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_language_base`
--

CREATE TABLE `cztsd_language_base` (
  `lang_id` int(8) unsigned NOT NULL auto_increment,
  `weight` int(4) NOT NULL default '1',
  `lang_name` varchar(255) NOT NULL default '',
  `lang_desc` varchar(255) NOT NULL default '',
  `lang_code` varchar(255) NOT NULL default '',
  `lang_charset` varchar(255) NOT NULL default '',
  `lang_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`lang_id`),
  KEY `lang_name` (`lang_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_language_base`
--

INSERT INTO `cztsd_language_base` (`lang_id`, `weight`, `lang_name`, `lang_desc`, `lang_code`, `lang_charset`, `lang_image`) VALUES
(2, 1, 'english', 'English', 'en', 'UTF-8', 'english.gif');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_language_base_lang_id_seq`
--

CREATE TABLE `cztsd_language_base_lang_id_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_language_base_lang_id_seq`
--

INSERT INTO `cztsd_language_base_lang_id_seq` (`id`) VALUES
(2);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_language_ext`
--

CREATE TABLE `cztsd_language_ext` (
  `lang_id` int(8) unsigned NOT NULL auto_increment,
  `weight` int(4) NOT NULL default '1',
  `lang_name` varchar(255) NOT NULL default '',
  `lang_desc` varchar(255) NOT NULL default '',
  `lang_code` varchar(255) NOT NULL default '',
  `lang_charset` varchar(255) NOT NULL default '',
  `lang_image` varchar(255) NOT NULL default '',
  `lang_base` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`lang_id`),
  KEY `lang_name` (`lang_name`),
  KEY `lang_base` (`lang_base`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_language_ext`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_category`
--

CREATE TABLE `cztsd_lt_category` (
  `category_id` mediumint(8) NOT NULL auto_increment,
  `category_pid` mediumint(8) NOT NULL default '0',
  `category_sid` mediumint(3) NOT NULL default '0',
  `category_title` varchar(150) NOT NULL default '',
  `category_description` text NOT NULL,
  `category_image` varchar(150) NOT NULL default '',
  `category_weight` tinyint(1) NOT NULL default '0',
  `category_display` tinyint(1) NOT NULL default '1',
  `category_published` int(11) NOT NULL default '0',
  `category_imageside` varchar(4) NOT NULL default 'left',
  `category_type` varchar(10) NOT NULL default '',
  `category_header` varchar(150) NOT NULL default '',
  `category_footer` varchar(150) NOT NULL default '',
  `category_body` text NOT NULL,
  UNIQUE KEY `category_id` (`category_id`),
  KEY `category_title` (`category_display`,`category_published`,`category_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_category`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_content`
--

CREATE TABLE `cztsd_lt_content` (
  `content_id` int(11) unsigned NOT NULL auto_increment,
  `content_sid` int(11) unsigned NOT NULL default '0',
  `content_cid` int(11) unsigned NOT NULL default '0',
  `content_uid` int(11) unsigned NOT NULL default '0',
  `content_alias` varchar(100) NOT NULL default '',
  `content_created` int(11) unsigned NOT NULL default '0',
  `content_published` int(11) unsigned NOT NULL default '0',
  `content_updated` int(11) unsigned NOT NULL default '0',
  `content_expired` int(11) unsigned NOT NULL default '0',
  `content_title` varchar(100) NOT NULL default '',
  `content_subtitle` varchar(100) NOT NULL default '',
  `content_intro` text NOT NULL,
  `content_body` mediumtext NOT NULL,
  `content_images` text NOT NULL,
  `content_summary` text NOT NULL,
  `content_counter` int(11) NOT NULL default '0',
  `content_type` varchar(10) NOT NULL default 'static',
  `content_hits` int(11) NOT NULL default '0',
  `content_version` decimal(3,2) NOT NULL default '0.00',
  `content_approved` smallint(1) NOT NULL default '0',
  `content_meta` text NOT NULL,
  `content_keywords` text NOT NULL,
  `content_weight` tinyint(5) NOT NULL default '0',
  `content_display` tinyint(1) NOT NULL default '1',
  `content_spotlight` tinyint(1) NOT NULL default '0',
  `content_spotlightmain` tinyint(1) NOT NULL default '0',
  `content_status` int(11) NOT NULL,
  PRIMARY KEY  (`content_id`),
  KEY `idx_sid` (`content_sid`),
  KEY `idx_cid` (`content_cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_content`
--

INSERT INTO `cztsd_lt_content` (`content_id`, `content_sid`, `content_cid`, `content_uid`, `content_alias`, `content_created`, `content_published`, `content_updated`, `content_expired`, `content_title`, `content_subtitle`, `content_intro`, `content_body`, `content_images`, `content_summary`, `content_counter`, `content_type`, `content_hits`, `content_version`, `content_approved`, `content_meta`, `content_keywords`, `content_weight`, `content_display`, `content_spotlight`, `content_spotlightmain`, `content_status`) VALUES
(1, 0, 0, 0, '', 0, 1192787950, 0, 0, 'Pokalbiai', '??ia galite pasikalb?ti su SkyCommunity komanda', '', '<iframe marginwidth="0" marginheight="0" src="http://chat.skycommunity.lt/irc.cgi?interface=nonjs&amp;Nickname={X_USERNAME}&amp;Server=irc.le.lt&amp;Channel=skycommunity&amp;Format=skycomblue" frameborder="0" width="653" scrolling="no" height="490">J?s? nar??ykl? nepalaiko r?meli?</iframe>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(2, 0, 0, 0, '', 0, 1193000804, 0, 0, 'Tinkle', '?dom?s nemokami dalykai tinkle', '', '<p>Internete galima rasti i??ties daug ?domi? dalyk?. Ta??iau rasti kažk? vertingo tarp daugyb?s bever??i? dalyk? yra i??ties nepaprasta ??? informacijos kiekis milžini??kas. Tenka sugai??ti nemažai laiko  j? beie??kant. Bet jei laiko paie??koms n?ra, o noras rasti ?domi? ir verting? dalyk? yra gana didelis? Šiuo tikslu mes ir suk?r?me ??? skyrel?, ? kuri? sud?jome, m?s? nuomone ?domiausias/vertingiausias internetines paslaugas, bei tinklalapius. </p><ul class="links"><li id="link_data_exchange"><a href="index.php?page_type=static&id=6">Duomen? mainai</a></li><li id="link_chat"><a href="index.php?page_type=static&id=8">Bendravimas</a></li><li id="link_games"><a href="index.php?page_type=static&id=4">Žaidimai</a></li><li id="link_tv"><a href="index.php?page_type=static&id=7">Televizija</a></li><li id="link_radio"><a href="index.php?page_type=static&id=5">Radijas</a></li></ul>', 'blank.png', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(3, 0, 0, 0, '', 0, 1193648129, 0, 0, 'Apie mus', 'Kas yra ta SkyCommunity?', '', '<p>SkyCommunity - tai pla??iajuos??io interneto <a target="_blank" href="http://www.skynet.lt">SkyNet</a> vartotoj? bendruomen?. Šios bendruomen?s ??irdis - <a href="http://www.skycommunity.lt">SkyCommunity</a> tinklalapis su j? priži?rin??iu kolektyvu, kuris stengiasi pateikti kuo daugiau ?domi? žini? apie <a target="_blank" href="http://www.skynet.lt">SkyNet</a> tinklo poky??ius, naujas paslaugas, bei kitus su ??iuo tinklu susijusius ?vykius, pateikti informacij? apie nemokamus vertingus tinklo resursus, o taip pat pad?ti naujiems nekomerciniams projektams, kurie gal?t? b?ti naudingi ne tik j? autoriams, tapti ne tik id?jomis ant popieriaus, bet ir realybe - t.y. patarti i??kilusiais klausimais, duoti reikaling? technin? palaikym? vieno ar kito sprendimo ?gyvendinimui. Ta??iau tai nerei??kia, kad SkyCommunity yra tik kažkokia virtuali bendruomen? - ji yra gyva - kartas nuo karto vyksta ir gyvi susitikimai... :)<br /></p><p>Nors SkyCommunity id?ja paremta UAB "Penkiu komunikaciju centro" teikiama pla??iajuos??io interneto <a target="_blank" href="http://www.skynet.lt">SkyNet</a> paslauga, ta??iau tai nerei??kia, kad ??i bendruomen? yra kažkieno nuosavyb?, o ??is tinklalapis yra kuriamas tik kažkokios ?mon?s darbuotoj?. Tai tik rei??kia, kad patys ??io tinklo vartotojai yra jo paslaug? k?r?jai. Juk kas daugiau jei ne jie žino, koki? nemokam? paslaug? jiems reikia, kaip jos tur?t? b?ti ?gyvendintos... Kitaip tariant ??ios internetin?s bendruomen?s id?jos autoriai yra paprasti <a target="_blank" href="http://www.skynet.lt">SkyNet</a> tinklo vartotojai, kuriems niekas nemoka už j? tri?s? bei vargus - vis? tai jie daro tik d?l savo malonumo. Kita vertus kol kas SkyCommunity projektai naudojasi UAB "Penki? komunikacij? centro" teikiamomis technin?mis galimyb?mis - UAB "Penki? komunikacij? centras" SkyCommunity id?jas tiesiogiai remia.<br /></p><p>Kiekvienas(-a) norintis prisijungti prie   <a href="http://www.skycommunity.lt">SkyCommunity</a> ar kokio nors kito SkyCommunity globojamo projekto, gali tai padaryti - užtenka susisiekti su <a href="http://www.skycommunity.lt">SkyCommunity</a> komanda ir papasakoti apie savo mintis, id?jas, planus... Visa tai neturi b?ti b?tinai susij? su kompiuteriais ar internetu - sri??i? yra i??ties daugyb?. Svarbu nor?ti kažk? daryti ir neting?ti... :-) O susisiekti su mumis galima apsilankius tinklalapio pokalbi? skyrelyje arba para??ius lai??ka adresu <a href="mailto:info@skycommunity.lt">info@skycommunity.lt</a>.</p>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(9, 0, 0, 0, '', 0, 0, 0, 0, 'testxxx', 'aaaa', '', '<div class="info">     Visi žemiau i??vardinti punktai - tai tinklalapio taisykl?s. Nor?dami užsiregistruoti turite su jomis sutikti. O jeigu sutikus ateityje, kuri? nors taisykl? pažeisite, gali sulaukti bausm?s. <br /><br /><strong>Terminai</strong><ol><li>Lankytojas - asmuo, užsuk?s ? tinklalap?.</li><li>Registruotas vartotojas - vartotojas, kuris užsiregistravo ??iame tinklalapyje.</li><li>Vartotoj? grup? - tai registruotot? vartotoj? grup? turinti tam tikras teises.</li><li>Administracija - žmoni? priži?rin??i? ??i? svetain? komanda.</li><li>Skycommunity.lt projektas - projektas, kuris yra globojamas SkyCommunity.lt kolektyvo.</li></ol><strong>Registruot? vartotoj? teis?s bei ?sipareigojimai:</strong><ol><li>Kiekvienas tinklalapio lankytojas gali b?ti registruotu jo vartotoju.</li><li>Kiekvienas registruotas vartotojas gali priklausyti kuri? nors i?? tinklalapyje esan??i? vartotoj? grupi?.</li><li>Registruotas vartotojas turi teis? naudotis papildomomis svetain?s galimyb?mis (pvz. komentavimu).</li><li>Registruotas vartotojas už prasižengimus gali prarasti galimyb? naudotis papildomomis tinklalapio paslaugomis.</li></ol><strong>Administracijos teis?s ir ?pareigojimai:</strong><ol><li>Trinti komentarus, ar kit? vartotoj? sukurt? svetain?s turin?, kuris pažeidžia taisykles.</li><li>Redaguoti komentarus, kurie dalinai pažeidžia turin?.</li><li>Bausti registruotus vartotojus, už j? prasižengimus.</li><li>Bet kada keisti tinklalapio taisykles apie tai prie?? tai paskelbus vie??ai.</li><li>Administracija neprisiima jokios teisin?s atsakomyb?s už vartotoj? turin?, kuris pažeidin?ja ?statymus.</li></ol><strong>Draudžiama:</strong><ol><li>Keiktis.</li><li>Kitus ?žeidin?ti, ty??iotis, kurstyti neapykant?.</li><li>Skelbti tiesiogines nuorodas ? piratin? intelektualin? produkcij?.</li><li>Ra??yti internetini? žaidim? adresus, kuriuos nuspaud? kiti vartotojai uždirbt? nuorodos savininkui ta??k? žaidime.</li><li>Floodinti (pvz. ra??yti visi??kai ne ? tem? atsakymus/komentarus).</li><li>Reklamuoti svetaines, produktus, be svetain?s administracijos žinios.</li><li>Skelbti klaiding? informacij?.</li><li>Bet k?, kas pažeidžia LR ?statymus.</li></ol><strong>SkyCommunity.lt projektai:</strong><br /></div><ol><li>SkyCommunity.lt komanda neprisiima pilnos atsakomyb?s už j? turin?.</li><li>Kiekvienas projektas j? savininkams pageidaujant, bei neprie??taraujant nei vienam i?? esam? SkyCommunity.lt komandos nari?, gali tapti nauju SkyCommunity.lt projektu.</li><li>Kiekvienas??SkyCommunity.lt projektas gali tur?ti papildom? taisykli?, kuri? taip pat reikia laikytis. </li><li>Visos ??ia i??vardintos taisykl?s galioja ir SkyCommunity.lt projektams.</ol>', '', '', 0, 'static', 0, 1.00, 0, '', '', 0, 1, 0, 0, 0),
(4, 0, 0, 0, '', 0, 1193577193, 0, 0, 'Tinkle', 'Žaidimai', '', '<p>Po sunki? dienos darb? kartais b?na  visai neblogai ??iek tiek pails?ti - pažaisti žaidimus... o dar geriau ne vienam  o su draugais!.. :-) Žemiau esantis s?ra??as tur?t? pad?ti susirasti žaidim? serverius, kurie veikia SkyNet tinkle ir yra skirti vie??am naudojimui.</p><table border="0" class="links"><tbody><tr><th width="16"><div class="hidden">T</div></th><th width="23%">Pavadinimas</th><th width="19%">Žanras</th><th width="19%">Statistika</th><th width="36%">Apra??ymas</th></tr><tr align="left" valign="top"><td>{special:web}</td><td><a href="http://www.chess.lt" target="_blank">Chess.lt</a></td><td>Internetinis žaidimas</td><td><a href="http://www.chess.lt" target="_blank">www.chess.lt</a></td><td>Internetinis ??achmat? žaidimas su detalia bendra žaidim? bei žaid?j? statistika. Norint žaisti b?tina registracija.</td></tr><tr align="left" valign="top"><td>{game:cs}</td><td><a href="steam://connect/cs.wfan.lt:27015">cs.torrent.lt CSDM</a></td><td rowspan="2">Pirmo asmens ??audykl?</td><td rowspan="2"><a href="http://cs.skycommunity.lt/">cs.skycommunity.lt</a></td><td rowspan="2">Pirmo asmens ??audykl?, kurioje kovoja skirtinguose žem?lapiuose dvi komandos       - teroristai, bei teroristin?s saugumo paj?gos. </td></tr><tr align="left" valign="top"><td>{game:cs}</td><td><a href="steam://connect/212.122.67.33:27015">cs.skycommunity.lt CSDM</a></td></tr></tbody></table>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(5, 0, 0, 0, '', 0, 1193577461, 0, 0, 'Tinkle', 'Radijas', '', '<p>Bedirbant ar besiilsint neblogai b?na kartais ir pasiklausyti radijo. Bet k? daryti kai jo n?ra ??alia, o yra tik kompiuteris prijungtas prie interneto? Žinoma,??galima??juk??klausytis??radijos??internetu!</p><table border="0" class="links"><tbody><tr><th width="16"><div class="hidden">T</div></th><th>Pavadinimas</th><th>Dažnis</th><th>Kokyb?</th><th>Apra??ymas</th></tr><tr align="left" valign="top"><td>{stream:wm}</td><td><a href="http://84.46.204.45/sfm.asx"><a href="http://mms.skynet.lt/SuperFM.asx">SuperFM</a></td><td>99.7 MHz</td><td>40 Kbps stereo</td><td>Keli? met? senumo populiarieji muzikiniai hitai.</td></tr><tr align="left" valign="top"><td>{stream:wm}</td><td><a href="http://84.46.204.45/ehr.asx"><a href="http://mms.skynet.lt/EHR.asx"> European Hit Radio</a></td><td>104.7 MHz</td><td>40 Kbps stereo</td><td>Šiuo metu ?vairi? top''? vir???n?se karaliaujanti muzika.</td></tr><tr align="left" valign="top"><td>{stream:wm}</td><td><a href="http://mms.skynet.lt/PHR.asx"> Power Hit Radio</a></td><td>95.9 MHz</td><td>40 Kbps stereo</td><td>Rap, bei ??oki? muzikos kryptis atstovaujanti radijo stotis.</td></tr><tr align="left" valign="top"><td>{stream:wm}</td><td><a href="http://mms.skynet.lt/JazzFM.asx">JazzFM</a></td><td>99.3 MHz</td><td>40 Kbps stereo</td><td>Tik jazz''as ir nieko daugiau...</td></tr></tbody></table>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(6, 0, 0, 0, '', 0, 1193577344, 0, 0, 'Tinkle', 'Duomen? mainai', '', '<p>Kartais su draugais... na i??ties? ne tik draugais... prireikia apsikeisti kokiais nors skaitmeniniais duomenimis. Bet kaip tai padaryti? Ypa?? jei duomen? kiekiai yra labai dideli arba reikia juos padalinti dideliam vartotoj? kiekiui? Paprastas elektroninis pa??tas tokiu atveju jau nelabai tinka, o kurti specialius serverius tokiems atvejams gali pasirodyti per daug sud?tinga ar/ir brangu. Tod?l galima pasinaudoti nemokamomis duomen? keitimosi sistemomis. Dal? j? galima rasti ir SkyNet tinkle - belieka tik pasirinkti sau patinkan??i?... :-)</p><table width="100%" border="0" class="lists"><tbody><tr><th width="16"><div class="hidden">T</div></th><th>Pavadinimas</th><th>Apra??ymas</th></tr><tr align="left" valign="top"><td>{special:web}</td><td><a href="http://ipix.lt" target="_blank">iPix.lt</a></td><td>Paveiksl?li? internete talpinimo sistema. Paveiksl?lius galima talpinti       tiek prisiregistravus, tiek ir ne. </td></tr><tr align="left" valign="top"><td>{p2p:bittorrent}</td><td><a href="http://skytorrents.skynet.lt" target="_blank">SkyTorrents</a></td><td>BitTorent protokolu paremta fail? manin? sistema. Registracija b?tina.</td></tr><tr align="left" valign="top"><td>{p2p:dc}</td><td><a href="http://dc.skycommunity.lt">dc.skycommunity.lt</a></td><td>DC++ paremta fail? main? sistema. Galima netik patogiai ie??koti fail?, bet ir       bendrauti realiu laiku tekstin?mis žinut?ms su daugybe kit? vartotoj?.</td></tr><tr align="left" valign="top"><td>{p2p:emule}</td><td><a href="http://www.emule.skynet.lt">emule.skynet.lt</a></td><td>Viskas apie eMule, kuri yra ??auni programa norint labai paprastai si?stis, bei       dalintis anonimi??kai failais. Ši fail? main? sistema, skirtingai nei DC++       ar BitTorrent yra labiau orentuota ne ? parsisiuntimo grei??ius, bet ? milžini??k?       fail? pasirinkim?.</td></tr></tbody></table><div class="note"><strong>?sp?jimas: </strong><a href="http://skycommunity.lt">SkyCommunity.lt</a> kolektyvas n?ra atsakingas už??tai,??koki???duomen???mainams??ir??kaip??naudojamos????ios??nuorodos.??Paspausdamas??ant??nuorodos??tinklalapio vartotojas??sutinka,??kad??tik??jis??yra??atsakingas??už??tai,??kam????ios??nuorodos??bus??naudojamos. </div>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(7, 0, 0, 0, '', 0, 1193577409, 0, 0, 'Tinkle', 'Televizija', '', '<p>Internetu ži?r?ti televizij?? Kod?l gi ne! </p><table border="0" class="lists"><tbody><tr><th width="16"><div class="hidden">T</div></th><th>Pavadinimas</th><th>Apra??ymas</th></tr><tr align="left" valign="top"><td>{stream:vlc}</td><td><a href="http://penki.tv" target="_blank">Penki.tv</a></td><td>?vair?s skaitmeniniai TV kanalai. SkyNet vartotojams paslauga nemokama, o kitiems reikia jau mok?ti. </td></tr></tbody></table>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0),
(8, 0, 0, 0, '', 0, 1193577610, 0, 0, 'Tinkle', 'Bendravimas', '', '<p>Kartais i??ties b?na smagu pabendrauti su draugais. Kartais b?na smagu susirasti nauj? draug? bendramin??i? bendraujant. Visa tai ?manoma padaryti ir internetu - beto bendravimo b?d? yra i?? ties daug ir skirting?!</p><table border="0" class="lists"><tbody><tr><th width="16"><div class="hidden">T</div></th><th>Pavadinimas</th><th>Apra??ymas</th></tr><tr align="left" valign="top"><td>{special:email}</td><td><a href="http://webmail.penki.lt/" target="_blank">SkyNet pa??to d?žut?</a></td><td>Kiekvienas SkyNet vartotojas, jei tik pageidauja, nemokamai gauna ir sav? elektroninio       pa??to d?žut?, kuri? galima pasiekti tiek per bet koki? pa??to program? (prie??       tai j? sukonfiguravus pagal reikiamus nustatymus), arba per interneto svetain?.</td></tr><tr align="left" valign="top"><td>{special:web}</td><td><a href="http://forum.penki.lt/" target="_blank">Penki.lt forumas</a></td><td>Daugyb? ?vairiausi? tem? skirtingiems vartotoj? poreikiams, bei norams.</td></tr><tr align="left" valign="top"><td>{chat:irc}</td><td><a href="http://www.aitvaras.eu" target="_blank">Aitvaras.eu IRC tinklas</a></td><td>Tekstiniais prane??imais paremta sistema, kurioje vartotojai vieni su kitais bendrauja         taip vadinamuose pokalbi? kambariuose realiu laiku.<br /><br /> Šiame tinkle galima           rasti ir SkyCommunity kanal?, kuris, beje, yra pasiekiamas ir i?? ??io       tinklalapio pokalbi? skyrelio.</td></tr></tbody></table>', '', '', 0, 'static', 0, 1.00, 1, '', '', 0, 1, 0, 0, 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_content_seq`
--

CREATE TABLE `cztsd_lt_content_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_content_seq`
--

INSERT INTO `cztsd_lt_content_seq` (`id`) VALUES
(9);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_menus`
--

CREATE TABLE `cztsd_lt_menus` (
  `menu_id` int(11) NOT NULL default '0',
  `menu_pid` int(11) default '0',
  `menu_type` varchar(25) default NULL,
  `menu_title` varchar(100) default NULL,
  `menu_link` varchar(255) default NULL,
  `menu_image` varchar(255) default NULL,
  `menu_weight` int(3) default '0',
  `menu_mid` int(3) default '0',
  `menu_name` varchar(35) NOT NULL default '',
  `menu_sectionid` int(3) NOT NULL default '0',
  `menu_display` tinyint(1) default '0',
  `menu_target` varchar(20) default NULL,
  `menu_class` varchar(15) NOT NULL default ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_menus`
--

INSERT INTO `cztsd_lt_menus` (`menu_id`, `menu_pid`, `menu_type`, `menu_title`, `menu_link`, `menu_image`, `menu_weight`, `menu_mid`, `menu_name`, `menu_sectionid`, `menu_display`, `menu_target`, `menu_class`) VALUES
(1, 5, 'usermenu', 'User info', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 0, 0, '', 0, 1, '', '0'),
(2, 0, 'usermenu', 'Logout', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 3, 0, '', 0, 1, '', '0'),
(3, 0, 'usermenu', 'Administration', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(5, 0, 'mainmenu', 'Pagrindinis meniu', '', '', 0, 0, '', 0, 1, '', ''),
(37, 0, 'usermenu', 'Notices', '{X_SITEURL}/index.php?page_type=notifications', '', 2, 0, '', 0, 0, '', ''),
(40, 0, 'topmenu', 'Vartotojo meniu', '', '', 2, 0, '', 0, 1, '', ''),
(41, 0, 'footermenu', 'Register', '{X_SITEURL}/index.php?page_type=register', '', 0, 0, '', 0, 1, '', ''),
(42, 40, 'topmenu', 'Administravimas', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(44, 40, 'topmenu', 'Mano profilis', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 2, 0, '', 0, 1, '', ''),
(45, 40, 'topmenu', 'Prane??imai', '{X_SITEURL}/index.php?page_type=notifications', '', 3, 0, '', 0, 0, '', ''),
(47, 40, 'topmenu', 'Atsijungti', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 4, 0, '', 0, 1, '', '0');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_menus_seq`
--

CREATE TABLE `cztsd_lt_menus_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_menus_seq`
--

INSERT INTO `cztsd_lt_menus_seq` (`id`) VALUES
(216);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_profilecategory`
--

CREATE TABLE `cztsd_lt_profilecategory` (
  `profilecat_id` smallint(5) unsigned NOT NULL default '0',
  `profilecat_name` varchar(25) NOT NULL default '',
  `profilecat_order` smallint(5) unsigned NOT NULL default '0',
  `profilecat_desc` text NOT NULL,
  `profilecat_display` smallint(2) NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_profilecategory`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_rss`
--

CREATE TABLE `cztsd_lt_rss` (
  `rss_id` smallint(3) unsigned NOT NULL auto_increment,
  `rss_name` varchar(255) NOT NULL default '',
  `rss_url` varchar(255) NOT NULL default '',
  `rss_rssurl` varchar(255) NOT NULL default '',
  `rss_encoding` varchar(15) NOT NULL default '',
  `rss_cachetime` mediumint(8) unsigned NOT NULL default '3600',
  `rss_asblock` tinyint(1) unsigned NOT NULL default '0',
  `rss_display` tinyint(1) unsigned NOT NULL default '0',
  `rss_weight` smallint(3) unsigned NOT NULL default '0',
  `rss_mainfull` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainimg` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_blockimg` tinyint(1) unsigned NOT NULL default '0',
  `rss_blockmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_xml` text NOT NULL,
  `rss_updated` int(10) NOT NULL default '0',
  PRIMARY KEY  (`rss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_rss`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_section`
--

CREATE TABLE `cztsd_lt_section` (
  `section_id` mediumint(8) NOT NULL auto_increment,
  `section_title` varchar(150) NOT NULL default '',
  `section_image` varchar(150) NOT NULL default '',
  `section_weight` tinyint(1) NOT NULL default '0',
  `section_display` enum('0','1') NOT NULL default '1',
  `section_published` int(11) NOT NULL default '0',
  `section_imageside` varchar(4) NOT NULL default 'left',
  `section_description` text NOT NULL,
  `section_type` varchar(10) NOT NULL default '',
  `section_is` tinyint(1) NOT NULL default '1',
  UNIQUE KEY `section_id` (`section_id`),
  KEY `section_title` (`section_display`,`section_published`,`section_weight`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_section`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_section_seq`
--

CREATE TABLE `cztsd_lt_section_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_section_seq`
--

INSERT INTO `cztsd_lt_section_seq` (`id`) VALUES
(3);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_stories`
--

CREATE TABLE `cztsd_lt_stories` (
  `storyid` int(8) unsigned NOT NULL default '0',
  `uid` int(5) unsigned NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `created` int(10) unsigned NOT NULL default '0',
  `published` int(10) unsigned NOT NULL default '0',
  `expired` int(10) unsigned NOT NULL default '0',
  `hostname` varchar(20) NOT NULL default '',
  `nohtml` tinyint(1) NOT NULL default '0',
  `nosmiley` tinyint(1) NOT NULL default '0',
  `hometext` text NOT NULL,
  `bodytext` text NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `counter` int(8) unsigned NOT NULL default '0',
  `topicid` smallint(4) unsigned NOT NULL default '1',
  `ihome` tinyint(1) NOT NULL default '0',
  `notifypub` tinyint(1) NOT NULL default '0',
  `story_type` varchar(5) NOT NULL default '',
  `topicdisplay` tinyint(1) NOT NULL default '0',
  `topicalign` char(1) NOT NULL default 'R',
  `comments` smallint(5) unsigned NOT NULL default '0',
  `rating` double(6,4) NOT NULL default '0.0000',
  `votes` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_stories`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_stories_files`
--

CREATE TABLE `cztsd_lt_stories_files` (
  `fileid` int(8) unsigned NOT NULL auto_increment,
  `filerealname` varchar(255) NOT NULL default '',
  `storyid` int(8) unsigned NOT NULL default '0',
  `date` int(10) NOT NULL default '0',
  `mimetype` varchar(64) NOT NULL default '',
  `downloadname` varchar(255) NOT NULL default '',
  `counter` int(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`fileid`),
  KEY `storyid` (`storyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_stories_files`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_stories_storyid_seq`
--

CREATE TABLE `cztsd_lt_stories_storyid_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_stories_storyid_seq`
--

INSERT INTO `cztsd_lt_stories_storyid_seq` (`id`) VALUES
(5);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_stories_votedata`
--

CREATE TABLE `cztsd_lt_stories_votedata` (
  `ratingid` int(11) unsigned NOT NULL auto_increment,
  `storyid` int(8) unsigned NOT NULL default '0',
  `ratinguser` int(11) NOT NULL default '0',
  `rating` tinyint(3) unsigned NOT NULL default '0',
  `ratinghostname` varchar(60) NOT NULL default '',
  `ratingtimestamp` int(10) NOT NULL default '0',
  PRIMARY KEY  (`ratingid`),
  KEY `ratinguser` (`ratinguser`),
  KEY `ratinghostname` (`ratinghostname`),
  KEY `storyid` (`storyid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_stories_votedata`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_topics`
--

CREATE TABLE `cztsd_lt_topics` (
  `topic_id` smallint(4) unsigned NOT NULL default '0',
  `topic_pid` smallint(4) unsigned NOT NULL default '0',
  `topic_imgurl` varchar(20) NOT NULL default '',
  `topic_title` varchar(255) NOT NULL,
  `menu` tinyint(1) NOT NULL default '0',
  `topic_frontpage` tinyint(1) NOT NULL default '1',
  `topic_rssurl` varchar(255) NOT NULL default '',
  `topic_description` text NOT NULL,
  `topic_color` varchar(6) NOT NULL default '000000',
  KEY `topic_title` (`topic_title`),
  KEY `menu` (`menu`),
  KEY `topic_title_2` (`topic_title`),
  KEY `menu_2` (`menu`),
  KEY `topic_title_3` (`topic_title`),
  KEY `menu_3` (`menu`),
  KEY `topic_title_4` (`topic_title`),
  KEY `menu_4` (`menu`),
  KEY `topic_title_5` (`topic_title`),
  KEY `menu_5` (`menu`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_topics`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_lt_topics_topic_id_seq`
--

CREATE TABLE `cztsd_lt_topics_topic_id_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_lt_topics_topic_id_seq`
--

INSERT INTO `cztsd_lt_topics_topic_id_seq` (`id`) VALUES
(5);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_media`
--

CREATE TABLE `cztsd_media` (
  `media_id` mediumint(8) unsigned NOT NULL auto_increment,
  `media_name` varchar(30) NOT NULL default '',
  `media_nicename` varchar(255) NOT NULL default '',
  `media_ext` varchar(4) NOT NULL default '',
  `media_caption` text NOT NULL,
  `media_mimetype` varchar(30) NOT NULL default '',
  `media_created` int(10) unsigned NOT NULL default '0',
  `media_display` tinyint(1) unsigned NOT NULL default '0',
  `media_weight` smallint(5) unsigned NOT NULL default '0',
  `media_cid` smallint(5) unsigned NOT NULL default '0',
  `media_dirname` varchar(255) NOT NULL default 'uploads',
  `media_uid` tinyint(4) NOT NULL default '0',
  `media_filesize` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`media_id`),
  KEY `media_cid` (`media_cid`),
  KEY `media_display` (`media_display`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_media`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_mediacategory`
--

CREATE TABLE `cztsd_mediacategory` (
  `media_cid` smallint(5) unsigned NOT NULL auto_increment,
  `media_ctitle` varchar(100) NOT NULL default '',
  `media_cmaxsize` int(8) unsigned NOT NULL default '0',
  `media_cmaxwidth` smallint(3) unsigned NOT NULL default '0',
  `media_cmaxheight` smallint(3) unsigned NOT NULL default '0',
  `media_cdisplay` tinyint(1) unsigned NOT NULL default '0',
  `media_cweight` smallint(3) unsigned NOT NULL default '0',
  `media_ctype` char(1) NOT NULL default '',
  `media_cdirname` varchar(255) NOT NULL default 'uploads',
  `media_cdescription` text NOT NULL,
  `media_cupdated` int(11) NOT NULL default '0',
  `media_cprefix` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`media_cid`),
  KEY `media_cdisplay` (`media_cdisplay`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_mediacategory`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_menus`
--

CREATE TABLE `cztsd_menus` (
  `menu_id` int(11) NOT NULL auto_increment,
  `menu_pid` int(11) default '0',
  `menu_type` varchar(25) default NULL,
  `menu_title` varchar(100) default NULL,
  `menu_link` varchar(255) default NULL,
  `menu_image` varchar(255) default NULL,
  `menu_weight` int(3) default '0',
  `menu_mid` int(3) default '0',
  `menu_name` varchar(35) NOT NULL default '',
  `menu_sectionid` int(3) NOT NULL default '0',
  `menu_display` tinyint(1) default '0',
  `menu_target` varchar(20) default NULL,
  `menu_class` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`menu_id`),
  KEY `menu_type` (`menu_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=48 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_menus`
--

INSERT INTO `cztsd_menus` (`menu_id`, `menu_pid`, `menu_type`, `menu_title`, `menu_link`, `menu_image`, `menu_weight`, `menu_mid`, `menu_name`, `menu_sectionid`, `menu_display`, `menu_target`, `menu_class`) VALUES
(1, 0, 'usermenu', 'My Account', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 1, 0, '', 0, 1, '', '0'),
(2, 0, 'usermenu', 'Logout', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 3, 0, '', 0, 1, '', '0'),
(3, 0, 'usermenu', 'Administrator Area', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(5, 0, 'mainmenu', 'Home', '{X_SITEURL}', '', 0, 0, '', 0, 1, '', ''),
(6, 0, 'topmenu', 'Home', '{X_SITEURL}', '', 0, 0, '', 0, 1, '', ''),
(37, 0, 'usermenu', 'Notifications', '{X_SITEURL}/index.php?page_type=notifications', '', 2, 0, '', 0, 1, '', ''),
(40, 0, 'topmenu', 'Users Menu', '', '', 2, 0, '', 0, 1, '', ''),
(41, 0, 'footermenu', 'Register', '{X_SITEURL}/index.php?page_type=register', '', 0, 0, '', 0, 1, '', ''),
(42, 40, 'topmenu', 'Administrator Area', '{X_SITEURL}/addons/system/', '', 0, 0, '', 0, 1, '', '0'),
(44, 40, 'topmenu', 'My Account', '{X_SITEURL}/index.php?page_type=userinfo&uid={X_UID}', '', 2, 0, '', 0, 1, '', ''),
(45, 40, 'topmenu', 'Notifications', '{X_SITEURL}/index.php?page_type=notifications', '', 3, 0, '', 0, 1, '', ''),
(47, 40, 'topmenu', 'Logout', '{X_SITEURL}/index.php?page_type=user&act=logout', '', 4, 0, '', 0, 1, '', '0');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_messages`
--

CREATE TABLE `cztsd_messages` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `subject` varchar(255) NOT NULL default '',
  `from_userid` mediumint(8) unsigned NOT NULL default '0',
  `to_userid` mediumint(8) unsigned NOT NULL default '0',
  `is_trash` int(1) NOT NULL default '0',
  `is_saved` int(1) NOT NULL default '0',
  `time` int(11) unsigned NOT NULL default '0',
  `text` text NOT NULL,
  `msg` int(1) NOT NULL default '1',
  `priority` int(1) NOT NULL default '3',
  `track` int(1) NOT NULL default '0',
  `is_attachment` int(1) NOT NULL default '0',
  `attachment_type` varchar(255) NOT NULL default '',
  `trash_date` int(11) NOT NULL,
  `read_date` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `to_userid` (`to_userid`),
  KEY `msgidfromuserid` (`id`,`from_userid`),
  KEY `touseridmsg` (`to_userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_messages`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_messages_buddy`
--

CREATE TABLE `cztsd_messages_buddy` (
  `buddy_id` mediumint(8) unsigned NOT NULL auto_increment,
  `buddy_desc` varchar(255) NOT NULL,
  `buddy_owner` mediumint(8) NOT NULL,
  `buddy_uid` mediumint(8) unsigned NOT NULL default '0',
  `buddy_name` varchar(160) NOT NULL default '0',
  `buddy_allow` int(1) NOT NULL default '0',
  `buddy_date` int(11) NOT NULL,
  PRIMARY KEY  (`buddy_id`),
  KEY `to_userid` (`buddy_name`),
  KEY `msgidfromuserid` (`buddy_id`,`buddy_uid`),
  KEY `touseridmsg` (`buddy_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_messages_buddy`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_messages_sent`
--

CREATE TABLE `cztsd_messages_sent` (
  `mid` mediumint(8) unsigned NOT NULL auto_increment,
  `id` mediumint(8) unsigned NOT NULL,
  `subject` varchar(255) NOT NULL default '',
  `from_userid` mediumint(8) unsigned NOT NULL default '0',
  `to_userid` mediumint(8) unsigned NOT NULL default '0',
  `is_trash` int(1) NOT NULL default '0',
  `is_saved` int(1) NOT NULL default '0',
  `time` int(11) unsigned NOT NULL default '0',
  `text` text NOT NULL,
  `msg` int(1) NOT NULL default '1',
  `priority` int(1) NOT NULL default '3',
  `track` int(1) NOT NULL default '0',
  `is_attachment` int(1) NOT NULL default '0',
  `attachment_type` varchar(255) NOT NULL default '',
  `trash_date` int(11) NOT NULL,
  `read_date` int(11) NOT NULL,
  PRIMARY KEY  (`mid`),
  KEY `to_userid` (`to_userid`),
  KEY `touseridmsg` (`to_userid`),
  KEY `msgidfromuserid` (`mid`,`from_userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_messages_sent`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_mimetypes`
--

CREATE TABLE `cztsd_mimetypes` (
  `mime_id` int(11) NOT NULL auto_increment,
  `mime_ext` varchar(60) NOT NULL default '',
  `mime_types` text NOT NULL,
  `mime_name` varchar(255) NOT NULL default '',
  `mime_images` varchar(160) NOT NULL default '',
  `mime_safe` tinyint(1) NOT NULL default '1',
  `mime_category` smallint(8) NOT NULL default '0',
  `mime_display` tinyint(1) NOT NULL default '1',
  KEY `mime_id` (`mime_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=124 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_mimetypes`
--

INSERT INTO `cztsd_mimetypes` (`mime_id`, `mime_ext`, `mime_types`, `mime_name`, `mime_images`, `mime_safe`, `mime_category`, `mime_display`) VALUES
(1, 'bin', 'application/octet-stream', 'Binary File/Linux Executable', '', 1, 0, 1),
(2, 'dms', 'application/octet-stream', 'Amiga DISKMASHER Compressed Archive', '', 1, 0, 1),
(3, 'class', 'application/octet-stream', 'Java Bytecode', '', 1, 0, 1),
(4, 'so', 'application/octet-stream', 'UNIX Shared Library Function', '', 1, 0, 1),
(5, 'dll', 'application/octet-stream', 'Dynamic Link Library', '', 1, 0, 1),
(6, 'hqx', 'application/binhex application/mac-binhex application/mac-binhex40', 'Macintosh BinHex 4 Compressed Archive', '', 1, 0, 1),
(7, 'cpt', 'application/mac-compactpro application/compact_pro', 'Compact Pro Archive', '', 1, 0, 1),
(8, 'lha', 'application/lha application/x-lha application/octet-stream application/x-compress application/x-compressed application/maclha', 'Compressed Archive File', '', 1, 0, 1),
(9, 'lzh', 'application/lzh application/x-lzh application/x-lha application/x-compress application/x-compressed application/x-lzh-archive zz-application/zz-winassoc-lzh application/maclha application/octet-stream', 'Compressed Archive File', '', 1, 0, 1),
(10, 'sh', 'application/x-shar', 'UNIX shar Archive File', '', 1, 0, 1),
(11, 'shar', 'application/x-shar', 'UNIX shar Archive File', '', 1, 0, 1),
(12, 'tar', 'application/tar application/x-tar applicaton/x-gtar multipart/x-tar application/x-compress application/x-compressed', 'Tape Archive File', '', 1, 0, 1),
(13, 'gtar', 'application/x-gtar', 'GNU tar Compressed File Archive', '', 1, 0, 1),
(14, 'ustar', 'application/x-ustar multipart/x-ustar', 'POSIX tar Compressed Archive', '', 1, 0, 1),
(15, 'zip', 'application/zip application/x-zip application/x-zip-compressed application/octet-stream application/x-compress application/x-compressed multipart/x-zip', 'Compressed Archive File', '', 1, 0, 1),
(16, 'exe', 'application/exe application/x-exe application/dos-exe application/x-winexe application/msdos-windows application/x-msdos-program', 'Executable File', '', 1, 0, 1),
(17, 'wmz', 'application/x-ms-wmz', 'Windows Media Compressed Skin File', '', 1, 0, 1),
(18, 'wmd', 'application/x-ms-wmd', 'Windows Media Download File', '', 1, 0, 1),
(19, 'doc', 'application/msword application/doc appl/text application/vnd.msword application/vnd.ms-word application/winword application/word application/x-msw6 application/x-msword', 'Word Document', '', 1, 0, 1),
(20, 'pdf', 'application/pdf application/acrobat application/x-pdf applications/vnd.pdf text/pdf', 'Acrobat Portable Document Format', '', 1, 0, 1),
(21, 'eps', 'application/eps application/postscript application/x-eps image/eps image/x-eps', 'Encapsulated PostScript', '', 1, 0, 1),
(22, 'ps', 'application/postscript application/ps application/x-postscript application/x-ps text/postscript', 'PostScript', '', 1, 0, 1),
(23, 'smi', 'application/smil', 'SMIL Multimedia', '', 1, 0, 1),
(24, 'smil', 'application/smil', 'Synchronized Multimedia Integration Language', '', 1, 0, 1),
(25, 'wmlc', 'application/vnd.wap.wmlc ', 'Compiled WML Document', '', 1, 0, 1),
(26, 'wmlsc', 'application/vnd.wap.wmlscriptc', 'Compiled WML Script', '', 1, 0, 1),
(27, 'vcd', 'application/x-cdlink', 'Virtual CD-ROM CD Image File', '', 1, 0, 1),
(28, 'pgn', 'application/formstore', 'Picatinny Arsenal Electronic Formstore Form in TIFF Format', '', 1, 0, 1),
(29, 'cpio', 'application/x-cpio', 'UNIX CPIO Archive', '', 1, 0, 1),
(30, 'csh', 'application/x-csh', 'Csh Script', '', 1, 0, 1),
(31, 'dcr', 'application/x-director', 'Shockwave Movie', '', 1, 0, 1),
(32, 'dir', 'application/x-director', 'Macromedia Director Movie', '', 1, 0, 1),
(33, 'dxr', 'application/x-director application/vnd.dxr', 'Macromedia Director Protected Movie File', '', 1, 0, 1),
(34, 'dvi', 'application/x-dvi', 'TeX Device Independent Document', '', 1, 0, 1),
(35, 'spl', 'application/x-futuresplash', 'Macromedia FutureSplash File', '', 1, 0, 1),
(36, 'hdf', 'application/x-hdf', 'Hierarchical Data Format File', '', 1, 0, 1),
(37, 'js', 'application/x-javascript text/javascript', 'JavaScript Source Code', '', 1, 0, 1),
(38, 'skp', 'application/x-koan application/vnd-koan koan/x-skm application/vnd.koan', 'SSEYO Koan Play File', '', 1, 0, 1),
(39, 'skd', 'application/x-koan application/vnd-koan koan/x-skm application/vnd.koan', 'SSEYO Koan Design File', '', 1, 0, 1),
(40, 'skt', 'application/x-koan application/vnd-koan koan/x-skm application/vnd.koan', 'SSEYO Koan Template File', '', 1, 0, 1),
(41, 'skm', 'application/x-koan application/vnd-koan koan/x-skm application/vnd.koan', 'SSEYO Koan Mix File', '', 1, 0, 1),
(42, 'latex', 'application/x-latex text/x-latex', 'LaTeX Source Document', '', 1, 0, 1),
(43, 'nc', 'application/x-netcdf text/x-cdf', 'Unidata netCDF Graphics', '', 1, 0, 1),
(44, 'cdf', 'application/cdf application/x-cdf application/netcdf application/x-netcdf text/cdf text/x-cdf', 'Channel Definition Format', '', 1, 0, 1),
(45, 'swf', 'application/x-shockwave-flash application/x-shockwave-flash2-preview application/futuresplash image/vnd.rn-realflash', 'Macromedia Flash Format File', '', 1, 0, 1),
(46, 'sit', 'application/stuffit application/x-stuffit application/x-sit', 'StuffIt Compressed Archive File', '', 1, 0, 1),
(47, 'tcl', 'application/x-tcl', 'TCL/TK Language Script', '', 1, 0, 1),
(48, 'tex', 'application/x-tex', 'LaTeX Source', '', 1, 0, 1),
(49, 'texinfo', 'application/x-texinfo', 'TeX', '', 1, 0, 1),
(50, 'texi', 'application/x-texinfo', 'TeX', '', 1, 0, 1),
(51, 't', 'application/x-troff', 'TAR Tape Archive Without Compression', '', 1, 0, 1),
(52, 'tr', 'application/x-troff', 'Unix Tape Archive = TAR without compression (tar)', '', 1, 0, 1),
(53, 'src', 'application/x-wais-source', 'Sourcecode', '', 1, 0, 1),
(54, 'xhtml', 'application/xhtml+xml', 'Extensible HyperText Markup Language File', '', 1, 0, 1),
(55, 'xht', 'application/xhtml+xml', 'Extensible HyperText Markup Language File', '', 1, 0, 1),
(56, 'au', 'audio/basic audio/x-basic audio/au audio/x-au audio/x-pn-au audio/rmf audio/x-rmf audio/x-ulaw audio/vnd.qcelp audio/x-gsm audio/snd', 'ULaw/AU Audio File', '', 1, 0, 1),
(57, 'XM', 'audio/xm audio/x-xm audio/module-xm audio/mod audio/x-mod', 'Fast Tracker 2 Extended Module', '', 1, 0, 1),
(58, 'snd', 'audio/basic', 'Macintosh Sound Resource', '', 1, 0, 1),
(59, 'mid', 'audio/mid audio/m audio/midi audio/x-midi application/x-midi audio/soundtrack', 'Musical Instrument Digital Interface MIDI-sequention Sound', '', 1, 0, 1),
(60, 'midi', 'audio/mid audio/m audio/midi audio/x-midi application/x-midi', 'Musical Instrument Digital Interface MIDI-sequention Sound', '', 1, 0, 1),
(61, 'kar', 'audio/midi audio/x-midi audio/mid x-music/x-midi', 'Karaoke MIDI File', '', 1, 0, 1),
(62, 'mpga', 'audio/mpeg audio/mp3 audio/mgp audio/m-mpeg audio/x-mp3 audio/x-mpeg audio/x-mpg video/mpeg', 'Mpeg-1 Layer3 Audio Stream', '', 1, 0, 1),
(63, 'mp2', 'video/mpeg audio/mpeg', 'MPEG Audio Stream, Layer II', '', 1, 0, 1),
(64, 'mp3', 'audio/mpeg audio/x-mpeg audio/mp3 audio/x-mp3 audio/mpeg3 audio/x-mpeg3 audio/mpg audio/x-mpg audio/x-mpegaudio', 'MPEG Audio Stream, Layer III', '', 1, 0, 1),
(65, 'aif', 'audio/aiff audio/x-aiff sound/aiff audio/rmf audio/x-rmf audio/x-pn-aiff audio/x-gsm audio/x-midi audio/vnd.qcelp', 'Audio Interchange File', '', 1, 0, 1),
(66, 'aiff', 'audio/aiff audio/x-aiff sound/aiff audio/rmf audio/x-rmf audio/x-pn-aiff audio/x-gsm audio/mid audio/x-midi audio/vnd.qcelp', 'Audio Interchange File', '', 1, 0, 1),
(67, 'aifc', 'audio/aiff audio/x-aiff audio/x-aifc sound/aiff audio/rmf audio/x-rmf audio/x-pn-aiff audio/x-gsm audio/x-midi audio/mid audio/vnd.qcelp', 'Audio Interchange File', '', 1, 0, 1),
(68, 'm3u', 'audio/x-mpegurl audio/mpeg-url application/x-winamp-playlist audio/scpls audio/x-scpls', 'MP3 Playlist File', '', 1, 0, 1),
(69, 'ram', 'audio/x-pn-realaudio audio/vnd.rn-realaudio audio/x-pm-realaudio-plugin audio/x-pn-realvideo audio/x-realaudio video/x-pn-realvideo text/plain', 'RealMedia Metafile', '', 1, 0, 1),
(70, 'rm', 'application/vnd.rn-realmedia audio/vnd.rn-realaudio audio/x-pn-realaudio audio/x-realaudio audio/x-pm-realaudio-plugin', 'RealMedia Streaming Media', '', 1, 0, 1),
(71, 'rpm', 'audio/x-pn-realaudio audio/x-pn-realaudio-plugin audio/x-pnrealaudio-plugin video/x-pn-realvideo-plugin audio/x-mpegurl application/octet-stream', 'RealMedia Player Plug-in', '', 1, 0, 1),
(72, 'ra', 'audio/vnd.rn-realaudio audio/x-pn-realaudio audio/x-realaudio audio/x-pm-realaudio-plugin video/x-pn-realvideo', 'RealMedia Streaming Media', '', 1, 0, 1),
(73, 'wav', 'audio/wav audio/x-wav audio/wave audio/x-pn-wav', 'Waveform Audio', '', 1, 0, 1),
(74, 'wax', ' audio/x-ms-wax', 'Windows Media Audio Redirector', '', 1, 0, 1),
(75, 'wma', 'audio/x-ms-wma video/x-ms-asf', 'Windows Media Audio File', '', 1, 0, 1),
(76, 'bmp', 'image/bmp image/x-bmp image/x-bitmap image/x-xbitmap image/x-win-bitmap image/x-windows-bmp image/ms-bmp image/x-ms-bmp application/bmp application/x-bmp application/x-win-bitmap application/preview', 'Windows OS/2 Bitmap Graphics', '', 1, 0, 1),
(77, 'gif', 'image/gif image/x-xbitmap image/gi_', 'Graphic Interchange Format', '', 1, 0, 1),
(78, 'ief', 'image/ief', 'Image File - Bitmap graphics', '', 1, 0, 1),
(79, 'jpeg', 'image/jpeg image/jpg image/jpe_ image/pjpeg image/vnd.swiftview-jpeg', 'JPEG/JIFF Image', '', 1, 0, 1),
(80, 'jpg', 'image/jpeg image/jpg image/jp_ application/jpg application/x-jpg image/pjpeg image/pipeg image/vnd.swiftview-jpeg image/x-xbitmap', 'JPEG/JIFF Image', '', 1, 0, 1),
(81, 'jpe', 'image/jpeg', 'JPEG/JIFF Image', '', 1, 0, 1),
(82, 'png', 'image/png application/png application/x-png', 'Portable (Public) Network Graphic', '', 1, 0, 1),
(83, 'tiff', 'image/tiff', 'Tagged Image Format File', '', 1, 0, 1),
(84, 'tif', 'image/tif image/x-tif image/tiff image/x-tiff application/tif application/x-tif application/tiff application/x-tiff', 'Tagged Image Format File', '', 1, 0, 1),
(85, 'ico', 'image/ico image/x-icon application/ico application/x-ico application/x-win-bitmap image/x-win-bitmap application/octet-stream', 'Windows Icon', '', 1, 0, 1),
(86, 'wbmp', 'image/vnd.wap.wbmp', 'Wireless Bitmap File Format', '', 1, 0, 1),
(87, 'ras', 'application/ras application/x-ras image/ras', 'Sun Raster Graphic', '', 1, 0, 1),
(88, 'pnm', 'image/x-portable-anymap', 'PBM Portable Any Map Graphic Bitmap', '', 1, 0, 1),
(89, 'pbm', 'image/portable bitmap image/x-portable-bitmap image/pbm image/x-pbm', 'UNIX Portable Bitmap Graphic', '', 1, 0, 1),
(90, 'pgm', 'image/x-portable-graymap image/x-pgm', 'Portable Graymap Graphic', '', 1, 0, 1),
(91, 'ppm', 'image/x-portable-pixmap application/ppm application/x-ppm image/x-p image/x-ppm', 'PBM Portable Pixelmap Graphic', '', 1, 0, 1),
(92, 'rgb', 'image/rgb image/x-rgb', 'Silicon Graphics RGB Bitmap', '', 1, 0, 1),
(93, 'xbm', 'image/x-xpixmap image/x-xbitmap image/xpm image/x-xpm', 'X Bitmap Graphic', '', 1, 0, 1),
(94, 'xpm', 'image/x-xpixmap', 'BMC Software Patrol UNIX Icon File', '', 1, 0, 1),
(95, 'xwd', 'image/x-xwindowdump image/xwd image/x-xwd application/xwd application/x-xwd', 'X Windows Dump', '', 1, 0, 1),
(96, 'igs', 'model/iges application/iges application/x-iges application/igs application/x-igs drawing/x-igs image/x-igs', 'Initial Graphics Exchange Specification Format', '', 1, 0, 1),
(97, 'css', 'application/css-stylesheet text/css', 'Hypertext Cascading Style Sheet', '', 1, 0, 1),
(98, 'html', 'text/html text/plain', 'Hypertext Markup Language', '', 1, 0, 1),
(99, 'htm', 'text/html', 'Hypertext Markup Language', '', 1, 0, 1),
(100, 'txt', 'text/plain application/txt browser/internal', 'Text File', '', 1, 0, 1),
(101, 'rtf', 'application/rtf application/x-rtf text/rtf text/richtext application/msword application/doc application/x-soffice', 'Rich Text Format File', '', 1, 0, 1),
(102, 'wml', 'text/vnd.wap.wml text/wml', 'Website META Language File', '', 1, 0, 1),
(103, 'wmls', 'text/vnd.wap.wmlscript', 'WML Script', '', 1, 0, 1),
(104, 'etx', 'text/x-setext', 'SetText Structure Enhanced Text', '', 1, 0, 1),
(105, 'xml', 'text/xml application/xml application/x-xml', 'Extensible Markup Language File', '', 1, 0, 1),
(106, 'xsl', 'text/xml', 'XML Stylesheet', '', 1, 0, 1),
(107, 'php', 'application/x-httpd-php text/php application/php magnus-internal/shellcgi application/x-php', 'PHP Script', '', 1, 0, 1),
(108, 'php3', 'text/php3 application/x-httpd-php', 'PHP Script', '', 1, 0, 1),
(109, 'mpeg', 'video/mpeg', 'MPEG Movie', '', 1, 0, 1),
(110, 'mpg', 'video/mpeg video/mpg video/x-mpg video/mpeg2 application/x-pn-mpg video/x-mpeg video/x-mpeg2a audio/mpeg audio/x-mpeg image/mpg', 'MPEG 1 System Stream', '', 1, 0, 1),
(111, 'mpe', 'video/mpeg', 'MPEG Movie Clip', '', 1, 0, 1),
(112, 'qt', 'video/quicktime audio/aiff audio/x-wav video/flc', 'QuickTime Movie', '', 1, 0, 1),
(113, 'mov', 'video/quicktime video/x-quicktime image/mov audio/aiff audio/x-midi audio/x-wav video/avi', 'QuickTime Video Clip', '', 1, 0, 1),
(114, 'avi', 'video/avi \r\nvideo/msvideo \r\nvideo/x-msvideo \r\nimage/avi \r\nvideo/xmpg2 \r\napplication/x-troff-msvideo \r\naudio/aiff \r\naudio/avi', 'Audio Video Interleave File', '', 1, 0, 1),
(115, 'movie', 'video/sgi-movie video/x-sgi-movie', 'QuickTime Movie', '', 1, 0, 1),
(116, 'asf', 'audio/asf application/asx video/x-ms-asf-plugin application/x-mplayer2 video/x-ms-asf application/vnd.ms-asf video/x-ms-asf-plugin video/x-ms-wm video/x-ms-wmx', 'Advanced Streaming Format', '', 1, 0, 1),
(117, 'asx', 'video/asx application/asx video/x-ms-asf-plugin application/x-mplayer2 video/x-ms-asf application/vnd.ms-asf video/x-ms-asf-plugin video/x-ms-wm video/x-ms-wmx video/x-la-asf', 'Advanced Stream Redirector File', '', 1, 0, 1),
(118, 'wmv', 'video/x-ms-wmv', 'Windows Media File', '', 1, 0, 1),
(119, 'wvx', 'video/x-ms-wvx', 'Windows Media Redirector', '', 1, 0, 1),
(120, 'wm', 'video/x-ms-wm', 'Windows Media A/V File', '', 1, 0, 1),
(121, 'wmx', 'video/x-ms-wmx', 'Windows Media Player A/V Shortcut', '', 1, 0, 1),
(122, 'ice', 'x-conference-xcooltalk', 'Cooltalk Audio', '', 1, 0, 1),
(123, 'rar', 'application/octet-stream', 'WinRAR Compressed Archive', '', 1, 0, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_newblocks`
--

CREATE TABLE `cztsd_newblocks` (
  `bid` mediumint(8) unsigned NOT NULL auto_increment,
  `mid` smallint(5) unsigned NOT NULL default '0',
  `func_num` tinyint(3) unsigned NOT NULL default '0',
  `options` varchar(255) NOT NULL default '',
  `name` varchar(150) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `side` tinyint(1) unsigned NOT NULL default '0',
  `weight` smallint(5) unsigned NOT NULL default '0',
  `block_type` char(1) NOT NULL default '',
  `c_type` char(1) NOT NULL default '',
  `isactive` tinyint(1) unsigned NOT NULL default '0',
  `dirname` varchar(50) NOT NULL default '',
  `func_file` varchar(50) NOT NULL default '',
  `show_func` varchar(50) NOT NULL default '',
  `edit_func` varchar(50) NOT NULL default '',
  `template` varchar(50) NOT NULL default '',
  `bcachetime` int(10) unsigned NOT NULL default '0',
  `last_modified` int(10) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `liveupdate` int(1) NOT NULL default '0',
  PRIMARY KEY  (`bid`,`mid`,`title`,`weight`,`side`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_newblocks`
--

INSERT INTO `cztsd_newblocks` (`bid`, `mid`, `func_num`, `options`, `name`, `title`, `content`, `side`, `weight`, `block_type`, `c_type`, `isactive`, `dirname`, `func_file`, `show_func`, `edit_func`, `template`, `bcachetime`, `last_modified`, `description`, `liveupdate`) VALUES
(53, 1, 12, '0|80', 'Themes', 'Themes', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_themes_show', 'b_system_themes_edit', 'system_block_themes.html', 0, 1194864180, 'Shows theme selection box', 0),
(52, 1, 11, '', 'Notification Options', 'Notification Options', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_notification_show', '', 'system_block_notification.html', 0, 1194864180, 'Shows notification options', 0),
(51, 1, 10, '10', 'Recent Comments', 'Recent Comments', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_comments_show', 'b_system_comments_edit', 'system_block_comments.html', 0, 1194864180, 'Shows most recent comments', 0),
(49, 1, 8, '10|0', 'Top Posters', 'Top Posters', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_topposters_show', 'b_system_topposters_edit', 'system_block_topusers.html', 0, 1194864180, 'Top posters', 0),
(50, 1, 9, '10|0', 'New Members', 'New Members', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_newmembers_show', 'b_system_newmembers_edit', 'system_block_newusers.html', 0, 1194864180, 'Shows most recent users', 0),
(48, 1, 7, '', 'Who''s Online', 'Who''s Online', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_online_show', '', 'system_block_online.html', 0, 1194864180, 'Displays users/guests currently online', 0),
(46, 1, 5, '', 'Main Menu', 'Main Menu', '', 0, 0, 'M', 'H', 1, 'system', 'system_blocks.php', 'b_system_main_show', '', 'system_block_mainmenu.html', 0, 1194866101, 'Shows the main navigation menu of the site', 0),
(47, 1, 6, '320|190|poweredby.gif|1', 'Site Info', 'Site Info', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_info_show', 'b_system_info_edit', 'system_block_siteinfo.html', 0, 1194864180, 'Shows basic info about the site and a link to Recommend Us pop up window', 0),
(45, 1, 4, '', 'Rss Feeds', 'Rss Feeds', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_rssshow', '', 'system_block_rss.html', 0, 1194864180, 'Shows headline news via RDF/RSS news feed', 0),
(44, 1, 3, '', 'Search', 'Search', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_search_show', '', 'system_block_search.html', 0, 1194864180, 'Shows search form block', 0),
(42, 1, 1, '', 'User Menu', 'User Menu', '', 0, 0, 'M', 'H', 1, 'system', 'system_blocks.php', 'b_system_user_show', '', 'system_block_user.html', 0, 1194866112, 'Shows user block', 0),
(43, 1, 2, '', 'Login', 'Login', '', 0, 0, 'M', 'H', 1, 'system', 'system_blocks.php', 'b_system_login_show', '', 'system_block_login.html', 0, 1194864180, 'Shows login form', 0),
(41, 10, 0, '', 'Buddy Block', 'Buddy Block', '', 9, 0, 'M', 'H', 1, 'messages', 'buddy_block.php', 'b_buddy_show', 'b_buddy_edit', 'message_buddy_list.html', 0, 1192190443, 'Displays List of buddies on user buddy list', 0),
(40, 7, 8, '0|0|0|0|1|1', '', 'Archives', '', 9, 0, 'M', 'H', 1, 'news', 'news_archives.php', 'b_news_archives_show', 'b_news_archives_edit', 'news_block_archives.html', 0, 1194864203, 'Shows a block where you can see archives', 0),
(39, 7, 7, 'published|10|25|0|0', 'AtsitiktinÄ—s anujienos', 'Random news', '', 9, 0, 'M', 'H', 1, 'news', 'news_randomnews.php', 'b_news_randomnews_show', 'b_news_randomnews_edit', 'news_block_randomnews.html', 0, 1194864203, 'Shows a block where news appears randomly', 0),
(33, 7, 1, '', 'NaujienÅ³ Temos', 'News Topics', '', 9, 0, 'M', 'H', 1, 'news', 'news_topics.php', 'b_news_topics_show', '', 'news_block_topics.html', 0, 1194864202, 'Shows news topics', 0),
(34, 7, 2, '', 'Didysis Straipsnis', 'Big Story', '', 9, 0, 'M', 'H', 1, 'news', 'news_bigstory.php', 'b_news_bigstory_show', '', 'news_block_bigstory.html', 0, 1194864202, 'Shows most read story of the day', 0),
(35, 7, 3, 'counter|10|25|0|0|0|0||1||||||', 'DidÅ¾iausios Naujienos', 'Top News', '', 9, 0, 'M', 'H', 1, 'news', 'news_top.php', 'b_news_top_show', 'b_news_top_edit', 'news_block_top.html', 0, 1194864202, 'Shows top read news articles', 0),
(36, 7, 4, 'published|10|25|0|0|0|0||1||||||', 'PaskutinÄ—s Naujienos', 'Recent News', '', 9, 0, 'M', 'H', 1, 'news', 'news_top.php', 'b_news_top_show', 'b_news_top_edit', 'news_block_top.html', 0, 1194864203, 'Shows recent articles', 0),
(37, 7, 5, '', 'Moderuoti Naujienas', 'Moderate News', '', 9, 0, 'M', 'H', 1, 'news', 'news_moderate.php', 'b_news_topics_moderate', '', 'news_block_moderate.html', 0, 1194864203, 'Shows a block to moderate articles', 0),
(38, 7, 6, '', 'Naviguoti per temas', 'Navigate thru topics', '', 9, 0, 'M', 'H', 1, 'news', 'news_topicsnav.php', 'b_news_topicsnav_show', 'b_news_topicsnav_edit', 'news_block_topicnav.html', 0, 1194864203, 'Shows a block to navigate topics', 0),
(54, 1, 13, '', 'Language', 'Language', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_language_select_show', 'b_language_select_edit', 'system_block_language.html', 0, 1194864180, 'Shows Language block', 0),
(55, 1, 14, '', 'Streaming Media', 'Streaming Media', '', 9, 0, 'M', '', 1, 'system', 'system_blocks.php', 'b_system_stream_show', 'b_system_stream_edit', 'system_block_streaming.html', 0, 1194864180, 'Shows Streaming block', 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_newblocks_bid_seq`
--

CREATE TABLE `cztsd_newblocks_bid_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_newblocks_bid_seq`
--

INSERT INTO `cztsd_newblocks_bid_seq` (`id`) VALUES
(58);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_online`
--

CREATE TABLE `cztsd_online` (
  `online_sessionid` varchar(60) NOT NULL default '',
  `online_uid` mediumint(8) unsigned NOT NULL default '0',
  `online_uname` varchar(25) NOT NULL default '',
  `online_updated` int(10) unsigned NOT NULL default '0',
  `online_addon` smallint(5) unsigned NOT NULL default '0',
  `online_component` varchar(25) NOT NULL default '',
  `online_ip` varchar(15) NOT NULL default '',
  `online_hidden` tinyint(1) NOT NULL default '0',
  KEY `online_addon` (`online_addon`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_online`
--

INSERT INTO `cztsd_online` (`online_sessionid`, `online_uid`, `online_uname`, `online_updated`, `online_addon`, `online_component`, `online_ip`, `online_hidden`) VALUES
('90542', 0, 'Anonymous', 1194867710, 0, '', '127.0.0.1', 0),
('90541', 0, 'Anonymous', 1194867709, 0, '', '127.0.0.1', 0),
('90537', 0, 'Anonymous', 1194867703, 0, '', '127.0.0.1', 0),
('90536', 0, 'Anonymous', 1194867696, 0, '', '127.0.0.1', 0),
('90535', 0, 'Anonymous', 1194867695, 0, '', '127.0.0.1', 0);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_online_seq`
--

CREATE TABLE `cztsd_online_seq` (
  `id` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_online_seq`
--

INSERT INTO `cztsd_online_seq` (`id`) VALUES
(90542);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_profile`
--

CREATE TABLE `cztsd_profile` (
  `profile_id` smallint(5) unsigned NOT NULL auto_increment,
  `profile_modid` smallint(5) unsigned NOT NULL default '0',
  `profile_catid` smallint(5) unsigned NOT NULL default '0',
  `profile_sectid` smallint(5) unsigned NOT NULL default '1',
  `profile_name` varchar(25) NOT NULL default '',
  `profile_title` varchar(30) NOT NULL default '',
  `profile_value` text NOT NULL,
  `profile_desc` text NOT NULL,
  `profile_formtype` varchar(15) NOT NULL default '',
  `profile_valuetype` varchar(10) NOT NULL default '',
  `profile_order` smallint(5) unsigned NOT NULL default '0',
  `profile_required` tinyint(2) NOT NULL default '0',
  `profile_display` tinyint(2) NOT NULL default '1',
  PRIMARY KEY  (`profile_id`),
  KEY `profile_mod_cat_id` (`profile_modid`,`profile_catid`),
  KEY `name` (`profile_catid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_profile`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_profilecategory`
--

CREATE TABLE `cztsd_profilecategory` (
  `profilecat_id` smallint(5) unsigned NOT NULL auto_increment,
  `profilecat_name` varchar(25) NOT NULL default '',
  `profilecat_order` smallint(5) unsigned NOT NULL default '0',
  `profilecat_desc` text NOT NULL,
  `profilecat_display` smallint(2) NOT NULL default '1',
  PRIMARY KEY  (`profilecat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_profilecategory`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_profileoption`
--

CREATE TABLE `cztsd_profileoption` (
  `profileop_id` mediumint(8) unsigned NOT NULL auto_increment,
  `profileop_name` varchar(255) NOT NULL default '',
  `profileop_value` varchar(255) NOT NULL default '',
  `profile_id` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`profileop_id`),
  KEY `profile_id` (`profile_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_profileoption`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_ranks`
--

CREATE TABLE `cztsd_ranks` (
  `rank_id` smallint(5) unsigned NOT NULL auto_increment,
  `rank_title` varchar(50) NOT NULL default '',
  `rank_min` mediumint(8) unsigned NOT NULL default '0',
  `rank_max` mediumint(8) unsigned NOT NULL default '0',
  `rank_special` tinyint(1) unsigned NOT NULL default '0',
  `rank_image` varchar(255) default NULL,
  PRIMARY KEY  (`rank_id`),
  KEY `rankspecial` (`rank_special`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_ranks`
--

INSERT INTO `cztsd_ranks` (`rank_id`, `rank_title`, `rank_min`, `rank_max`, `rank_special`, `rank_image`) VALUES
(5, 'Home away from home', 151, 10000, 0, 'rank3dbf8eb1a72e7.gif'),
(4, 'Just can''t stay away', 71, 150, 0, 'rank3dbf8ea81e642.gif'),
(3, 'Quite a regular', 41, 70, 0, 'rank3dbf8e9e7d88d.gif'),
(2, 'Not too shy to talk', 21, 40, 0, 'rank3dbf8e94a6f72.gif'),
(1, 'Just popping in', 0, 20, 0, 'rank3e632f95e81ca.gif'),
(6, 'Moderator', 0, 0, 1, 'rank3dbf8edf15093.gif'),
(7, 'Webmaster', 0, 0, 1, 'rank3dbf8ee8681cd.gif');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_ranks_seq`
--

CREATE TABLE `cztsd_ranks_seq` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_ranks_seq`
--

INSERT INTO `cztsd_ranks_seq` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_rss`
--

CREATE TABLE `cztsd_rss` (
  `rss_id` smallint(3) unsigned NOT NULL auto_increment,
  `rss_name` varchar(255) NOT NULL default '',
  `rss_url` varchar(255) NOT NULL default '',
  `rss_rssurl` varchar(255) NOT NULL default '',
  `rss_encoding` varchar(15) NOT NULL default '',
  `rss_cachetime` mediumint(8) unsigned NOT NULL default '3600',
  `rss_asblock` tinyint(1) unsigned NOT NULL default '0',
  `rss_display` tinyint(1) unsigned NOT NULL default '0',
  `rss_weight` smallint(3) unsigned NOT NULL default '0',
  `rss_mainfull` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainimg` tinyint(1) unsigned NOT NULL default '1',
  `rss_mainmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_blockimg` tinyint(1) unsigned NOT NULL default '0',
  `rss_blockmax` tinyint(2) unsigned NOT NULL default '10',
  `rss_xml` text NOT NULL,
  `rss_updated` int(10) NOT NULL default '0',
  PRIMARY KEY  (`rss_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_rss`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_section`
--

CREATE TABLE `cztsd_section` (
  `section_id` mediumint(8) NOT NULL auto_increment,
  `section_title` varchar(150) NOT NULL default '',
  `section_image` varchar(150) NOT NULL default '',
  `section_weight` tinyint(1) NOT NULL default '0',
  `section_display` enum('0','1') NOT NULL default '1',
  `section_published` int(11) NOT NULL default '0',
  `section_imageside` varchar(4) NOT NULL default 'left',
  `section_description` text NOT NULL,
  `section_type` varchar(10) NOT NULL default '',
  `section_is` tinyint(1) NOT NULL default '1',
  UNIQUE KEY `section_id` (`section_id`),
  KEY `section_title` (`section_display`,`section_published`,`section_weight`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_section`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_security`
--

CREATE TABLE `cztsd_security` (
  `security_id` mediumint(8) NOT NULL default '0',
  `security_title` varchar(60) NOT NULL default '',
  `security_login` varchar(10) NOT NULL default '',
  `security_password` varchar(10) NOT NULL default '',
  `security_sessionid` varchar(32) NOT NULL default '',
  `security_ip` varchar(10) NOT NULL default '',
  `security_date` int(11) NOT NULL default '0',
  `security_user_agent` varchar(255) NOT NULL default '',
  `security_remote_addr` varchar(20) NOT NULL default '',
  `security_http_referer` varchar(255) NOT NULL default '',
  `security_request_uri` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`security_id`),
  KEY `security_title` (`security_title`(3))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_security`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_security_seq`
--

CREATE TABLE `cztsd_security_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_security_seq`
--

INSERT INTO `cztsd_security_seq` (`id`) VALUES
(21);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_session`
--

CREATE TABLE `cztsd_session` (
  `sess_id` varchar(32) NOT NULL default '',
  `sess_updated` int(10) unsigned NOT NULL default '0',
  `sess_ip` varchar(15) NOT NULL default '',
  `sess_data` text NOT NULL,
  PRIMARY KEY  (`sess_id`),
  KEY `updated` (`sess_updated`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_session`
--

INSERT INTO `cztsd_session` (`sess_id`, `sess_updated`, `sess_ip`, `sess_data`) VALUES
('60d0d92f2b61cfa5cc8f8a1b713517bf', 1194867710, '127.0.0.1', 'user|a:2:{s:4:"menu";a:2:{s:4:"Home";a:4:{s:3:"url";s:24:"http://localhost/zarilia";s:5:"title";s:4:"Home";s:5:"items";a:0:{}s:2:"id";i:3;}s:10:"My Account";a:4:{s:3:"url";s:69:"http://localhost/zarilia/index.php?page_type=userinfo&amp;uid={X_UID}";s:5:"title";s:10:"My Account";s:5:"items";a:0:{}s:2:"id";i:5;}}s:10:"footermenu";N;}'),
('f7f86da269bfb61e12081af958b96e17', 1194866935, '127.0.0.1', 'user|a:2:{s:4:"menu";a:2:{s:6:"Tinkle";a:4:{s:3:"url";s:60:"http://localhost/zarilia/index.php?page_type=static&amp;id=8";s:5:"title";s:6:"Tinkle";s:5:"items";a:0:{}s:2:"id";i:1;}s:17:"Pagrindinis meniu";a:4:{s:3:"url";s:0:"";s:5:"title";s:17:"Pagrindinis meniu";s:5:"items";a:4:{i:0;a:3:{s:3:"url";s:37:"http://localhost/zarilia/addons/news/";s:5:"title";s:9:"Naujienos";s:5:"image";s:0:"";}i:1;a:3:{s:3:"url";s:60:"http://localhost/zarilia/index.php?page_type=static&amp;id=2";s:5:"title";s:6:"Tinkle";s:5:"image";s:0:"";}i:2;a:3:{s:3:"url";s:60:"http://localhost/zarilia/index.php?page_type=static&amp;id=1";s:5:"title";s:9:"Pokalbiai";s:5:"image";s:0:"";}i:3;a:3:{s:3:"url";s:60:"http://localhost/zarilia/index.php?page_type=static&amp;id=3";s:5:"title";s:8:"Apie mus";s:5:"image";s:0:"";}}s:2:"id";i:4;}}s:10:"footermenu";N;}');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_smiles`
--

CREATE TABLE `cztsd_smiles` (
  `id` smallint(5) unsigned NOT NULL auto_increment,
  `code` varchar(50) NOT NULL default '',
  `smile_url` varchar(100) NOT NULL default '',
  `emotion` varchar(75) NOT NULL default '',
  `display` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_smiles`
--

INSERT INTO `cztsd_smiles` (`id`, `code`, `smile_url`, `emotion`, `display`) VALUES
(1, ':-D', 'smil3dbd4d4e4c4f2.gif', 'Grin smilie', 1),
(2, ':-)', 'smil3dbd4d6422f04.gif', 'Smile', 1),
(3, ':-(', 'smil3dbd4d75edb5e.gif', 'Sad', 1),
(4, ':-o', 'smil3dbd4d8676346.gif', 'Surprised', 1),
(5, ':-?', 'smil3dbd4d99c6eaa.gif', 'Confused', 1),
(6, '8-)', 'smil3dbd4daabd491.gif', 'Cool', 1),
(7, ':lol:', 'smil3dbd4dbc14f3f.gif', 'Laughing', 1),
(8, ':-x', 'smil3dbd4dcd7b9f4.gif', 'Mad', 1),
(9, ':-P', 'smil3dbd4ddd6835f.gif', 'Razz', 1),
(10, ':oops:', 'smil3dbd4df1944ee.gif', 'Embaressed', 1),
(11, ':cry:', 'smil3dbd4e02c5440.gif', 'Crying (very sad)', 1),
(12, ':evil:', 'smil3dbd4e1748cc9.gif', 'Evil or Very Mad', 1),
(13, ':roll:', 'smil3dbd4e29bbcc7.gif', 'Rolling Eyes', 1),
(14, ';-)', 'smil3dbd4e398ff7b.gif', 'Wink', 1),
(15, ':pint:', 'smil3dbd4e4c2e742.gif', 'Another pint of beer', 1),
(16, ':hammer:', 'smil3dbd4e5e7563a.gif', 'ToolTimes at work', 1),
(17, ':idea:', 'smil3dbd4e7853679.gif', 'I have an idea', 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_smiles_seq`
--

CREATE TABLE `cztsd_smiles_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_smiles_seq`
--

INSERT INTO `cztsd_smiles_seq` (`id`) VALUES
(36);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_stats`
--

CREATE TABLE `cztsd_stats` (
  `stat_id` mediumint(8) unsigned NOT NULL auto_increment,
  `stat_date` int(11) unsigned NOT NULL default '1',
  `stat_user_agent` varchar(255) NOT NULL default '',
  `stat_remote_addr` varchar(20) NOT NULL default '',
  `stat_http_referer` varchar(255) NOT NULL default '',
  `stat_request_uri` varchar(255) NOT NULL default '',
  `stat_request_addon` varchar(255) NOT NULL default '',
  `stat_unique` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`stat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_stats`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_streaming`
--

CREATE TABLE `cztsd_streaming` (
  `streaming_id` mediumint(9) NOT NULL default '0',
  `streaming_title` varchar(150) NOT NULL default '',
  `streaming_file` varchar(255) NOT NULL default '',
  `streaming_uid` mediumint(8) NOT NULL default '0',
  `streaming_description` text NOT NULL,
  `streaming_image` varchar(255) NOT NULL default '',
  `streaming_weight` smallint(5) NOT NULL default '0',
  `streaming_display` tinyint(1) NOT NULL default '0',
  `streaming_published` tinyint(1) NOT NULL default '0',
  `streaming_mimetype` varchar(100) NOT NULL default '',
  `streaming_alias` varchar(60) NOT NULL default '',
  PRIMARY KEY  (`streaming_id`),
  KEY `streaming_title` (`streaming_title`),
  KEY `streaming_uid` (`streaming_uid`),
  KEY `streaming_display` (`streaming_display`),
  KEY `streaming_published` (`streaming_published`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_streaming`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_tplfile`
--

CREATE TABLE `cztsd_tplfile` (
  `tpl_id` mediumint(7) unsigned NOT NULL auto_increment,
  `tpl_refid` smallint(5) unsigned NOT NULL default '0',
  `tpl_addon` varchar(25) NOT NULL default '',
  `tpl_tplset` varchar(50) NOT NULL default '',
  `tpl_file` varchar(50) NOT NULL default '',
  `tpl_desc` varchar(255) NOT NULL default '',
  `tpl_lastmodified` int(10) unsigned NOT NULL default '0',
  `tpl_lastimported` int(10) unsigned NOT NULL default '0',
  `tpl_type` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`tpl_id`),
  KEY `tpl_refid` (`tpl_refid`,`tpl_type`),
  KEY `tpl_tplset` (`tpl_tplset`,`tpl_file`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=789 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_tplfile`
--

INSERT INTO `cztsd_tplfile` (`tpl_id`, `tpl_refid`, `tpl_addon`, `tpl_tplset`, `tpl_file`, `tpl_desc`, `tpl_lastmodified`, `tpl_lastimported`, `tpl_type`) VALUES
(759, 1, 'system', 'default', 'system_stream.html', '', 1194864179, 0, 'addon'),
(757, 1, 'system', 'default', 'system_blogindex.html', '', 1194864179, 0, 'addon'),
(758, 1, 'system', 'default', 'system_newsindex.html', '', 1194864179, 0, 'addon'),
(743, 1, 'system', 'default', 'system_userinfo.html', '', 1194864178, 0, 'addon'),
(744, 1, 'system', 'default', 'system_userform.html', '', 1194864178, 0, 'addon'),
(745, 1, 'system', 'default', 'system_rss.html', '', 1194864178, 0, 'addon'),
(746, 1, 'system', 'default', 'system_comment.html', '', 1194864178, 0, 'addon'),
(747, 1, 'system', 'default', 'system_comments_flat.html', '', 1194864178, 0, 'addon'),
(748, 1, 'system', 'default', 'system_comments_thread.html', '', 1194864178, 0, 'addon'),
(749, 1, 'system', 'default', 'system_comments_nest.html', '', 1194864178, 0, 'addon'),
(750, 1, 'system', 'default', 'system_dummy.html', 'Dummy template file for holding non-template contents. This should not be edited.', 1194864178, 0, 'addon'),
(751, 1, 'system', 'default', 'system_notification_list.html', '', 1194864178, 0, 'addon'),
(752, 1, 'system', 'default', 'system_notification_select.html', '', 1194864178, 0, 'addon'),
(753, 1, 'system', 'default', 'system_rssindex.html', '', 1194864178, 0, 'addon'),
(754, 1, 'system', 'default', 'system_rssfeed.html', '', 1194864179, 0, 'addon'),
(755, 1, 'system', 'default', 'system_staticindex.html', '', 1194864179, 0, 'addon'),
(756, 1, 'system', 'default', 'system_errorpage.html', '', 1194864179, 0, 'addon'),
(651, 35, 'news', 'default', 'news_block_top.html', 'Shows top read news articles', 1194864202, 0, 'block'),
(652, 36, 'news', 'default', 'news_block_top.html', 'Shows recent articles', 1194864203, 0, 'block'),
(653, 37, 'news', 'default', 'news_block_moderate.html', 'Shows a block to moderate articles', 1194864203, 0, 'block'),
(654, 38, 'news', 'default', 'news_block_topicnav.html', 'Shows a block to navigate topics', 1194864203, 0, 'block'),
(650, 34, 'news', 'default', 'news_block_bigstory.html', 'Shows most read story of the day', 1194864202, 0, 'block'),
(649, 33, 'news', 'default', 'news_block_topics.html', 'Shows news topics', 1194864202, 0, 'block'),
(787, 7, 'news', 'default', 'news_whos_who.html', 'Who''s who', 1194864202, 0, 'addon'),
(780, 7, 'news', 'default', 'news_archive.html', '', 1194864201, 0, 'addon'),
(781, 7, 'news', 'default', 'news_article.html', '', 1194864201, 0, 'addon'),
(782, 7, 'news', 'default', 'news_index.html', '', 1194864201, 0, 'addon'),
(783, 7, 'news', 'default', 'news_by_topic.html', '', 1194864202, 0, 'addon'),
(784, 7, 'news', 'default', 'news_by_this_author.html', 'Shows a page resuming all the articles of the same author (according to the perms)', 1194864202, 0, 'addon'),
(741, 1, 'system', 'default', 'system_mediamanager.html', '', 1194864177, 0, 'addon'),
(742, 1, 'system', 'default', 'system_mediaupload.html', '', 1194864177, 0, 'addon'),
(657, 9, 'advertisement', 'default', 'ads_index.html', '', 1192190414, 0, 'addon'),
(658, 41, 'messages', 'default', 'message_buddy_list.html', 'Displays List of buddies on user buddy list', 1192190443, 0, 'block'),
(656, 40, 'news', 'default', 'news_block_archives.html', 'Shows a block where you can see archives', 1194864203, 0, 'block'),
(655, 39, 'news', 'default', 'news_block_randomnews.html', 'Shows a block where news appears randomly', 1194864203, 0, 'block'),
(785, 7, 'news', 'default', 'news_ratenews.html', 'Template used to rate a news', 1194864202, 0, 'addon'),
(786, 7, 'news', 'default', 'news_rss.html', 'Used for RSS per topics', 1194864202, 0, 'addon'),
(779, 7, 'news', 'default', 'news_item.html', '', 1194864201, 0, 'addon'),
(706, 1, 'system', 'default', 'system_block_login.html', 'Login form', 1192741526, 0, 'block'),
(760, 1, 'system', 'default', 'system_lostpass.html', '', 1194864179, 0, 'addon'),
(761, 1, 'system', 'default', 'system_registerform.html', '', 1194864179, 0, 'addon'),
(762, 1, 'system', 'default', 'system_edituserform.html', '', 1194864179, 0, 'addon'),
(763, 1, 'system', 'default', 'system_friend.html', '', 1194864179, 0, 'addon'),
(764, 1, 'system', 'default', 'system_avatarform.html', '', 1194864179, 0, 'addon'),
(765, 42, 'system', 'default', 'system_block_user.html', 'Shows user block', 1194864180, 0, 'block'),
(766, 43, 'system', 'default', 'system_block_login.html', 'Shows login form', 1194864180, 0, 'block'),
(767, 44, 'system', 'default', 'system_block_search.html', 'Shows search form block', 1194864180, 0, 'block'),
(768, 45, 'system', 'default', 'system_block_rss.html', 'Shows headline news via RDF/RSS news feed', 1194864180, 0, 'block'),
(769, 46, 'system', 'default', 'system_block_mainmenu.html', 'Shows the main navigation menu of the site', 1194864180, 0, 'block'),
(770, 47, 'system', 'default', 'system_block_siteinfo.html', 'Shows basic info about the site and a link to Recommend Us pop up window', 1194864180, 0, 'block'),
(771, 48, 'system', 'default', 'system_block_online.html', 'Displays users/guests currently online', 1194864180, 0, 'block'),
(772, 49, 'system', 'default', 'system_block_topusers.html', 'Top posters', 1194864180, 0, 'block'),
(773, 50, 'system', 'default', 'system_block_newusers.html', 'Shows most recent users', 1194864180, 0, 'block'),
(774, 51, 'system', 'default', 'system_block_comments.html', 'Shows most recent comments', 1194864180, 0, 'block'),
(775, 52, 'system', 'default', 'system_block_notification.html', 'Shows notification options', 1194864180, 0, 'block'),
(776, 53, 'system', 'default', 'system_block_themes.html', 'Shows theme selection box', 1194864180, 0, 'block'),
(777, 54, 'system', 'default', 'system_block_language.html', 'Shows Language block', 1194864180, 0, 'block'),
(778, 55, 'system', 'default', 'system_block_streaming.html', 'Shows Streaming block', 1194864180, 0, 'block'),
(788, 7, 'news', 'default', 'news_topics_directory.html', 'Topics Directory', 1194864202, 0, 'addon');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_tplset`
--

CREATE TABLE `cztsd_tplset` (
  `tplset_id` int(7) unsigned NOT NULL auto_increment,
  `tplset_name` varchar(50) NOT NULL default '',
  `tplset_desc` varchar(255) NOT NULL default '',
  `tplset_credits` text NOT NULL,
  `tplset_created` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`tplset_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_tplset`
--

INSERT INTO `cztsd_tplset` (`tplset_id`, `tplset_name`, `tplset_desc`, `tplset_credits`, `tplset_created`) VALUES
(1, 'default', 'Zarilia Default Template Set', '', 1183095911);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_tplset_seq`
--

CREATE TABLE `cztsd_tplset_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_tplset_seq`
--

INSERT INTO `cztsd_tplset_seq` (`id`) VALUES
(2);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_tplsource`
--

CREATE TABLE `cztsd_tplsource` (
  `tpl_id` mediumint(7) unsigned NOT NULL default '0',
  `tpl_source` mediumtext NOT NULL,
  KEY `tpl_id` (`tpl_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_tplsource`
--

INSERT INTO `cztsd_tplsource` (`tpl_id`, `tpl_source`) VALUES
(741, '<!DOCTYPE html PUBLIC ''//W3C//DTD XHTML 1.0 Transitional//EN'' ''http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd''>\r\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<{$zarilia_langcode}>" lang="<{$zarilia_langcode}>">\r\n<head>\r\n<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />\r\n<meta http-equiv="content-language" content="<{$zarilia_langcode}>" />\r\n<title><{$sitename}><{$smarty.const._MA_AD_MEDIA_MANAGER}></title>\r\n<{$zarilia_header}>\r\n<{$zarilia_addon_header}>\r\n<script type="text/javascript">\r\n<!--//\r\nfunction appendCode(addCode) {\r\n	var targetDom = window.opener.zariliaGetElementById(''<{$target}>'');\r\n\r\n	if (targetDom.createTextRange && targetDom.caretPos){\r\n  		var caretPos = targetDom.caretPos;\r\n		caretPos.text = caretPos.text.charAt(caretPos.text.length - 1)\r\n== '' '' ? addCode + '' '' : addCode;\r\n	} else if (targetDom.getSelection && targetDom.caretPos){\r\n		var caretPos = targetDom.caretPos;\r\n		caretPos.text = caretPos.text.charat(caretPos.text.length - 1)\r\n== '' '' ? addCode + '' '' : addCode;\r\n	} else {\r\n		targetDom.value = targetDom.value + addCode;\r\n  	}\r\n	//window.close();\r\n	return;\r\n}\r\n\r\nfunction InsertWysiwygImage(addCode)\r\n{\r\n	window.opener.XK_InsertImage(''<{$target}>'',addCode,'''');\r\n	//window.close();\r\n	return;\r\n};\r\n//-->\r\n</script>\r\n\r\n</head>\r\n<body onload="window.resizeTo(<{$xsize}>, <{$ysize}>);">\r\n<br /><br />\r\n  <table cellspacing="1" id="imagenav" width="90%" align="center">\r\n    <tr>\r\n      <td align="left" width="50%"><{$selection_box}>\r\n	  </td>\r\n	 <{if $media_cid > 0}>\r\n      <td align="right" width="50%">\r\n	   <a href="<{$zarilia_url}>/mediamanager.php?target=<{$target}>&amp;op=upload&amp;media_cid=<{$media_cid}>"> <img src=''<{$zarilia_url}>/images/upload.png'' border=''0'' alt=''<{$smarty.const._ADDIMAGE}>'' align= "absmiddle"/></a>\r\n	  </td>\r\n	 <{/if}>\r\n   </tr>\r\n  </table>\r\n<br />\r\n<table id="imagemain" cellspacing="1" border="0" width="90%" align="center" class="outers">\r\n  <tr align="left">\r\n    <th><{$smarty.const._MA_AD_MEDIA_DETAILS}></th>\r\n    <th><{$smarty.const._MA_AD_MEDIA_IMAGE}></th>\r\n  </tr>\r\n<{if $media_total > 0}>\r\n <{section name=i loop=$images}>\r\n  <tr valign="top">\r\n    <td class=''head'' nowrap="nowrap:">\r\n	<input type="hidden" name="image_id[]" value="<{$images[i].id}>" />\r\n	 <table>\r\n	  <tr>\r\n	   <td width="30%"><b><{$smarty.const._MA_AD_MEDIA_EREALNAME}></b></td><td><{$images[i].nicename}></td>\r\n	  </tr>\r\n	  <tr>\r\n	   <td width="30%"><b><{$smarty.const._MA_AD_MEDIA_ENAME}></b></td><td><{$images[i].realname}></td>\r\n	  </tr>\r\n	  <tr>\r\n	   <td width="30%"><b><{$smarty.const._MA_AD_MEDIA_EFILESIZE}></b></td><td><{$images[i].size}></td>\r\n	  </tr>\r\n	   <{if $images[i].width }>\r\n	  <tr>\r\n	    <td width="30%"><b><{$smarty.const._MA_AD_MEDIA_EDIM}></b></td><td><{$lang_weight}>: <{$images[i].width}> X <{$lang_height}>: <{$images[i].height}></td>\r\n	  </tr>\r\n	   <{/if}>\r\n	  <tr>\r\n	   <td width="30%"><b><{$smarty.const._MA_AD_MEDIA_EMIMETYPE}></b></td><td><{$images[i].mimetype}></td>\r\n	  </tr>\r\n	 </table>\r\n	</td>\r\n    <td width= "70%" class = ''even'' style="text-align: center;">\r\n	  <div align="center">\r\n		<{$images[i].src}>\r\n	  </div>\r\n	  <div align="center">\r\n		 <{$media}>\r\n		 <{if $images[i].media != 1 }>\r\n		  <a href="#" onclick="javascript:appendCode(''<{$images[i].lxcode}>'');"> <img src="<{$zarilia_url}>/images/im_back.png" title="Insert Left Align" alt="Left" /></a>\r\n		 <{/if}>\r\n		  <a href="#" onclick="javascript:appendCode(''<{$images[i].xcode}>'');"> <img src="<{$zarilia_url}>/images/im_down.png" title="Insert Center Align" alt="Center" /></a>\r\n\r\n		 <{if $images[i].media != 1 }>\r\n  	 	 <a href="#" onclick="javascript:appendCode(''<{$images[i].rxcode}>'');"> <img src="<{$zarilia_url}>/images/im_forward.png" title="Insert Right Align" alt="Right" /></a>\r\n         <a href="#" onclick="javascript:InsertWysiwygImage(''<{$images[i].xcode}>'');"> <img src="<{$zarilia_url}>/images/im_add.png" title="Insert Into Wysiwyg" alt="Insert Into Wysiwyg" /></a>\r\n		 <{/if}>\r\n	  </div>\r\n	</td>\r\n  </tr>\r\n <{/section}>\r\n<{else}>\r\n  <tr>\r\n    <td colspan="4" class="even" align="center"><b><{$smarty.const._MA_AD_MEDIA_NOTHINGFOUND}></b></td>\r\n  </tr>\r\n<{/if}>\r\n  <tr>\r\n    <td colspan="4" class="footer" align="center">&nbsp;</td>\r\n  </tr>\r\n</table>\r\n<{if pagenav}>\r\n	<div style="padding-top: 6px; padding-bottom: 6px; padding-right: 6px; text-align: right; " id="pagenav"><{$pagenav}></div>\r\n<{/if}>\r\n\r\n<div style="padding-top: 6px; padding-bottom: 6px; padding-right: 6px; text-align: center; ">\r\n	<input value="<{$smarty.const._CLOSE}>" type="button" class="formbutton" onclick="javascript:window.close();" />\r\n</div>\r\n\r\n</body>\r\n</html>'),
(742, '<!DOCTYPE html PUBLIC ''//W3C//DTD XHTML 1.0 Transitional//EN'' ''http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd''>\r\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<{$zarilia_langcode}>" lang="<{$zarilia_langcode}>">\r\n<head>\r\n<meta http-equiv="content-type" content="text/html; charset=<{$zarilia_charset}>" />\r\n<meta http-equiv="content-language" content="<{$zarilia_langcode}>" />\r\n<title><{$zarilia_sitename}> <{$smarty.const._MA_AD_MEDIA_MANAGER}></title>\r\n<{$zarilia_header}>\r\n<{$zarilia_addon_header}>\r\n<{$media_form.javascript}>\r\n\r\n</head><body onload="window.resizeTo(<{$xsize}>, <{$ysize}>);">\r\n<br /><br />\r\n<table cellspacing="0" cellpadding="2" width="90%" id="medianav" align="center" class="outer">\r\n  <tr class="even">\r\n    <td align="left"><b><{$smarty.const._MA_AD_MEDIA_MANAGER}></b> : <{$smarty.const._MA_AD_MEDIA_UPLOAD}></td>\r\n  </tr>\r\n</table><br />\r\n\r\n<form name="<{$media_form.name}>" id="<{$media_form.name}>" action="<{$media_form.op}>" method="<{$media_form.method}>" <{$media_form.extra}>>\r\n<table id="mediamain" width = "90%" align="center" class="outer">\r\n  <tr align="left">\r\n    <th colspan="2"><{$smarty.const._MA_AD_MEDIA_CREATE}></th>\r\n  </tr>\r\n  <!-- start of form elements loop -->\r\n<{foreach item=element from=$media_form.elements}>\r\n	<{if $element.hidden != true}>\r\n	  <tr valign="top">\r\n	    <td class="head"><{$element.caption}></td>\r\n	    <td class="even"><{$element.body}></td>\r\n	  </tr>\r\n	<{else}>\r\n		<{$element.body}>\r\n	<{/if}>\r\n<{/foreach}>\r\n  <!-- end of form elements loop -->\r\n  <tr>\r\n    <td colspan="2" class="foot" align="center">&nbsp;</td>\r\n  </tr>\r\n</table>\r\n</form>\r\n\r\n<div style="padding-top: 6px; padding-bottom: 6px; padding-right: 6px; text-align: center; ">\r\n	<input value="<{$smarty.const._CLOSE}>" type="button" class="formbutton" onclick="javascript:window.close();" />\r\n</div>\r\n</body>\r\n</html>'),
(743, '<h3 class="profiletitle"><{$smarty.const._US_PROFILE_TITLE_HEADING}> <{$user_realname}></h3>\r\n<table id=''profileheading'' cellspacing=''1'' cellpadding=''2''>\r\n	<tr>\r\n		<td width="20%" class=''profile''>\r\n			<div style="font-size: 14px; font-weight: bold;"><{$user_uname}></div>\r\n			<{if $user_avatarurl}>\r\n			 <div style="text-align: center;"><img src="<{$user_avatarurl}>" alt=''<{$smarty.const._US_AVATAR}>'' vspace=''5px'' /></div>\r\n			<{/if}>\r\n			<div><strong><{$user_ranktitle}></strong></div>\r\n			<div><{$user_rankimage}></div>\r\n		</td>\r\n		<td class=''profileinfo''>\r\n			<table class="outer" cellpadding="2" cellspacing="1" width="100%">\r\n			  <tr valign="top">\r\n			    <th colspan="2" align="left"><{$smarty.const._US_STATISTICS}></th>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head" width="30%"><{$smarty.const._US_MEMBERSINCE}></td>\r\n			    <td align="left" class="odd"><{$user_joindate}></td>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head"><{$smarty.const._US_POSTS}></td>\r\n			    <td align="left" class="even"><{$user_posts}></td>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head"><{$smarty.const._US_LASTLOGIN}></td>\r\n			    <td align="left" class="odd"><{$user_lastlogin}></td>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head"><{$smarty.const._US_LEVEL}></td>\r\n			    <td align="left" class="odd"><{$user_usrlevel}></td>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head"><{$smarty.const._US_MEDPREF}></td>\r\n			    <td align="left" class="odd"><{$user_usrmedpref}></td>\r\n			  </tr>\r\n			  <tr valign="top">\r\n			    <td class="head"><{$smarty.const._US_ONLINE}></td>\r\n			    <td align="left" class="odd"><img src="<{$user_online_image}>" alt=''<{$user_online_status}>'' align="absmiddle" /> <{$user_online_status}> </td>\r\n			  </tr>\r\n			</table>\r\n			<br />\r\n			<{if $user_ownpage == true}>\r\n				<form name="usernav" action="index.php?page_type=user" method="post">\r\n				<table width="100%" align="center" border="0">\r\n				  <tr align="center">\r\n				    <td>\r\n						<{if $user_ownpage == true}>\r\n						   <form name="usernav" action="index.php?page_type=user" method="post">\r\n							<input type="button" class="formbutton" value="<{$smarty.const._US_EDITPROFILE}>" onclick="location=''index.php?page_type=edituser''" />\r\n						    <input type="button" class="formbutton" value="<{$smarty.const._US_AVATAR}>" onclick="location=''index.php?page_type=avatar''" />\r\n						    <input type="button" class="formbutton" value="<{$smarty.const._US_NOTIFICATIONS}>" onclick="location=''index.php?page_type=notifications''" />\r\n						    <input type="button" class="formbutton" value="<{$smarty.const._US_INBOX}>" onclick="location=''index.php?page_type=messages''" />\r\n						    <{if $user_candelete == true}>\r\n						     <input type="button" class="formbutton" value="<{$smarty.const._US_DELACCOUNT}>" onclick="location=''index.php?page_type=user&amp;act=delete''" />\r\n						    <{/if}>\r\n						    <input type="button" class="formbutton" value="<{$smarty.const._US_LOGOUT}>" onclick="location=''index.php?page_type=user&amp;act=logout''" />\r\n						   </form>\r\n						<{/if}>\r\n					</td>\r\n				  </tr>\r\n				</table>\r\n				</form>\r\n				<br />\r\n				<{elseif $zarilia_isadmin != false}>\r\n				<table width="100%" align="center" border="0">\r\n				  <tr align="center">\r\n				    <td>\r\n					 <input type="button" class="formbutton" value="<{$smarty.const._US_EDITPROFILE}>" onclick="location=''<{$zarilia_url}>/addons/system/admin.php?fct=users&amp;uid=<{$user_uid}>&amp;op=modifyUser''" />\r\n				     <input type="button" class="formbutton" value="<{$smarty.const._US_DELACCOUNT}>" onclick="location=''<{$zarilia_url}>/addons/system/admin.php?fct=users&amp;op=delUser&amp;uid=<{$user_uid}>''" />\r\n				   </td>\r\n				  </tr>\r\n				</table>\r\n				<br />\r\n			<{/if}>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<{if $zarilia_isuser}>\r\n <div align="right">\r\n  <{if $show_posts}>\r\n   <input type="button" class="formbutton" value="<{$smarty.const._US_VIEWPOSTS}>" onclick="location=''<{$zarilia_url}>/index.php?page_type=userinfo&amp;act=posts&amp;uid=<{$user_uid}>''" />\r\n  <{else}>\r\n    <input type="button" class="formbutton" value="<{$smarty.const._US_VIEWPROFILE}>" onclick="location=''<{$zarilia_url}>/index.php?page_type=userinfo&amp;uid=<{$user_uid}>''" />\r\n  <{/if}>\r\n  <{if $user_ownpage == false }>\r\n   <input type="button" class="formbutton" value="<{$smarty.const._US_SENDEMAIL}>" onclick="location=''<{$zarilia_url}>/index.php?page_type=userinfo&act=endemail&amp;uid=<{$user_uid}>''" />\r\n   <input type="button" class="formbutton" value="<{$smarty.const._US_SENDPMTO}>" onclick="location=''<{$zarilia_url}>/addons/messages/message_create.php?op=create&amp;uid=<{$user_uid}>''" />\r\n  <{/if}>\r\n </div>\r\n<{/if}>\r\n<br />\r\n<{$user_tabs}>\r\n<br /><br />\r\n\r\n<{if $show_posts }>\r\n	<table cellpadding="2" cellspacing="1" width="100%">\r\n	 <tr valign="top">\r\n	  <th align="left" colspan="2"><{$lang_opt}></th>\r\n	 </tr>\r\n	 <tr valign="top">\r\n		<!-- start addon search results loop -->\r\n		<{if $user_form}>\r\n			<{foreach item=userform from=$user_form}>\r\n			 <tr valign="top">\r\n			  <td class="head" width="35%"><b><{$userform.title}></b></td>\r\n			  <td align="left" class="even"><{$userform.value}></td>\r\n			 </tr>\r\n			<{/foreach}>\r\n		<{else}>\r\n		  <tr valign="top">\r\n		   <td colspan="2" align="center" class="even">No Results Found</td>\r\n		  </tr>\r\n		<{/if}>\r\n	</table>\r\n<{else}>\r\n	<table class="outer" cellpadding="2" cellspacing="1" width="100%">\r\n	 <tr valign="top">\r\n	  <th align="left"><{$smarty.const._US_DATEPOSTED}></th>\r\n	  <th align="left"><{$smarty.const._US_ITEMPOSTED}></th>\r\n	 </tr>\r\n	 <tr valign="top">\r\n\r\n	<!-- start addon search results loop -->\r\n	<{foreach item=addon from=$addons}>\r\n	 <tr valign="top">\r\n	  <td class="head" colspan="2"><b><{$addon.name}></b></td>\r\n	 </tr>\r\n	 <{foreach item=result from=$addon.results}>\r\n	  <tr valign="top">\r\n	   <td style="white-space: nowrap;" class="even" width="15%"><{$result.time}></td>\r\n	   <td class="even"><a href="<{$result.link}>"><{$result.title}></a></td>\r\n	  </tr>\r\n	 <{/foreach}>\r\n	  <tr valign="top">\r\n	   <td class="foot" colspan="2" style="text-align: right;">&nbsp;<{$addon.showall_link}></td>\r\n	  </tr>\r\n	  <tr valign="top">\r\n	   <td colspan="2">&nbsp;</td>\r\n	  </tr>\r\n	<{/foreach}>\r\n	</table>\r\n<{/if}>'),
(744, '<h4><{$lang_login}></h4>\r\n<div style="text-align: left;"><{$smarty.const._US_LOGINNOTICE}></div><br />\r\n<form id="userlogin" action="<{$zarilia_url}>" method="post">\r\n  <table width="100%" border="0" cellspacing="1" cellpadding="2" summary="">\r\n    <tr>\r\n      <td colspan="2"><b><{$smarty.const._US_LOGINUSINGDETAILS}></b></td>\r\n    </tr>\r\n    <tr>\r\n      <td width="30%"><b><{$smarty.const._USERNAME}></b></td>\r\n      <td><input type="text" style=''vertical-align: middle;'' name="login" size="21" maxlength="25" value="<{$usercookie}>" /></td>\r\n    </tr>\r\n    <tr>\r\n      <td><b><{$smarty.const._PASSWORD}></b></td>\r\n      <td><input type="password" style=''vertical-align: middle;'' name="pass" size="21" maxlength="32" /></td>\r\n    </tr>\r\n    <{if $showimage}>\r\n	<tr>\r\n      <td><b><{$smarty.const._MB_SYSTEM_LOGINCHECK}></b></td>\r\n      <td>\r\n	  	<input type="text" style=''vertical-align: middle;'' name="verification" size="5" maxlength="32" />&nbsp;<{$verification_image}>\r\n	  	<input type="hidden" name="verification_ver" value="<{$verification_ver}>" />\r\n	  </td>\r\n    </tr>\r\n    <{/if}>\r\n	<tr>\r\n      <td>&nbsp;</td>\r\n      <td>\r\n	   <input type="checkbox" style='' vertical-align: middle;'' name="rememberme" value="1"/> <{$smarty.const._US_REMEBERME}> <br />\r\n	   <input type="checkbox" style='' vertical-align: middle;'' name="loginanon" value="1"/> <{$smarty.const._US_LOGINANON}> </td>\r\n    </tr>\r\n    <tr>\r\n      <td>&nbsp;</td>\r\n      <td><input type="submit" class="formbutton" value="<{$smarty.const._LOGIN}>" /></td>\r\n    </tr>\r\n  </table>\r\n  <input type="hidden" name="page_type" value="user" />\r\n  <input type="hidden" name="act" value="dologin" />\r\n  <{if $redirect_page}>\r\n   <input type="hidden" name="zarilia_redirect" value="<{$redirect_page}>" />\r\n  <{/if}>\r\n</form>\r\n<div style="text-align: left;"><{$smarty.const._US_BROWSERCOOKIES}></div>\r\n\r\n<{if $allow_register }>\r\n	<h4><{$smarty.const._US_CREATEACCOUNT}></h4>\r\n	<div style="text-align: left;"><{$smarty.const._US_CREATEACCOUNTTEXT}></div><br />\r\n	<div style="text-align: left;"><{$smarty.const._US_CREATEACCOUNTSIGNUP}></div>\r\n<{/if}>'),
(745, '<?xml version="1.0" encoding="UTF-8"?>\r\n<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">\r\n<rss version="2.0">\r\n  <channel>\r\n    <title><{$channel_title}></title>\r\n    <link><{$channel_link}></link>\r\n    <description><{$channel_desc}></description>\r\n    <lastBuildDate><{$channel_lastbuild}></lastBuildDate>\r\n    <docs>http://backend.userland.com/rss/</docs>\r\n    <generator><{$channel_generator}></generator>\r\n    <category><{$channel_category}></category>\r\n    <managingEditor><{$channel_editor}></managingEditor>\r\n    <webMaster><{$channel_webmaster}></webMaster>\r\n    <language><{$channel_language}></language>\r\n    <{if $image_url != ""}>\r\n    <image>\r\n      <title><{$channel_title}></title>\r\n      <url><{$image_url}></url>\r\n      <link><{$channel_link}></link>\r\n      <width><{$image_width}></width>\r\n      <height><{$image_height}></height>\r\n    </image>\r\n    <{/if}>\r\n    <{foreach item=item from=$items}>\r\n    <item>\r\n      <title><{$item.title}></title>\r\n      <link><{$item.link}></link>\r\n      <description><{$item.description}></description>\r\n      <pubDate><{$item.pubdate}></pubDate>\r\n      <guid><{$item.guid}></guid>\r\n    </item>\r\n    <{/foreach}>\r\n  </channel>\r\n</rss>'),
(746, '<!-- start comment post -->\r\n        <tr>\r\n          <td class="head"><a id="comment<{$comment.id}>"></a> <{$comment.poster.uname}></td>\r\n          <td class="head"><div class="comDate"><span class="comDateCaption"><{$lang_posted}>:</span> <{$comment.date_posted}>&nbsp;&nbsp;<span class="comDateCaption"><{$lang_updated}>:</span> <{$comment.date_modified}></div></td>\r\n        </tr>\r\n        <tr>\r\n\r\n          <{if $comment.poster.id != 0}>\r\n\r\n          <td class="odd"><div class="comUserRank"><div class="comUserRankText"><{$comment.poster.rank_title}></div><img class="comUserRankImg" src="<{$zarilia_upload_url}>/<{$comment.poster.rank_image}>" alt="" /></div><img class="comUserImg" src="<{$zarilia_upload_url}>/<{$comment.poster.avatar}>" alt="" /><div class="comUserStat"><span class="comUserStatCaption"><{$lang_joined}>:</span> <{$comment.poster.regdate}></div><div class="comUserStat"><span class="comUserStatCaption"><{$lang_from}>:</span> <{$comment.poster.from}></div><div class="comUserStat"><span class="comUserStatCaption"><{$lang_posts}>:</span> <{$comment.poster.postnum}></div><div class="comUserStatus"><{$comment.poster.status}></div></td>\r\n\r\n          <{else}>\r\n\r\n          <td class="odd"> </td>\r\n\r\n          <{/if}>\r\n\r\n          <td class="odd">\r\n            <div class="comTitle"><{$comment.image}><{$comment.title}></div><div class="comText"><{$comment.text}></div>\r\n          </td>\r\n        </tr>\r\n        <tr>\r\n          <td class="even"></td>\r\n\r\n          <{if $zarilia_iscommentadmin == true}>\r\n\r\n          <td class="even" align="right">\r\n            <a href="<{$editcomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/edit.gif" alt="<{$lang_edit}>" /></a><a href="<{$deletecomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/delete.gif" alt="<{$lang_delete}>" /></a><a href="<{$replycomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/reply.gif" alt="<{$lang_reply}>" /></a>\r\n          </td>\r\n\r\n          <{elseif $zarilia_isuser == true && $zarilia_userid == $comment.poster.id}>\r\n\r\n          <td class="even" align="right">\r\n            <a href="<{$editcomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/edit.gif" alt="<{$lang_edit}>" /></a><a href="<{$replycomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/reply.gif" alt="<{$lang_reply}>" /></a>\r\n          </td>\r\n\r\n          <{elseif $zarilia_isuser == true || $anon_canpost == true}>\r\n\r\n          <td class="even" align="right">\r\n            <a href="<{$replycomment_link}>&amp;com_id=<{$comment.id}>"><img src="<{$zarilia_url}>/images/icons/reply.gif" alt="<{$lang_reply}>" /></a>\r\n          </td>\r\n\r\n          <{else}>\r\n\r\n          <td class="even"> </td>\r\n\r\n          <{/if}>\r\n\r\n        </tr>\r\n<!-- end comment post -->'),
(747, '<table class="outer" cellpadding="5" cellspacing="1">\r\n  <tr>\r\n    <th width="20%"><{$lang_poster}></td>\r\n    <th><{$lang_thread}></td>\r\n  </tr>\r\n  <{foreach item=comment from=$comments}>\r\n    <{include file="db:system_comment.html" comment=$comment}>\r\n  <{/foreach}>\r\n</table>'),
(748, '<{section name=i loop=$comments}>\r\n<br />\r\n<table cellspacing="1" class="outer">\r\n  <tr>\r\n    <th width="20%"><{$lang_poster}></th>\r\n    <th><{$lang_thread}></th>\r\n  </tr>\r\n  <{include file="db:system_comment.html" comment=$comments[i]}>\r\n</table>\r\n\r\n<{if $show_threadnav == true}>\r\n<div style="text-align:left; margin:3px; padding: 5px;">\r\n<a href="<{$comment_url}>"><{$lang_top}></a> | <a href="<{$comment_url}>&amp;com_id=<{$comments[i].pid}>&amp;com_rootid=<{$comments[i].rootid}>#newscomment<{$comments[i].pid}>"><{$lang_parent}></a>\r\n</div>\r\n<{/if}>\r\n\r\n<{if $comments[i].show_replies == true}>\r\n<!-- start comment tree -->\r\n<br />\r\n<table cellspacing="1" class="outer">\r\n  <tr>\r\n    <th width="50%"><{$lang_subject}></th>\r\n    <th width="20%" align="center"><{$lang_poster}></th>\r\n    <th align="right"><{$lang_posted}></th>\r\n  </tr>\r\n  <{foreach item=reply from=$comments[i].replies}>\r\n  <tr>\r\n    <td class="even"><{$reply.prefix}> <a href="<{$comment_url}>&amp;com_id=<{$reply.id}>&amp;com_rootid=<{$reply.root_id}>"><{$reply.title}></a></td>\r\n    <td class="odd" align="center"><{$reply.poster.uname}></td>\r\n    <td class="even" align="right"><{$reply.date_posted}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n</table>\r\n<!-- end comment tree -->\r\n<{/if}>\r\n\r\n<{/section}>'),
(749, '<{section name=i loop=$comments}>\r\n<br />\r\n<table cellspacing="1" class="outer">\r\n  <tr>\r\n    <th width="20%"><{$lang_poster}></th>\r\n    <th><{$lang_thread}></th>\r\n  </tr>\r\n  <{include file="db:system_comment.html" comment=$comments[i]}>\r\n</table>\r\n\r\n<!-- start comment replies -->\r\n<{foreach item=reply from=$comments[i].replies}>\r\n<br />\r\n<table cellspacing="0" border="0">\r\n  <tr>\r\n    <td width="<{$reply.prefix}>"></td>\r\n    <td>\r\n      <table class="outer" cellspacing="1">\r\n        <tr>\r\n          <th width="20%"><{$lang_poster}></th>\r\n          <th><{$lang_thread}></th>\r\n        </tr>\r\n        <{include file="db:system_comment.html" comment=$reply}>\r\n      </table>\r\n    </td>\r\n  </tr>\r\n</table>\r\n<{/foreach}>\r\n<!-- end comment tree -->\r\n<{/section}>'),
(750, '<{$dummy_content}>'),
(751, '<h4><{$smarty.const._NOT_ACTIVENOTIFICATIONS}></h4>\r\n<form name="notificationlist" action="notifications.php" method="post">\r\n<table width="100%" border="0" callpadding="2" cellspacing="1">\r\n  <tr>\r\n    <th><input name="allbox" id="allbox" onclick="zariliaCheckGroup(''notificationlist'', ''allbox'', ''del_mod[]'');" type="checkbox" value="<{$smarty.const._NOT_CHECKALL}>" /></th>\r\n    <th><{$smarty.const._NOT_EVENT}></th>\r\n    <th><{$smarty.const._NOT_CATEGORY}></th>\r\n    <th><{$smarty.const._NOT_ITEMID}></th>\r\n    <th><{$smarty.const._NOT_ITEMNAME}></th>\r\n  </tr>\r\n  <{if $addons}>\r\n  <{foreach item=addon from=$addons}>\r\n  <tr>\r\n    <td class="head"><input name="del_mod[<{$addon.id}>]" id="del_mod[]" onclick="zariliaCheckGroup(''notificationlist'', ''del_mod[<{$addon.id}>]'', ''del_not[<{$addon.id}>][]'');" type="checkbox" value="<{$addon.id}>" /></td>\r\n    <td class="head" colspan="4"><{$smarty.const._NOT_ADDON}>: <{$addon.name}></td>\r\n  </tr>\r\n  <{foreach item=category from=$addon.categories}>\r\n  <{foreach item=item from=$category.items}>\r\n  <{foreach item=notification from=$item.notifications}>\r\n  <tr>\r\n    <{cycle values=odd,even assign=class}>\r\n    <td class="<{$class}>"><input type="checkbox" name="del_not[<{$addon.id}>][]" id="del_not[<{$addon.id}>][]" value="<{$notification.id}>" /></td>\r\n    <td class="<{$class}>"><{$notification.event_title}></td>\r\n    <td class="<{$class}>"><{$notification.category_title}></td>\r\n    <td class="<{$class}>"><{if $item.id != 0}><{$item.id}><{/if}></td>\r\n    <td class="<{$class}>"><{if $item.id != 0}><{if $item.url != ''''}><a href="<{$item.url}>"><{/if}><{$item.name}><{if $item.url != ''''}></a><{/if}><{/if}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n  <{/foreach}>\r\n  <{/foreach}>\r\n  <{/foreach}>\r\n  <{else}>\r\n   <tr><td class="even" colspan="5" align="center"><{$smarty.const._NOT_NONOTSFOUND}></td></tr>\r\n  <{/if}>\r\n  <tr>\r\n    <td class="foot" colspan="5"><br />\r\n      <input type="submit" class="formbutton" name="delete_cancel" value="<{$smarty.const._CANCEL}>" />\r\n      <input type="reset" class="formbutton" name="delete_reset" value="<{$smarty.const._NOT_CLEAR}>" />\r\n      <input type="submit" class="formbutton" name="delete" value="<{$smarty.const._DELETE}>" />\r\n    </td>\r\n  </tr>\r\n</table>\r\n</form>'),
(752, '<{if $zarilia_notification.show}>\r\n<form name="notification_select" action="<{$zarilia_notification.target_page}>" method="post">\r\n<h4 style="text-align:center;"><{$lang_activenotifications}></h4>\r\n<input type="hidden" name="not_redirect" value="<{$zarilia_notification.redirect_script}>" />\r\n<table class="outer">\r\n  <tr><th colspan="3"><{$lang_notificationoptions}></th></tr>\r\n  <tr>\r\n    <td class="head"><{$lang_category}></td>\r\n    <td class="head"><input name="allbox" id="allbox" onclick="zariliaCheckAll(''notification_select'',''allbox'');" type="checkbox" value="<{$lang_checkall}>" /></td>\r\n    <td class="head"><{$lang_events}></td>\r\n  </tr>\r\n  <{foreach name=outer item=category from=$zarilia_notification.categories}>\r\n  <{foreach name=inner item=event from=$category.events}>\r\n  <tr>\r\n    <{if $smarty.foreach.inner.first}>\r\n    <td class="even" rowspan="<{$smarty.foreach.inner.total}>"><{$category.title}></td>\r\n    <{/if}>\r\n    <td class="odd">\r\n    <{counter assign=index}>\r\n    <input type="hidden" name="not_list[<{$index}>][params]" value="<{$category.name}>,<{$category.itemid}>,<{$event.name}>" />\r\n    <input type="checkbox" id="not_list[]" name="not_list[<{$index}>][status]" value="1" <{if $event.subscribed}>checked="checked"<{/if}> />\r\n    </td>\r\n    <td class="odd"><{$event.caption}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n  <{/foreach}>\r\n  <tr>\r\n    <td class="foot" colspan="3" align="center"><input type="submit" class="formbutton" name="not_submit" value="<{$lang_updatenow}>" /></td>\r\n  </tr>\r\n</table>\r\n<div align="center">\r\n<{$lang_notificationmethodis}>:&nbsp;<{$user_method}>&nbsp;&nbsp;[<a href="<{$editprofile_url}>"><{$lang_change}></a>]\r\n</div>\r\n</form>\r\n<{/if}>'),
(753, '<h4 style="text-align:left;"><{$lang_headlines}></h4>\r\n<div style=''padding: 1px; text-align: left;''>\r\n      <ul style="list-style-image:url(images/rss.gif);">\r\n      <!-- start site loop -->\r\n      <{foreach item=site from=$feed_sites}>\r\n        <li>&nbsp;<a href="<{$zarilia_url}>/index.php?page_type=rss&amp;id=<{$site.id}>"><{$site.name}></a></li>\r\n      <{/foreach}>\r\n      <!-- end site loop -->\r\n      </ul>\r\n</div>\r\n\r\n<{$headline}>'),
(754, '<table cellspacing="1" class="outer">\r\n  <tr>\r\n    <th colspan="3"><a href="<{$channel.link}>" target="_blank"><{$channel.title}></a></th>\r\n  </tr>\r\n  <tr>\r\n    <td width="25%" rowspan="6">\r\n      <{if $image.url != ""}>\r\n        <img src="<{$image.url}>" width="<{$image.width|default:88}>" height="<{$image.height|default:31}>" alt="<{$image.title}>" />\r\n      <{else}>\r\n        &nbsp;\r\n      <{/if}>\r\n    </td>\r\n    <td valign="top" class="head"><{$lang_lastbuild}></td>\r\n    <td class="odd"><{$channel.lastbuilddate|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <tr>\r\n    <td valign="top" class="head"><{$lang_description}></td>\r\n    <td class="even"><{$channel.description|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <tr>\r\n    <td valign="top" class="head"><{$lang_webmaster}></td>\r\n    <td class="odd"><{$channel.webmaster|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <tr>\r\n    <td valign="top" class="head"><{$lang_category}></td>\r\n    <td class="even"><{$channel.category|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <tr>\r\n    <td valign="top" class="head"><{$lang_generator}></td>\r\n    <td class="odd"><{$channel.generator|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <tr>\r\n    <td valign="top" class="head"><{$lang_language}></td>\r\n    <td class="even"><{$channel.language|default:"&nbsp;"}></td>\r\n  </tr>\r\n  <{section name=i loop=$items}>\r\n  <{if $items[i].title != ""}>\r\n  <tr class="head">\r\n    <td colspan="3"><a id="<{$items[i].link}>"></a><a href="<{$items[i].link}>" target="_blank"><{$items[i].title}></a></td>\r\n  </tr>\r\n  <{/if}>\r\n  <{if $show_full == true}>\r\n    <{if $items[i].category != ""}>\r\n    <tr>\r\n      <td class="even" valign="top"><{$lang_category}></td>\r\n      <td class="odd" colspan="2"><{$items[i].category}>\r\n    </tr>\r\n    <{/if}>\r\n    <{if $items[i].pubdate != ""}>\r\n    <tr>\r\n      <td class="even" valign="top"><{$lang_pubdate}>:</td>\r\n      <td class="odd" colspan="2"><{$items[i].pubdate}></td>\r\n    </tr>\r\n    <{/if}>\r\n    <{if $items[i].description != ""}>\r\n    <tr>\r\n      <td class="even" valign="top"><{$lang_description}>:</td>\r\n      <td colspan="2" class="odd"><{$items[i].description}><{if $items[i].guid != ""}>&nbsp;&nbsp;<a href="<{$items[i].guid}>" target="_blank"><{$lang_more}></a><{/if}></td>\r\n    </tr>\r\n    <{elseif $items[i].guid != ""}>\r\n    <tr>\r\n      <td class="even" valign="top"></td>\r\n      <td colspan="2" class="odd"><a href="<{$items[i].guid}>" target="_blank"><{$lang_more}></a></td>\r\n    </tr>\r\n    <{/if}>\r\n  <{/if}>\r\n  <{/section}>\r\n</table>'),
(755, '<{if $content_title}>\r\n <h3><{$content_title}></h3>\r\n<{/if}>\r\n\r\n<{if $zarilia_showheader}>\r\n	<{if $content_avatar}>\r\n		<{$content_avatar}>\r\n	<{/if}>\r\n\r\n	<{if $content_author}>\r\n	 <div><{$smarty.const._CONTENT_AUTHOR}><{$content_author}></div>\r\n	<{/if}>\r\n\r\n	<{if $content_published}>\r\n	 <div><{$smarty.const._CONTENT_PUBLISHED}><{$content_published}></div><br />\r\n	<{/if}>\r\n<{/if}>\r\n\r\n<div align="right"><{$content_icons}></div>\r\n<{if $content_subtitle}>\r\n <div><strong><{$content_subtitle}></strong></div><br />\r\n<{/if}>\r\n\r\n<{if $content_body}>\r\n <{if $content_intro}>\r\n  <div><{$content_intro}></div><br />\r\n <{/if}>\r\n <div><{$content_body}></div>\r\n<{/if}>\r\n\r\n<{if $zarilia_showheader}>\r\n	<{if $content_updated}>\r\n	 <br /><div><i><{$smarty.const._CONTENT_UPDATED}><{$content_updated}></i></div><br />\r\n	<{/if}>\r\n<{/if}>'),
(756, '<h3></h3>\r\n<h3 style="text-align: left; color: Red;"><{$error_title}></h3>\r\n<div style="text-align:left;"><strong><{$error_heading}></strong></div><br />\r\n<div style="text-align:left;"><{$error_description}></div>\r\n\r\n<{if $error_link }>\r\n <div><{$error_link}></div><br />\r\n<{/if}>\r\n\r\n<{if $error_footer }>\r\n <div><{$error_footer}></div><br />\r\n<{/if}>'),
(757, '<{if $section_title}>\r\n <h3><{$section_title}></h3>\r\n<{/if}>\r\n\r\n<table width="100%" cellpadding="2" cellspacing="1" border="0" class="contentpane">\r\n <tr>\r\n  <td valign="top" class="contentdescription">\r\n	<{if $section_image}>\r\n	 <{$section_image}>\r\n	<{/if}>\r\n	<{if $section_description}>\r\n	 	<{$section_description}>\r\n	<{/if}>\r\n  </td>\r\n </tr>\r\n</table>\r\n\r\n<h3><{$smarty.const._CONTENT_LATESTBLOGS}></h3>\r\n<{foreach item=content from=$content}>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td height="20" colspan="2" class="sectiontableheader"><a href="<{$zarilia_url}>/index.php?page_type=blog&amp;id=<{$content.content_id}>" class="category"><{$content.content_title}></a></td>\r\n  </tr>\r\n  <tr class="sectiontableentry1">\r\n    <{if $content.content_images}>\r\n	  <td width="100" height="20" style="text-align: center;"><a href="<{$zarilia_url}>/index.php?page_type=blog&amp;id=<{$content.content_id}>" class="category"><{$content.content_images}></a></td>\r\n    <{/if}>\r\n	<td width="90%" height="20" valign="top">\r\n	 <{$smarty.const._CONTENT_POSTEDBY}><{$content.content_author}>&nbsp;<{$smarty.const._CONTENT_POSTEDON}><{$content.content_published}><br /><br /><{$content.content_intro}>\r\n	</td>\r\n  </tr>\r\n</table>\r\n<div style=''text-align: right;''><a href="<{$zarilia_url}>/index.php?page_type=blog&amp;id=<{$content.content_id}>" class="category"><{$smarty.const._CONTENT_CONTINUE}> ''<{$content.content_title}>''......</a></div><br />\r\n<{/foreach}>\r\n\r\n<br /><div style="text-align: left;"><{$page_nav}></div>\r\n\r\n<{$page_backbutton}>'),
(758, '<{if $section_title}>\r\n <div class="header"><{$section_title}></div>\r\n<{/if}>\r\n\r\n<table width="100%" cellspacing="0" border="0">\r\n <tr>\r\n  <td valign="top">\r\n	<{if $section_image != ''''}><{$section_image}><{/if}>\r\n	<{if $section_description}><{$section_description}><{/if}>\r\n  </td>\r\n </tr>\r\n</table>\r\n\r\n<div class="latest"><{$smarty.const._CONTENT_LATESTNEWS}></div>\r\n<{foreach item=content from=$content}>\r\n<table id="news" cellspacing="0">\r\n  <tr>\r\n    <td height="20" colspan="2" class="newstitle"><a href="<{$zarilia_url}>/index.php?page_type=news&amp;id=<{$content.content_id}>" class="category"><{$content.content_title}></a></td>\r\n  </tr>\r\n  <tr class="newscontent">\r\n    <{if $content.content_images}>\r\n	  <td width="100" height="20" style="text-align: center;"><a href="<{$zarilia_url}>/index.php?page_type=news&amp;id=<{$content.content_id}>" class="category"><{$content.content_images}></a></td>\r\n    <{/if}>\r\n	<td width="90%" height="20" valign="top">\r\n	 <div class="news"><{$smarty.const._CONTENT_POSTEDBY}><{$content.content_author}>&nbsp;<{$smarty.const._CONTENT_POSTEDON}><{$content.content_published}></div>\r\n	 <div class="newscontent"><{$content.content_intro}></div>\r\n	</td>\r\n  </tr>\r\n</table>\r\n<div class="nav"><a class="morelink" href="<{$zarilia_url}>/index.php?page_type=news&amp;id=<{$content.content_id}>"><{$smarty.const._CONTENT_CONTINUE}> ''<{$content.content_title}>''......</a></div><br />\r\n<{/foreach}>\r\n<br /><div style="text-align: left;"><{$page_nav}></div>\r\n<{$page_backbutton}>'),
(759, '<{if $section_title}>\r\n <h3><{$section_title}></h3>\r\n<{/if}>\r\n\r\n<table width="100%" cellpadding="2" cellspacing="1" border="0" class="streamingpane">\r\n <tr>\r\n  <td valign="top" class="streamingdescription">\r\n	<{if $section_image}>\r\n	 <{$section_image}>\r\n	<{/if}>\r\n	<{if $section_description}>\r\n	 	<{$section_description}>\r\n	<{/if}>\r\n  </td>\r\n </tr>\r\n</table>\r\n\r\n<h3><{$smarty.const._CONTENT_STREAMS}></h3>\r\n<{foreach item=streaming from=$streaming}>\r\n<table width="100%" border="0" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td height="20" colspan="2" class="sectiontableheader"><a href="javascript:openWithSelfMain(''<{$zarilia_url}>/misc.php?op=showpopups&type=play&amp;id=<{$streaming.streaming_id}>'',''Play Media'',420,350);" class="category"><{$streaming.streaming_title}></a></td>\r\n  </tr>\r\n  <tr class="sectiontableentry1">\r\n    <{if $streaming.streaming_image}>\r\n	  <td width="100" height="20" style="text-align: center;"><a href="javascript:openWithSelfMain(''<{$zarilia_url}>/misc.php?op=showpopups&type=play&amp;id=<{$streaming.streaming_id}>'',''Play Media'',420,350);" class="category"><{$streaming.streaming_image}></a></td>\r\n    <{/if}>\r\n	<td width="90%" height="20" valign="top">\r\n	 <{$smarty.const._CONTENT_POSTEDBY}><{$streaming.streaming_author}>&nbsp;<{$smarty.const._CONTENT_POSTEDON}><{$streaming.streaming_published}><br /><br /><{$streaming.streaming_intro}>\r\n	<div><{$streaming.streaming_description}></div>\r\n	</td>\r\n  </tr>\r\n</table>\r\n<div style=''text-align: right;''>\r\n<a href="javascript:openWithSelfMain(''<{$zarilia_url}>/misc.php?op=showpopups&type=play&amp;id=<{$streaming.streaming_id}>'',''Play Media'',420,350);"><{$streaming.streaming_play}></a>\r\n<a href="<{$zarilia_url}>/download.php?page_type=stream&amp;id=<{$streaming.streaming_id}>" class="category"><{$streaming.streaming_download}></a>\r\n</div><br />\r\n<{/foreach}>\r\n\r\n<br /><div style="text-align: left;"><{$page_nav}></div>\r\n\r\n<{$page_backbutton}>'),
(760, '<h2><{$smarty.const._US_LOSTPASSWORD}></h2>\r\n<div><{$smarty.const._US_NOPROBLEM}></div>\r\n<h3><{$smarty.const._US_PASSWORDRETRIEVAL}></h3>\r\n<div style="margin-left: 20px;"><{$smarty.const._US_NOPROBLEM}></div>\r\n\r\n<form style="margin: 0px; padding: 0px;" id="lostpass" action="index.php" method="post">\r\n <input type="hidden" name="op" value="mailpasswd" />\r\n <input type="hidden" name="page_type" value="user" />\r\n <input type="hidden" name="act" value="lostconfirm" />\r\n  <table width="90%" border="0" cellspacing="1" cellpadding="2" summary="">\r\n    <tr>\r\n      <td style="text-align: right; padding-right: 5px;" width="30%"><b><{$smarty.const._US_YOUREMAIL}></b></td>\r\n      <td><input type="text" name="email" size="21" maxlength="32" /></td>\r\n    </tr>\r\n    <tr>\r\n      <td>&nbsp;</td>\r\n      <td><input type="submit" class="formbutton" value="<{$smarty.const._US_SENDPASSWORD}>" />	</td>\r\n    </tr>\r\n    <tr>\r\n      <td>&nbsp;</td>\r\n      <td><b><{$smarty.const._US_LOSTCLICK}></b></div></td>\r\n    </tr>\r\n  </table>\r\n\r\n</form>'),
(761, '<script type="text/javascript"><{$registerform.javascript}></script>\r\n\r\n<form name="<{$registerform.name}>" action="<{$registerform.op}>" method="<{$registerform.method}>" <{$registerform.extra}>>\r\n<table width="100%" align="center" cellspacing="0" cellpadding="0">\r\n  <tr>\r\n    <td colspan="3" align="left"><h3><{$smarty.const._US_REG_FORM_HEADING}></h3>\r\n      <div class=''register_login''><{$smarty.const._US_REGALREADYHAVE}> <a href="<{$zarilia_url}>/index.php?page_type=user" target="_blank"><{$smarty.const._US_REGSIGNIN}></a></div>\r\n      <table id="content">\r\n        <tr>\r\n          <td class=''register_title''><{$title}></td>\r\n        </tr>\r\n<{if $subtitle}>\r\n        <tr>\r\n          <td class=''register_subtitle''><{$subtitle}></td>\r\n        </tr>\r\n<{/if}>\r\n        <tr>\r\n          <td class=''register_subtitle''> <table width="100%" cellspacing="0">\r\n              <{if $header}>\r\n			  	<p><{$header}></p>\r\n			  <{/if}>\r\n<input type="hidden" name="page_type" value="register" />\r\n<{foreach item=element from=$registerform.elements}> <{if $element.hidden != true}> <{if $element.split }> <{$element.split}> <{else}>\r\n              <tr>\r\n                <td class="itemHead" width="40%"> <b><{$element.caption}> <{if $element.required}>* Required<{/if}></b>\r\n				<{if $element.description }> <div><span style="font-weight: normal;"><{$element.description}></span></div> <{/if}> </td>\r\n                <td class="itemBody"><{$element.body}></td>\r\n<{/if}> </tr>\r\n<{else}> <{$element.body}> <{/if}> <{/foreach}>\r\n            </table>\r\n			</td>\r\n        </tr>\r\n        <table align="center" cellspacing="0" cellpadding="0" id="buttons">\r\n          <tr>\r\n            <td width=''10%''>&nbsp;</td>\r\n            <td width=''25%'' align=''left'' nowrap=''nowrap''><{$b_back}></td>\r\n            <td width=''20%'' align=''center''><{$b_reload}> <{$b_restart}></td>\r\n            <td width=''25%'' align=''right'' nowrap=''nowrap''><{$b_next}></td>\r\n            <td width=''10%''>&nbsp;</td>\r\n          </tr>\r\n        </table>\r\n      </table></td>\r\n    <td width=''10%''><br />\r\n<{$stepbar}></td>\r\n    <td width=''2%''>&nbsp;</td>\r\n  </tr>\r\n</table>\r\n</form>'),
(762, '<script type="text/javascript"><{$zariliaform.javascript}></script>\r\n\r\n<div class="zar_title"><{$title}></div>\r\n<div class="zar_subtitle"><{$subtitle}></div><br />\r\n\r\n<{if $menubar}>\r\n	<div class="zar_heading"><{$menubar}></div>\r\n<{/if}>\r\n<table width="100%" cellspacing="0">\r\n<{if $header }>\r\n	<tr>\r\n		<th><{$header}></th>\r\n	</tr>\r\n<{/if}>\r\n<form name="<{$zariliaform.name}>" action="<{$zariliaform.op}>" method="<{$zariliaform.method}>" <{$zariliaform.extra}>>\r\n<input type="hidden" name="page_type" value="<{$page_type}>" />\r\n<{foreach item=element from=$zariliaform.elements}> <{if $element.hidden != true}> <{if $element.split }> <{$element.split}> <{else}>\r\n	<tr>\r\n		<td width="35%" class="itemHead"><b><{$element.caption}> <{if $element.required}>* Required<{/if}></b> <{if $element.description }> <br /><span style="font-weight: normal;"><{$element.description}></span> <{/if}> </td>\r\n        <td><{$element.body}></td>\r\n<{/if}>\r\n	</tr>\r\n<{else}> <{$element.body}> <{/if}> <{/foreach}>\r\n	</form>\r\n</table>');
INSERT INTO `cztsd_tplsource` (`tpl_id`, `tpl_source`) VALUES
(763, '<div style="padding-bottom: 12px; text-align: left; font-weight: normal;"><{$smarty.const._US_USER_DETAILS}></div>\r\n<form action="index.php?page_type=friend" method="post">\r\n  <input type="hidden" name="send" value="-1">\r\n  <input type="hidden" name="url" value="">\r\n  <input type="hidden" name="sign" value="">\r\n  <input type="hidden" name="uid" value="<{$sender.uid}>">\r\n  <input type="hidden" name="cc" value="">\r\n  <input type="hidden" name="style" value="1">\r\n  <input type="hidden" name="subject" value="">\r\n  <input type="hidden" name="more" value="">\r\n  <div align="center">\r\n    <center>\r\n      <table width="100%" cellpadding="2" cellspacing="1" border="0" width="100%">\r\n		<tr>\r\n          <td class="head" width="35%">To Name:</td>\r\n		  <td><input type="text" name="toname" size="23"></td>\r\n        </tr>\r\n        <tr>\r\n          <td class="head">To E-mail:*</td>\r\n		  <td><input type="text" name="to email" size="23"></td>\r\n        </tr>\r\n        <tr>\r\n          <td class="head">From Name</td>\r\n          <td><input type="text" name="fromname" size="23" value=""></td>\r\n        </tr>\r\n        <tr>\r\n          <td class="head">From E-mail:*</td>\r\n          <td><input type="text" name="from email" size="23" value=""></td>\r\n        </tr>\r\n        <tr>\r\n          <td class="head">Message </td>\r\n          <td><textarea name="text" rows="4" cols="26">You might be interested in this</textarea></td>\r\n          <!---->\r\n        </tr>\r\n        <tr>\r\n          <td colspan="2"> <div align="center"> Send a copy to yourself:\r\n              <input type="checkbox" name="q2" value="1">\r\n              <br>\r\n              <!-- -->\r\n              Opt-in to our newsletter\r\n              <input type="checkbox" name="q1" value="1">\r\n            </div></td>\r\n        </tr>\r\n      </table>\r\n      <p>\r\n        <input type="submit" value="Submit">\r\n        <input type="reset" value="Reset">\r\n      </p>\r\n    </center>\r\n  </div>\r\n</form>\r\n\r\n\r\n<table width="100%" cellpadding="2" cellspacing="1">\r\n  <tr>\r\n    <th colspan="2"><{$smarty.const._US_USER_DETAILS_HEADING}></th>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_NICKNAME}></td>\r\n    <td class="even"><input type="text" name="sendername" id="sendername" size="30" maxlength="25" value="" /></td>\r\n  </tr>\r\n\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_EMAIL}></td>\r\n    <td class="even"><input type="text" name="senderemail" id="senderemail" size="40" maxlength="60" value="<{$name}>" /></td>\r\n  </tr>\r\n\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_NAME}></td>\r\n    <td class="even"><input type="text" name="recpname" id="recpname" size="30" maxlength="25" value="" /></td>\r\n  </tr>\r\n\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_EMAIL}></td>\r\n    <td class="even"><input type="text" name="recpemail" id="email" size="40" maxlength="60" value="" /></td>\r\n  </tr>\r\n\r\n\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_EMAIL}></td>\r\n    <td class="even"><div id="">\r\n        <input type="text" name="email" id="email" size="40" maxlength="60" value="<{$name}>" />\r\n        <br />\r\n        <table cellpadding="0" cellspacing="0">\r\n          <tr>\r\n            <td><input type="checkbox" name="user_viewemail" value="<{$user_viewemail}>"/><{$smarty.const._US_ALLOWVIEWEMAIL}></td>\r\n          </tr>\r\n        </table>\r\n      </div></td>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_WEBSITE}></td>\r\n    <td class="even"><input type="text" name="url" id="url" size="40" maxlength="255" value="<{$url}>" /></td>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%">Time Zone: </td>\r\n    <td class="even"><select size="1" name="timezone_offset" id="timezone_offset">\r\n        <option value="-12">(GMT-12:00) International Date Line West</option>\r\n        <option value="-11">(GMT-11:00) Midway Island, Samoa</option>\r\n        <option value="-10">(GMT-10:00) Hawaii</option>\r\n        <option value="-9">(GMT-9:00) Alaska</option>\r\n        <option value="-8">(GMT-8:00) Pacific Time (US &amp; Canada)</option>\r\n        <option value="-7">(GMT-7:00) Mountain Time (US &amp; Canada)</option>\r\n        <option value="-6">(GMT-6:00) Central Time (US &amp; Canada), Mexico City</option>\r\n        <option value="-5">(GMT-5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option>\r\n        <option value="-4">(GMT-4:00) Atlantic Time (Canada), Caracas, La Paz</option>\r\n        <option value="-3.5">(GMT-3:30) St. John`s, Newfoundland and Labrador</option>\r\n        <option value="-3">(GMT-3:00) Brasilia, Buenos Aires, Georgetown</option>\r\n        <option value="-2">(GMT-2:00) Mid-Atlantic</option>\r\n        <option value="-1">(GMT-1:00) Azores, Cape Verde Islands</option>\r\n        <option value="0" selected="selected">(GMT) Western Europe Time, London, Lisbon, Casablanca</option>\r\n        <option value="1">(GMT+1:00) Berlin, Brussels, Copenhagen, Madrid, Paris</option>\r\n        <option value="2">(GMT+2:00) Kaliningrad, South Africa</option>\r\n        <option value="3">(GMT+3:00) Baghdad, Riyadh, Moscow, St. Petersburg<</option>\r\n        <option value="3.5">(GMT+3:30) Tehran</option>\r\n        <option value="4">(GMT+4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option>\r\n        <option value="4.5">(GMT+4:30) Kabul</option>\r\n        <option value="5">(GMT+5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option>\r\n        <option value="5.5">(GMT+5:30) Bombay, Calcutta, Madras, New Delhi</option>\r\n        <option value="6">(GMT+6:00) Almaty, Dhaka, Colombo</option>\r\n        <option value="7">(GMT+7:00) Bangkok, Hanoi, Jakarta</option>\r\n        <option value="8">(GMT+8:00) Beijing, Perth, Singapore, Hong Kong</option>\r\n        <option value="9">(GMT+9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option>\r\n        <option value="9.5">(GMT+9:30) Adelaide, Darwin, Yakutsk</option>\r\n        <option value="10">(GMT+10:00) Eastern Australia, Guam, Vladivostok</option>\r\n        <option value="11">(GMT+11:00) Magadan, Solomon Islands, New Caledonia</option>\r\n        <option value="12">(GMT+12:00) Auckland, Wellington, Fiji, Kamchatka</option>\r\n      </select></td>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_MAILOK}></td>\r\n    <td class="even"><input type="radio" name="user_mailok" value="1" <{if $user_mailok == 1}>checked="checked"<{/if}> />\r\n      Yes\r\n      <input type="radio" name="user_mailok" value="0"\r\n	  <{if $user_mailok == 0}>checked="checked"<{/if}>\r\n	  />\r\n      No </td>\r\n  </tr>\r\n  <tr>\r\n    <td colspan="2" class="foot">&nbsp;</td>\r\n  </tr>\r\n</table>\r\n<br />\r\n<br />\r\n<table width="100%" class="outer" cellspacing="1">\r\n  <tr>\r\n    <th colspan="2"><{$smarty.const._US_USER_LOGIN_HEADING}></th>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_LOGINNAME}></td>\r\n    <td class="even"><input type="text" name="login" id="login" size="30" maxlength="25" value="<{$login}>" /></td>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_PASSWORD}></td>\r\n    <td class="even">\r\n      <script type="text/javascript">\r\n			var qualityName1 = "<{$smarty.const._MD_AM_PASSLEVEL1}>";\r\n			var qualityName2 = "<{$smarty.const._MD_AM_PASSLEVEL2}>";\r\n			var qualityName3 = "<{$smarty.const._MD_AM_PASSLEVEL3}>";\r\n			var qualityName4 = "<{$smarty.const._MD_AM_PASSLEVEL4}>";\r\n			var qualityName5 = "<{$smarty.const._MD_AM_PASSLEVEL5}>";\r\n			var qualityName6 = "<{$smarty.const._MD_AM_PASSLEVEL6}>";\r\n			var passField = "pass";\r\n			var tipo = "1";\r\n			var tipo1 = "1";\r\n			var minpass = "5";\r\n			var pass_level = "60";\r\n			</script>\r\n      <input type="hidden" name="regex" value="[^0-9]">\r\n      <input type="hidden" name="regex3" value="([0-9])\\1+">\r\n      <input type="hidden" name="regex1" value="[0-9a-zA-Z]">\r\n      <input type="hidden" name="regex4" value="(\\W)\\1+">\r\n      <input type="hidden" name="regex2" value="[^A-Z]">\r\n      <input type="hidden" name="regex5" value="([A-Z])\\1+">\r\n      <input type="password" name="pass" id="pass" size="10" maxlength="32" value="<{$pass}>" /> &nbsp;\r\n      <input type="password" name="pass2" id="vpass" size="v10" maxlength="32" value="<{$pass2}>" />\r\n      <!--<script language="javascript" src="<{$zarilia_url}>/include/javascript/percent_bar.js"></script>-->\r\n	</td>\r\n  </tr>\r\n  <tr valign="top" align="left">\r\n    <td class="head" width="35%"><{$smarty.const._US_CREATEPASSWORD}></td>\r\n    <td class="even"><select name="type">\r\n        <option selected>Choose Type</option>\r\n        <option>Uppercase letters and numbers</option>\r\n        <option>Lowercase letters and numbers</option>\r\n        <option>Mixed case letters and numbers</option>\r\n      </select>\r\n      <select name="length">\r\n        <option value="0">Choose length</option>\r\n        <option value="1">1 Characters</options>\r\n        <option value="2">2 Characters</options>\r\n        <option value="3">3 Characters</options>\r\n        <option value="4">4 Characters</options>\r\n        <option value="5">5 Characters</options>\r\n        <option value="6">6 Characters</options>\r\n        <option value="7">7 Characters</options>\r\n        <option value="8">8 Characters</options>\r\n        <option value="9">9 Characters</options>\r\n        <option value="10">10 Characters</options>\r\n        <option value="11">11 Characters</options>\r\n        <option value="12">12 Characters</options>\r\n        <option value="13">13 Characters</options>\r\n        <option value="14">14 Characters</options>\r\n        <option value="15">15 Characters</options>\r\n        <option value="16" selected="selected">16 Characters</options>\r\n        <option value="17">17 Characters</options>\r\n        <option value="18">18 Characters</options>\r\n        <option value="19">19 Characters</options>\r\n        <option value="20">20 Characters</options>\r\n        <option value="21">21 Characters</options>\r\n        <option value="22">22 Characters</options>\r\n        <option value="23">23 Characters</options>\r\n        <option value="24">24 Characters</options>\r\n        <option value="25">25 Characters</options>\r\n        <option value="26">26 Characters</options>\r\n        <option value="27">27 Characters</options>\r\n        <option value="28">28 Characters</options>\r\n        <option value="29">29 Characters</options>\r\n        <option value="30">30 Characters</options>\r\n        <option value="31">31 Characters</options>\r\n      </select>\r\n      <br />\r\n      <input type="hidden" name="autoupdate" value="true">\r\n      <input type="text" name="password" size="20" readonly="readonly">\r\n      <br />\r\n      <input type="button" name="Generate Password"  id="Generate Password" value="Generate Password" onClick="generate(this.form, true);" /></td>\r\n  </tr>\r\n  <input type="hidden" name="verification_ver" id="verification_ver" value="<{$verification_ver}>" />\r\n  <tr class="foot">\r\n    <td colspan="2">* =  Required</td>\r\n  </tr>\r\n</table>\r\n<div><{$smarty.const._US_DISPLAY_PRIVACY}></div>'),
(782, '<{if $topic_rssfeed_link != ""}>\r\n<div align=''right''><{$topic_rssfeed_link}></div>\r\n<{/if}>\r\n\r\n<{if $displaynav == true}>\r\n  <div style="text-align: center;">\r\n    <form name="form1" action="<{$zarilia_url}>/addons/news/index.php" method="get">\r\n    <{$topic_select}> <select name="storynum"><{$storynum_options}></select> <input type="submit" value="<{$lang_go}>" class="formButton" /></form>\r\n  <hr />\r\n  </div>\r\n<{/if}>\r\n\r\n<{if $topic_description != ''''}>\r\n	<div style="text-align: center;"><{$topic_description}></div>\r\n<{/if}>\r\n\r\n<div style="margin: 10px;"><{$pagenav}></div>\r\n<table width=''100%'' border=''0''>\r\n<tr>\r\n	<{section name=i loop=$columns}>\r\n	<td width="<{$columnwidth}>%"><{foreach item=story from=$columns[i]}><{include file="db:news_item.html" story=$story}><{/foreach}></td>\r\n	<{/section}>\r\n</tr>\r\n</table>\r\n\r\n<div style="text-align: right; margin: 10px;"><{$pagenav}></div>\r\n<{include file=''db:system_notification_select.html''}>'),
(783, '<div class="item">\r\n<table width=''100%'' border=''0''>\r\n<tr>\r\n<{section name=i loop=$columns}>\r\n	<td width="<{$columnwidth}>%" valign="top">\r\n	<{foreach item=topic from=$columns[i]}>\r\n    <div class="itemBody">\r\n    	<div class="itemInfo"><span class="itemText"><a href="<{$zarilia_url}>/addons/news/index.php?storytopic=<{$topic.id}>"><{$topic.title}></a></span></div>\r\n		<{counter start=0 print=false assign=storynum}>\r\n        <{foreach item=story from=$topic.stories}>\r\n        	<{if $storynum == 0}>\r\n        		<{include file="db:news_item.html" story=$story}><br />\r\n			<{else}>\r\n        		<{if $storynum == 1}>\r\n            		<ul>\r\n				<{/if}>\r\n					<li><a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>"><{$story.title}></a> (<{$story.posttime}>)</li>\r\n				<{/if}>\r\n				<{counter}>\r\n			<{/foreach}>\r\n			<{if $storynum > 1}>\r\n				</ul>\r\n				<a href="<{$zarilia_url}>/addons/news/index.php?storytopic=<{$topic.id}>"><{$lang_morereleases}><{$topic.title}></a>\r\n			<{/if}>\r\n	</div><br />\r\n	<{/foreach}>\r\n	</td>\r\n<{/section}>\r\n</tr>\r\n</table>\r\n</div>\r\n<{include file=''db:system_notification_select.html''}>'),
(784, '<h2><{$lang_news_by_this_author}> <{$author_name_with_link}></h2>\r\n<br /><img src=''<{$user_avatarurl}>'' border=''0'' alt='''' />\r\n<br />\r\n<table width=''100%'' border=''0''>\r\n<{foreach item=topic from=$topics}>\r\n	<tr>\r\n		<{if $news_rating}><th colspan=''4''><{else}><th colspan=''3''><{/if}><{$topic.topic_link}></th>\r\n	</tr>\r\n	<tr>\r\n		<td><{$lang_date}></td><td><{$lang_title}></td><td><{$lang_hits}></td><{if $news_rating}><td><{$lang_rating}></td><{/if}>\r\n	</tr>\r\n	<{foreach item=article from=$topic.news}>\r\n	<tr>\r\n		<td><{$article.published}></td><td><{$article.article_link}></td><td align=''right''><{$article.hits}></td><{if $news_rating}><td align=''right''><{$article.rating}></td><{/if}>\r\n	</tr>\r\n	<{/foreach}>\r\n	<tr>\r\n		<td colspan=''2'' align=''left''><{$topic.topic_count_articles}></td>\r\n		<td align=''right''><{$topic.topic_count_reads}></td><{if $news_rating}><td>&nbsp;</td><{/if}>\r\n	</tr>\r\n	<tr><{if $news_rating}><td colspan=''4''><{else}><td colspan=''3''><{/if}>&nbsp;</td></tr>\r\n<{/foreach}>\r\n</table>'),
(785, '<br /><br /><br />\r\n\r\n<hr size="1" noshade="noshade" />\r\n<table border="0" cellpadding="1" cellspacing="0" width="80%" align="center">\r\n<tr>\r\n	<td>\r\n		<h3><{$news.title}></h3>\r\n		<ul>\r\n			<li><{$lang_voteonce}></li>\r\n			<li><{$lang_ratingscale}></li>\r\n			<li><{$lang_beobjective}></li>\r\n			<li><{$lang_donotvote}></li>\r\n		</ul>\r\n	</td>\r\n</tr>\r\n<tr>\r\n	<td align="center">\r\n		<form method="post" action="<{$zarilia_url}>/addons/news/ratenews.php">\r\n		<input type="hidden" name="storyid" value="<{$news.storyid}>" />\r\n		<select name="rating"><option>--</option><option>10</option><option>9</option><option>8</option><option>7</option><option>6</option><option>5</option><option>4</option><option>3</option><option>2</option><option>1</option></select>&nbsp;&nbsp;\r\n        <input type="submit" name="submit" value="<{$lang_rateit}>" /> <input type=''button'' value="<{$lang_cancel}>" onclick="location=''<{$zarilia_url}>/addons/news/article.php?storyid=<{$news.storyid}>''" />\r\n      	</form>\r\n   	</td>\r\n</tr>\r\n</table>'),
(786, '<?xml version="1.0" encoding="UTF-8"?>\r\n<rss version="2.0">\r\n  <channel>\r\n    <title><{$channel_title}></title>\r\n    <link><{$channel_link}></link>\r\n    <description><{$channel_desc}></description>\r\n    <lastBuildDate><{$channel_lastbuild}></lastBuildDate>\r\n    <docs>http://backend.userland.com/rss/</docs>\r\n    <generator><{$channel_generator}></generator>\r\n    <category><{$channel_category}></category>\r\n    <managingEditor><{$channel_editor}></managingEditor>\r\n    <webMaster><{$channel_webmaster}></webMaster>\r\n    <language><{$channel_language}></language>\r\n    <{if $image_url != ""}>\r\n    <image>\r\n      <title><{$channel_title}></title>\r\n      <url><{$image_url}></url>\r\n      <link><{$channel_link}></link>\r\n      <width><{$image_width}></width>\r\n      <height><{$image_height}></height>\r\n    </image>\r\n    <{/if}>\r\n    <{foreach item=item from=$items}>\r\n    <item>\r\n      <title><{$item.title}></title>\r\n      <link><{$item.link}></link>\r\n      <description><{$item.description}></description>\r\n      <pubDate><{$item.pubdate}></pubDate>\r\n      <guid><{$item.guid}></guid>\r\n    </item>\r\n    <{/foreach}>\r\n  </channel>\r\n</rss>'),
(779, '<table cellpadding="0" cellspacing="0" class="item">\r\n<tr>\r\n	<td>\r\n		<table cellpadding="0" cellspacing="0" width="98%">\r\n		<tr>\r\n			<td class="itemHead">\r\n				<span class="itemTitle">\r\n					<a href="<{$zarilia_url}>/addons/news/index.php?storytopic=<{$story.topicid}>"><{$story.topic_title}></a> : <{$story.news_title}>\r\n				</span>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="itemInfo"><{if $story.files_attached}><{$story.attached_link}>&nbsp;<{/if}><{if $story.poster != ''''}><span class="itemPoster"><{$lang_postedby}> <{$story.poster}></span><{/if}> <span class="itemPostDate"><{$lang_on}> <{$story.posttime}></span> (<span class="itemStats"><{$story.hits}> <{$lang_reads}></span>) <{$news_by_the_same_author_link}></td>\r\n		</tr>\r\n		<tr>\r\n			<td class="itemBody"><{$story.imglink}><p class="itemText"><{$story.text}></p></td>\r\n		</tr>\r\n		<tr>\r\n			<td class="itemFoot"><span class="itemAdminLink"><{$story.adminlink}></span><{if $rates}><b><{$lang_ratingc}></b> <{$story.rating}> (<{$story.votes}>) - <a href="<{$zarilia_url}>/addons/news/ratenews.php?storyid=<{$story.id}>" rel="nofollow"><{$lang_ratethisnews}></a> - <{/if}><span class="itemPermaLink"><{$story.morelink}></span></td>\r\n		</tr>\r\n		</table>\r\n	</td>\r\n</tr>\r\n</table>'),
(764, '<script type="text/javascript"><{$zariliaform.javascript}></script>\r\n<div class="zar_title"><{$title}></div>\r\n<div class="zar_subtitle"><{$subtitle}></div><br />\r\n<{if $menubar}>\r\n	<div class="zar_heading"><{$menubar}></div>\r\n<{/if}>\r\n\r\n<{if $allowupload}>\r\n	<div style="text-align: left;"><h4 style="color:#ff0000; font-weight:bold;"><{$smarty.const._US_OLDDELETED}></h4> <img src="<{$zarilia_upload}>/<{$avatar}>" alt="" /></div>\r\n<{/if}>\r\n\r\n<{if $allowupload}>\r\n<table width="100%" cellspacing="0">\r\n	<form name="uploadavatar" method="post" onsubmit="return zariliaFormValidate_uploadavatar();" enctype="multipart/form-data">\r\n	<input type="hidden" name="page_type" value="avatar" />\r\n	<input type="hidden" name="act" value="avatarupload" />\r\n	<tr>\r\n		<td width="35%" class="itemHead"><b><{$smarty.const._US_MAXPIXEL}></b></td>\r\n        <td><{$avatar_width}> x <{$avatar_height}></td>\r\n	</tr>\r\n   	<tr>\r\n		<td class="itemHead"><b><{$smarty.const._US_MAXIMGSZ}></b></td>\r\n        <td><{$avatar_maxsize}></td>\r\n	</tr>\r\n   	<tr>\r\n		<td class="itemHead"><b><{$smarty.const._US_SELFILE}> </b>  </td>\r\n        <td><input type=''hidden'' name=''MAX_FILE_SIZE'' value=''<{$avatar_maxsize}>'' />\r\n			<input type=''file'' name=''avatarfile'' id=''avatarfile'' />\r\n			<input type=''hidden'' name=''zarilia_upload_file[]'' id=''zarilia_upload_file[]'' value=''avatarfile'' />\r\n		</td>\r\n	</tr>\r\n		<input type=''hidden'' name=''uid'' id=''uid'' value=''1'' />\r\n	<tr>\r\n		<td width="45%" class="itemHead"><b> </b>  </td>\r\n        <td><input type=''submit'' class=''formbutton''  name=''submit''  id=''submit'' value=''Submit''  /></td>\r\n	</tr>\r\n 	</form>\r\n</table><br />\r\n<{/if}>\r\n\r\n<table width="100%" cellspacing="0">\r\n<{if $header }>\r\n	<tr>\r\n		<th><{$header}></th>\r\n	</tr>\r\n<{/if}>\r\n	<form name="<{$uploadavatar.name}>" method="<{$uploadavatar.method}>" <{$uploadavatar.extra}>>\r\n	<input type="hidden" name="page_type" value="<{$page_type}>" />\r\n	<{foreach item=element from=$uploadavatar.elements}> <{if $element.hidden != true}> <{if $element.split }> <{$element.split}> <{else}>\r\n	<tr>\r\n		<td width="35%" class="itemHead"><b><{$element.caption}> <{if $element.required}>* Required<{/if}></b> <{if $element.description }> <br /><span style="font-weight: normal;"><{$element.description}></span> <{/if}> </td>\r\n        <td><{$element.body}></td>\r\n<{/if}>\r\n	</tr>\r\n<{else}> <{$element.body}> <{/if}> <{/foreach}>\r\n	</form>\r\n</table>'),
(781, '<{if $pagenav}><div style="text-align: left; margin: 10px;"><{$smarty.const._NW_PAGE}> <{$pagenav}></div><{/if}>\r\n\r\n<div style="padding: 3px; margin-right:3px;"><{include file="db:news_item.html" story=$story}></div>\r\n\r\n<{if $attached_files_count>0}>\r\n	<div class="itemInfo"><{$lang_attached_files}>\r\n		<{foreach item=onefile from=$attached_files}>\r\n			<a href=''<{$onefile.visitlink}>'' target=''_blank''><{$onefile.file_realname}></a>&nbsp;\r\n		<{/foreach}>\r\n	</div>\r\n<{/if}>\r\n\r\n<{if $pagenav}><div style="text-align: left; margin: 10px;"><{$smarty.const._NW_PAGE}> <{$pagenav}></div><{/if}>\r\n\r\n<div style="padding: 5px; text-align: right; margin-right:3px;">\r\n	<{if $nav_links}><{if $previous_story_id != -1}><a href=''<{$zarilia_url}>/addons/news/article.php?storyid=<{$previous_story_id}>'' title="<{$previous_story_title}>"><{$lang_previous_story}></a> - <{/if}><{if $next_story_id!= -1}><a href=''<{$zarilia_url}>/addons/news/article.php?storyid=<{$next_story_id}>'' title="<{$next_story_title}>"><{$lang_next_story}></a><{/if}><{/if}>	<a href="<{$zarilia_url}>/addons/news/print.php?storyid=<{$story.id}>" rel="nofollow" title="<{$lang_printerpage}>"><img src="<{$zarilia_url}>/addons/news/images/print.gif" border="0" alt="<{$lang_printerpage}>" /></a> <a target="_top" href="<{$mail_link}>" title="<{$lang_sendstory}>" rel="nofollow"><img src="<{$zarilia_url}>/addons/news/images/friend.gif" border="0" alt="<{$lang_sendstory}>" /></a>  <a target="_blank" href="<{$zarilia_url}>/addons/news/pdf/pdf.php?storyid=<{$story.id}>" rel="nofollow" title="<{$lang_pdfstory}>"><img src="<{$zarilia_url}>/addons/news/images/acrobat.gif" border="0" alt="<{$lang_pdfstory}>" /></a>\r\n</div>\r\n\r\n<{if $showsummary == true && $summary_count>0}>\r\n<br /><br />\r\n<table width=''50%'' cellspacing=''0'' cellpadding=''1''>\r\n<tr>\r\n	<th><{$lang_other_story}></th>\r\n</tr>\r\n<{foreach item=onesummary from=$summary}>\r\n<tr class="<{cycle values="even,odd}>">\r\n	<td align=''left''><{$onesummary.story_published}> - <a href=''<{$zarilia_url}>/addons/news/article.php?storyid=<{$onesummary.story_id}>''<{$onesummary.htmltitle}>><{$onesummary.story_title}></a></td>\r\n</tr>\r\n<{/foreach}>\r\n</table>\r\n<br />\r\n<{/if}>\r\n\r\n<{if $bookmarkme == true}>\r\n<br /><br />\r\n<table width=''50%'' cellspacing=''0'' cellpadding=''1''>\r\n<tr>\r\n	<th><{$smarty.const._NW_BOOKMARK_ME}></th>\r\n</tr>\r\n<tr>\r\n	<td><br />\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_BLINKLIST}>" href="http://www.blinklist.com/index.php?Action=Blink/addblink.php&Description=&Url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&Title=<{$encoded_title}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/blinklist.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_DELICIOUS}>" href="http://del.icio.us/post?url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&title=<{$encoded_title}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/delicious.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_DIGG}>" href="http://digg.com/submit?phase=2&url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/diggman.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_FARK}>" href="http://cgi.fark.com/cgi/fark/edit.pl?new_url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&new_comment=<{$encoded_title}>&new_link_other=<{$encoded_title}>&linktype=Misc" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/fark.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_FURL}>" href="http://www.furl.net/storeIt.jsp?t=<{$encoded_title}>&u=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/furl.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_NEWSVINE}>" href="http://www.newsvine.com/_tools/seed&save?u=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&h=<{$encoded_title}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/newsvine.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_REDDIT}>" href="http://reddit.com/submit?url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&title=<{$encoded_title}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/reddit.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_SIMPY}>" href="http://www.simpy.com/simpy/LinkAdd.do?href=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>&title=<{$encoded_title}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/simpy.png" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_SPURL}>" href="http://www.spurl.net/spurl.php?title=<{$encoded_title}>&url=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/spurl.gif" /></a>&nbsp;\r\n		<a target="_blank" title="<{$smarty.const._NW_BOOKMARK_TO_YAHOO}>" href="http://myweb2.search.yahoo.com/myresults/bookmarklet?t=<{$encoded_title}>&u=<{$zarilia_url}>/addons/news/article.php?storyid=<{$story.id}>" title=""><img border="0" alt="" src="<{$zarilia_url}>/addons/news/images/yahoomyweb.gif" /></a>&nbsp;\r\n	</td>\r\n</tr>\r\n</table>\r\n<br />\r\n<{/if}>\r\n\r\n<div style="text-align: center; padding: 3px; margin:3px;">\r\n	<{$commentsnav}>\r\n	<{$lang_notice}>\r\n</div>\r\n\r\n<div style="margin:3px; padding: 3px;">\r\n<{if $comment_mode == "flat"}>\r\n	<{include file="db:system_comments_flat.html"}>\r\n<{elseif $comment_mode == "thread"}>\r\n	<{include file="db:system_comments_thread.html"}>\r\n<{elseif $comment_mode == "nest"}>\r\n	<{include file="db:system_comments_nest.html"}>\r\n<{/if}>\r\n</div>\r\n<{include file=''db:system_notification_select.html''}>'),
(780, '<table>\r\n<tr>\r\n    <th><{$lang_newsarchives}></th>\r\n</tr>\r\n<{foreach item=year from=$years}>\r\n<{foreach item=month from=$year.months}>\r\n<tr class="even">\r\n    <td><a href="<{$zarilia_url}>/addons/news/archive.php?year=<{$year.number}>&amp;month=<{$month.number}>"><{$month.string}> <{$year.number}></a></td>\r\n</tr>\r\n<{/foreach}>\r\n<{/foreach}>\r\n</table>\r\n\r\n<{if $show_articles == true}>\r\n<table>\r\n<tr>\r\n	<th><{$lang_articles}></th><th align="center"><{$lang_actions}></th><th align="center"><{$lang_views}></th><th align="center"><{$lang_date}></th>\r\n</tr>\r\n<{foreach item=story from=$stories}>\r\n<tr class="<{cycle values="even,odd"}>">\r\n	<td><{$story.title}></td><td align="center"><a href="<{$story.print_link}>" rel="nofollow"><img src="<{$zarilia_url}>/addons/news/images/print.gif" border="0" alt="<{$lang_printer}>" /></a> <a href="<{$story.mail_link}>" target="_top" /><img src="<{$zarilia_url}>/addons/news/images/friend.gif" border="0" alt="<{$lang_sendstory}>" /></a></td><td align="center"><{$story.counter}></td><td align="center"><{$story.date}></td>\r\n</tr>\r\n<{/foreach}>\r\n</table>\r\n\r\n<div><{$lang_storytotal}></div>\r\n<{/if}>'),
(649, '<div style="text-align: center;"><form name="newstopicform" action="<{$zarilia_url}>/addons/news/index.php" method="get"><{$block.selectbox}></form></div>'),
(650, '<p><{$block.message}></p>\r\n\r\n<{if $block.story_id != ""}>\r\n  <p><a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$block.story_id}>"<{$block.htmltitle}>><{$block.story_title}></a></p>\r\n<{/if}>');
INSERT INTO `cztsd_tplsource` (`tpl_id`, `tpl_source`) VALUES
(651, '<{if $block.displayview==2}>		<{* Classical view *}>\r\n\r\n<style type="text/css">\r\n#fullSupport {\r\n	padding: 1.5em;\r\n	background: <{$block.color2}>;\r\n	min-height: 300px;\r\n}\r\n\r\n<{if $block.tabskin==1}>			<{* Bar Style *}>\r\n#tabNavigation {\r\n	background: #F90;\r\n	border-bottom: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	list-style: none outside none;\r\n	color: inherit;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border-bottom: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 6px 3px 6px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	border-bottom: none;\r\n	height: auto;\r\n	margin: 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	border-bottom: none;\r\n	padding: 4px 6px 4px 6px\r\n}\r\n\r\n\\head+body #tabNavigation a, \\head+body #tabNavigation a:link, \\head+body #tabNavigation a:visited {\r\n	padding: 3px 6px 3px 6px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #CCC;\r\n	border-right: 1px solid #000;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-bottom: none;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 3px 5px 4px 5px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited {\r\n	padding: 4px 5px 5px 5px\r\n}\r\n\r\n\\head+body #tabNavigation .selectedTab a, \\head+body #tabNavigation .selectedTab a:link, \\head+body #tabNavigation .selectedTab a:visited, \\head+body #tabNavigation .selectedTab a:hover {\r\n	padding: 3px 5px 4px 5px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==2}>		<{* Beveled *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #000;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 2px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	padding: 3px 0 1px 0\r\n}\r\n\r\nhead+body #tabNavigation {\r\n	padding: 4px 0 2px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 3px;\r\n	padding: 0;\r\n	z-index: 1000\r\n}\r\n\r\nhtml #tabNavigation li/* */ {\r\n	height: auto\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	height: auto;\r\n	margin: 0 -5px 0 -3px;\r\n	padding: 3px 5px 2px 5px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li {\r\n	margin: 0 0 0 3px;\r\n	padding: 3px 0 2px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border-left: 1px solid #CCC;\r\n	border-right: 1px solid #CCC;\r\n	border-top: 1px solid #CCC;\r\n	color: #FFF;\r\n	height: 1em;\r\n	padding: 2px 4px 2px 4px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border-left: 1px solid #888;\r\n	border-right: 1px solid #888;\r\n	border-top: 1px solid #888;\r\n	color: #FFF\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #C60;\r\n	border-left: 1px solid #E80;\r\n	border-right: 1px solid #E80;\r\n	border-top: 1px solid #E80;\r\n	color: #FFF\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	margin: 0 -5px 0 -3px;\r\n	padding: 3px 5px 2px 5px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	margin: 0 0 0 3px;\r\n	padding: 3px 0 2px 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-left: 1px solid #FC3;\r\n	border-right: 1px solid #FC3;\r\n	border-top: 1px solid #FC3;\r\n	color: #FFF;\r\n	margin: -2px 0 0 0;\r\n	padding: 3px 4px 3px 4px;\r\n	position: relative;\r\n	top: 2px\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	margin: -1px 0 0 0;\r\n	top: 1px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited, html>body #tabNavigation .selectedTab a:hover {\r\n	padding: 2px 4px 2px 4px;\r\n	top: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation .selectedTab a, head:first-child+body #tabNavigation .selectedTab a:link, head:first-child+body #tabNavigation .selectedTab a:visited, head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	margin: -1px 0 0 0;\r\n	padding: 2px 4px 4px 4px;\r\n	top: 0\r\n}\r\n\r\nhead:first-child+body ul[id]#tabNavigation .selectedTab a, head:first-child+body ul[id]#tabNavigation .selectedTab a:link, head:first-child+body ul[id]#tabNavigation .selectedTab a:visited, head:first-child+body ul[id]#tabNavigation .selectedTab a:hover {\r\n	padding: 3px 4px 3px 4px;\r\n	top: 1px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==3}>		<{* Classic *}>\r\nul, li {\r\n	list-style: disc;\r\n	margin: 0 10px 0 10px\r\n}\r\n\r\n#tabNavigation {\r\n	background: #789;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 6px 0 6px 1px\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 6px 0 6px 1px;\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) <{$block.color4}> no-repeat scroll top right;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	padding: 5px 21px 5px 2px;\r\n	text-decoration: none;\r\n	z-index: 1000\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0;\r\n	padding: 5px 21px 5px 2px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) <{$block.color5}> no-repeat scroll top right;\r\n	color: #FFF;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) #789 no-repeat scroll top right;\r\n	color: #567;\r\n	text-decoration: none\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 0 0 0 23px\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 5px 1px 5px 22px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 5px 0 5px 23px\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selectedEnd.gif) no-repeat scroll top right;\r\n	border-bottom: none;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 5px 21px 5px 2px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	padding: 5px 21px 5px 1px\r\n}\r\n\r\n#tabNavigation .fixTabsIE a, #tabNavigation .fixTabsIE a:link, #tabNavigation .fixTabsIE a:visited, #tabNavigation .fixTabsIE a:hover {\r\n	display: none;\r\n}\r\n<{elseif $block.tabskin==4}>		<{* Folders *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #C60;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0 0 0 20px\r\n}\r\n\r\n\\html #tabNavigation/* */ {\r\n	margin: 0;\r\n	padding: 3px 0 3px 20px\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 0 0 1px 20px\r\n}\r\n\r\n\\head+body #tabNavigation {\r\n	padding: 0 0 3px 20px\r\n}\r\n\r\nhtml>body ul[id] #tabNavigation {\r\n	padding: 0 0 0 20px\r\n}\r\n\r\n#tabNavigation li,  #subNavigation li {\r\n	display: inline;\r\n	list-style: none outside none\r\n}\r\n\r\n#tabNavigation .preloadUnselected {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif);\r\n}\r\n\r\n#tabNavigation .preloadSelected {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif);\r\n}\r\n\r\n#tabNavigation .preloadHover {\r\n	background: transparent url(<{$block.imagesurl}>hover.gif);\r\n}\r\n\r\n#tabNavigation .preloadActive {\r\n	background: transparent url(<{$block.imagesurl}>active.gif);\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif) no-repeat top left;\r\n	border-right: 1px solid #666;\r\n	display: block;\r\n	float: left;\r\n	height: 1em;\r\n	margin: 3px 5px 3px -15px;\r\n	padding: 3px 5px 5px 27px\r\n}\r\n\r\nhead:first-child+body #tabNavigation li {\r\n	background: none;\r\n	border-right: none;\r\n	display: inline;\r\n	float: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif) no-repeat top left;\r\n	border-right: 1px solid #666;\r\n	color: #FFF;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	border-right: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation a, head:first-child+body #tabNavigation a:link, head:first-child+body #tabNavigation a:visited {\r\n	border-right: 1px solid #666;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	position: relative;\r\n	z-index: 50\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: transparent url(<{$block.imagesurl}>hover.gif) no-repeat top left;\r\n	border-right: 1px solid #333;\r\n	color: #FFF;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a:hover {\r\n	border-right: none;\r\n	text-decoration: underline\r\n}\r\n\r\nhead:first-child+body #tabNavigation a:hover {\r\n	border-right: 1px solid #333;\r\n	padding: 4px 5px 3px 27px;\r\n	position: relative;\r\n	text-decoration: none;\r\n	z-index: 5000\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: transparent url(<{$block.imagesurl}>active.gif) no-repeat top left;\r\n	color: #FFF;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a:active {\r\n	text-decoration: underline\r\n}\r\n\r\nhead:first-child+body #tabNavigation a:active {\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	display: block;\r\n	float: left;\r\n	height: 1em;\r\n	margin: 3px 5px 5px -15px;\r\n	padding: 3px 5px 5px 27px\r\n}\r\n\r\nhead:first-child+body #tabNavigation li.selectedTab {\r\n	background: none;\r\n	border-right: none;\r\n	display: inline;\r\n	float: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	color: #FFF;\r\n	cursor: text;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited {\r\n	border-right: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation .selectedTab a, head:first-child+body #tabNavigation .selectedTab a:link, head:first-child+body #tabNavigation .selectedTab a:visited, head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	position: relative;\r\n	z-index: 10000\r\n}\r\n\r\n\\html head:first-child+body #tabNavigation .selectedTab a, \\html head:first-child+body #tabNavigation .selectedTab a:link, \\html head:first-child+body #tabNavigation .selectedTab a:visited, \\html head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	padding: 4px 5px 5px 27px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==5}>		<{* MacOs *}>\r\n#tabNavigation {\r\n	background: #CCC;\r\n	border-bottom: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0;\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: inherit;\r\n	border-bottom: 1px solid #999;\r\n	border-left: 1px solid #FFF;\r\n	border-right: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: #000;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 6px 3px 6px;\r\n	text-decoration: none;\r\n	white-space: normal;\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	padding: 4px 6px 4px 6px\r\n}\r\n\r\n\\head+body #tabNavigation a, \\head+body #tabNavigation a:link, \\head+body #tabNavigation a:visited {\r\n	padding: 3px 6px 3px 6px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border-bottom: 1px solid #666;\r\n	border-left: 1px solid #CCC;\r\n	border-right: 1px solid #666;\r\n	border-top: 1px solid #CCC;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #CCC;\r\n	border-bottom: 1px solid #FFF;\r\n	border-left: 1px solid #999;\r\n	border-right: 1px solid #FFF;\r\n	border-top: 1px solid #999;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-bottom: 1px solid #999;\r\n	border-left: 1px solid #FFF;\r\n	border-right: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: #000;\r\n	cursor: text;\r\n	font-weight: bold\r\n}\r\n\r\n#tabNavigation .fixTabsIE a, #tabNavigation .fixTabsIE a:link, #tabNavigation .fixTabsIE a:visited {\r\n	visibility: hidden\r\n}\r\n\r\nhtml #tabNavigation .fixTabsIE a/* */, html #tabNavigation .fixTabsIE a:link/* */, html #tabNavigation .fixTabsIE a:visited/* */ {\r\n	background: #CCC;\r\n	border-bottom: none;\r\n	border-left: 1px solid #FFF;\r\n	border-right: none;\r\n	border-top: none;\r\n	color: inherit;\r\n	cursor: text;\r\n	margin: 0;\r\n	padding: 3px 6px 3px 6px;\r\n	visibility: visible\r\n}\r\n<{elseif $block.tabskin==6}>		<{* Plain *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #000;\r\n	font: normal 11px Verdana, Geneva, Arial, Helvetica, sans-serif;\r\n	margin: 0;\r\n	padding: 0 0 18px 0;\r\n}\r\n\r\nul#tabNavigation li {\r\n	display: inline;\r\n	list-style-image: none;\r\n	list-style-position: outside;\r\n	list-style-type: none;\r\n}\r\n\r\nul#tabNavigation a, ul#tabNavigation a:link, ul#tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border: 1px solid #000;\r\n	color: #000;\r\n	float: left;\r\n	margin: 0 0 0 5px;\r\n	padding: 2px 6px 2px 6px;\r\n	text-decoration: none\r\n}\r\n\r\nul#tabNavigation a:hover, ul#tabNavigation a:focus {\r\n	background: <{$block.color5}>;\r\n	color: #FFF;\r\n}\r\n\r\nul#tabNavigation a:active {\r\n	background: #FFF;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #00F;\r\n	padding: 2px 6px 3px 6px\r\n}\r\n\r\nul#tabNavigation li.selectedTab a, ul#tabNavigation li.selectedTab a:link, ul#tabNavigation li.selectedTab a:visited {\r\n	background: <{$block.color3}>;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #000;\r\n	cursor: text;\r\n	margin: 0 0 0 5px;\r\n	padding: 2px 6px 3px 6px\r\n}\r\n\r\nul#tabNavigation li.fixTabsIE {\r\n	display: none;\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==7}>		<{* Rounded *}>\r\n#tabNavigation {\r\n	background: #FFF;\r\n	border-bottom: 1px solid #000;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 1px 0 0 0;\r\n	padding: 0;\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	background: url(<{$block.imagesurl}>unselected_left.gif) #C60 no-repeat scroll top left;\r\n	color: inherit;\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0 0 0 2px;\r\n	padding: 0\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	margin: 0 0 0 -6px;\r\n	padding: 3px 0 3px 8px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li {\r\n	margin: 0 0 0 2px;\r\n	padding: 3px 0 3px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	border-bottom: 1px solid #000;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 8px 3px 8px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	border-bottom: none;\r\n	height: auto;\r\n	margin: 0 0 0 4px;\r\n	padding: 3px 8px 3px 4px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	color: #FFF;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	color: #000;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: transparent url(<{$block.imagesurl}>selected_left_F90.gif) no-repeat scroll top left;\r\n	color: inherit;\r\n	padding: 0\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	margin: 0 0 0 -6px;\r\n	padding: 4px 0 4px 8px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	margin: 0 0 0 2px;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selected_right_F90.gif) no-repeat scroll top right;\r\n	border-bottom: none;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 4px 8px 4px 8px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	padding: 4px 8px 4px 4px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==8}>		<{* ZDnet *}>\r\n#tabNavigation {\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 4px 0 3px 0\r\n}\r\n\r\n@media all {\r\n	#tabNavigation {\r\n		text-align: center\r\n	}\r\n}\r\n\r\n#tabNavigation li {\r\n	background: #000;\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0 4px 0 4px;\r\n	padding: 0;\r\n	position: relative;\r\n	top: 10px\r\n}\r\n\r\nhtml #tabNavigation li/* */ {\r\n	line-height: 1.2em;\r\n	top: 6px\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	margin: 0 2px 0 4px;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border: 1px solid #FFF;\r\n	bottom: 2px;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 4px 0 0;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 2px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0 -4px 0 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	margin: 0\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border: 1px solid #FFF;\r\n	bottom: 1px;\r\n	color: #FFF;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 1px\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #666;\r\n	border: 1px solid #FFF;\r\n	bottom: 0;\r\n	color: #FFF;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 0\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: <{$block.color3}>;\r\n	display: inline;\r\n	margin: 0 4px 0 4px;\r\n	position: relative;\r\n	top: 4px\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: #F90;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	bottom: 0;\r\n	color: #FFF;\r\n	cursor: text;\r\n	margin: 0 5px 0 0;\r\n	padding: 3px 5px 0 5px;\r\n	position: relative;\r\n	right: 0\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	margin: 0 -2px 0 0\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{/if}>\r\n</style>\r\n	<{* ************************************** Tabs creation ************************************** *}>\r\n<ul id="tabNavigation">\r\n<{foreach item=onetab from=$block.tabs}>\r\n	<{if $block.current_tab == $onetab.id}>\r\n	<li class="selectedTab"><a href=''#''><{$onetab.title}></a></li>\r\n	<{else}>\r\n	<li><a href="<{$block.url}>NewsTab=<{$onetab.id}>"><{$onetab.title}></a></li>\r\n	<{/if}>\r\n<{/foreach}>\r\n	<li class="fixTabsIE"><a href="javascript:void(0);">&nbsp;</a></li>\r\n</ul>\r\n\r\n<{if $block.current_is_spotlight}>\r\n	<div style="border-top: 1px solid rgb(0, 0, 0); background: <{$block.color1}> none repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial;"><{$block.spotlight.author}> <{$block.lang_on}> <{$block.spotlight.date}> <{if $block.use_rating}> - <{$block.spotlight.rating}>/10 (<{$block.spotlight.number_votes}>)<{/if}>, <{$block.spotlight.hits}> <{$block.lang_reads}><br /></div>\r\n<{else}>\r\n	<div style="border-top: 1px solid rgb(0, 0, 0); background: <{$block.color1}> none repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial;">\r\n	<{foreach item=onesummary from=$block.smallheader}>\r\n		<{$onesummary}>&nbsp;\r\n	<{/foreach}>\r\n	<br /></div>\r\n<{/if}>\r\n	<{* ************************************** Body of the current tab ************************************** *}>\r\n<div id="fullSupport">\r\n	<{if $block.current_is_spotlight && $block.tabs.id==0}>\r\n		<table border=''0''>\r\n		<tr>\r\n			<td colspan=''2''>\r\n				<table border=''0''>\r\n				<tr><td><img src=''<{$block.spotlight.topic_image}>'' border=''0'' alt='''' /></td><td align=''left''><{$block.spotlight.topic_description}></td></tr>\r\n				</table>\r\n			<div class="itemBody"><ul><li><{$block.spotlight.title_with_link}></li></ul></div></td>\r\n		</tr>\r\n		<tr>\r\n			<td><{$block.spotlight.image}>&nbsp;</td><td><p class="note"><{$block.spotlight.text}></p></td>\r\n		</tr>\r\n		</table>\r\n		<br /><center><hr width=''85%'' /></center>\r\n		<ul>\r\n			<{foreach item=onenews from=$block.spotlight.news}>\r\n				<li><{$onenews.date}> - <{$onenews.title_with_link}></li>\r\n			<{/foreach}>\r\n		</ul>\r\n	<{else}>\r\n		<table border=''0''>\r\n		<tr><td><img src=''<{$block.topic_image}>'' border=''0'' alt='''' /></td><td align=''left''><{$block.topic_description}></td></tr>\r\n		</table>\r\n		<{foreach item=onenews from=$block.news}>\r\n			<div class="itemBody"><ul><li><{$onenews.title}></li></ul><span class="itemStats">&nbsp;&nbsp;<{$onenews.author}> <{$block.lang_on}> <{$onenews.date}> - <{if $block.use_rating}> <{$onenews.rating}>/10 (<{$onenews.number_votes}>)<{/if}>, <{$onenews.hits}> <{$block.lang_reads}></span></div>\r\n			<p class="note"><{$onenews.text}></p>\r\n		<{/foreach}>\r\n	<{/if}>\r\n</div>\r\n<{else}>	<{* ************************************** Classical view ************************************** *}>\r\n<table>\r\n	<{if $block.spotlight}>\r\n	<tr>\r\n		<td><table>\r\n		<tr>\r\n			<td colspan=''2''>\r\n				<table border=''0''>\r\n				<tr><td><img src=''<{$block.spotlight.topic_image}>'' border=''0'' alt=''''></td><td align=''left''><{$block.spotlight.topic_description}></td></tr>\r\n				</table>\r\n				<font color="#FF6600"><b><{$block.spotlight.title}></b></font> <{$block.spotlight.author}>\r\n			<{if $block.sort==''counter''}>\r\n				(<{$block.spotlight.hits}>)\r\n			<{elseif $block.sort==''published''}>\r\n				(<{$block.spotlight.date}>)\r\n			<{else}>\r\n				(<{$block.spotlight.rating}>)\r\n			<{/if}>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td><{$block.spotlight.image}></td><td><{$block.spotlight.text}></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=''2''>\r\n			<{if $block.spotlight.read_more}>\r\n				<hr width=''98%'' />\r\n				<div align=''right''><a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$block.spotlight.id}>"><{$block.lang_read_more}></a> &nbsp;&nbsp;&nbsp;</div>\r\n				<hr width=''98%'' />\r\n			<{/if}>\r\n			</td>\r\n		</tr>\r\n		</table></td>\r\n	</tr>\r\n	<{/if}>\r\n	<tr>\r\n		<td>\r\n			<ul>\r\n				<{foreach item=news from=$block.stories}>\r\n					<{if $news.id != $block.spotlight.id}>\r\n						<li>\r\n						<{if $block.sort==''counter''}>\r\n							[<{$news.hits}>]\r\n						<{elseif $block.sort==''published''}>\r\n							[<{$news.date}>]\r\n						<{else}>\r\n							[<{$news.rating}>]\r\n						<{/if}>\r\n						<a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$news.id}>" <{$news.infotips}>><{$news.title}></a> <br /><{$news.teaser}></li>\r\n					<{/if}>\r\n				<{/foreach}>\r\n			</ul>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<{/if}>');
INSERT INTO `cztsd_tplsource` (`tpl_id`, `tpl_source`) VALUES
(652, '<{if $block.displayview==2}>		<{* Classical view *}>\r\n\r\n<style type="text/css">\r\n#fullSupport {\r\n	padding: 1.5em;\r\n	background: <{$block.color2}>;\r\n	min-height: 300px;\r\n}\r\n\r\n<{if $block.tabskin==1}>			<{* Bar Style *}>\r\n#tabNavigation {\r\n	background: #F90;\r\n	border-bottom: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	list-style: none outside none;\r\n	color: inherit;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border-bottom: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 6px 3px 6px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	border-bottom: none;\r\n	height: auto;\r\n	margin: 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	border-bottom: none;\r\n	padding: 4px 6px 4px 6px\r\n}\r\n\r\n\\head+body #tabNavigation a, \\head+body #tabNavigation a:link, \\head+body #tabNavigation a:visited {\r\n	padding: 3px 6px 3px 6px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #CCC;\r\n	border-right: 1px solid #000;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-bottom: none;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 3px 5px 4px 5px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited {\r\n	padding: 4px 5px 5px 5px\r\n}\r\n\r\n\\head+body #tabNavigation .selectedTab a, \\head+body #tabNavigation .selectedTab a:link, \\head+body #tabNavigation .selectedTab a:visited, \\head+body #tabNavigation .selectedTab a:hover {\r\n	padding: 3px 5px 4px 5px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==2}>		<{* Beveled *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #000;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 2px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	padding: 3px 0 1px 0\r\n}\r\n\r\nhead+body #tabNavigation {\r\n	padding: 4px 0 2px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 3px;\r\n	padding: 0;\r\n	z-index: 1000\r\n}\r\n\r\nhtml #tabNavigation li/* */ {\r\n	height: auto\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	height: auto;\r\n	margin: 0 -5px 0 -3px;\r\n	padding: 3px 5px 2px 5px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li {\r\n	margin: 0 0 0 3px;\r\n	padding: 3px 0 2px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border-left: 1px solid #CCC;\r\n	border-right: 1px solid #CCC;\r\n	border-top: 1px solid #CCC;\r\n	color: #FFF;\r\n	height: 1em;\r\n	padding: 2px 4px 2px 4px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border-left: 1px solid #888;\r\n	border-right: 1px solid #888;\r\n	border-top: 1px solid #888;\r\n	color: #FFF\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #C60;\r\n	border-left: 1px solid #E80;\r\n	border-right: 1px solid #E80;\r\n	border-top: 1px solid #E80;\r\n	color: #FFF\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	margin: 0 -5px 0 -3px;\r\n	padding: 3px 5px 2px 5px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	margin: 0 0 0 3px;\r\n	padding: 3px 0 2px 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-left: 1px solid #FC3;\r\n	border-right: 1px solid #FC3;\r\n	border-top: 1px solid #FC3;\r\n	color: #FFF;\r\n	margin: -2px 0 0 0;\r\n	padding: 3px 4px 3px 4px;\r\n	position: relative;\r\n	top: 2px\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	margin: -1px 0 0 0;\r\n	top: 1px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited, html>body #tabNavigation .selectedTab a:hover {\r\n	padding: 2px 4px 2px 4px;\r\n	top: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation .selectedTab a, head:first-child+body #tabNavigation .selectedTab a:link, head:first-child+body #tabNavigation .selectedTab a:visited, head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	margin: -1px 0 0 0;\r\n	padding: 2px 4px 4px 4px;\r\n	top: 0\r\n}\r\n\r\nhead:first-child+body ul[id]#tabNavigation .selectedTab a, head:first-child+body ul[id]#tabNavigation .selectedTab a:link, head:first-child+body ul[id]#tabNavigation .selectedTab a:visited, head:first-child+body ul[id]#tabNavigation .selectedTab a:hover {\r\n	padding: 3px 4px 3px 4px;\r\n	top: 1px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==3}>		<{* Classic *}>\r\nul, li {\r\n	list-style: disc;\r\n	margin: 0 10px 0 10px\r\n}\r\n\r\n#tabNavigation {\r\n	background: #789;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 6px 0 6px 1px\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 6px 0 6px 1px;\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) <{$block.color4}> no-repeat scroll top right;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	padding: 5px 21px 5px 2px;\r\n	text-decoration: none;\r\n	z-index: 1000\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0;\r\n	padding: 5px 21px 5px 2px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) <{$block.color5}> no-repeat scroll top right;\r\n	color: #FFF;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: url(<{$block.imagesurl}>unselectedEnd.gif) #789 no-repeat scroll top right;\r\n	color: #567;\r\n	text-decoration: none\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 0 0 0 23px\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 5px 1px 5px 22px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	background: url(<{$block.imagesurl}>selectedStart.gif) #FFF no-repeat scroll top left;\r\n	color: inherit;\r\n	margin: 0 0 0 -22px;\r\n	padding: 5px 0 5px 23px\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selectedEnd.gif) no-repeat scroll top right;\r\n	border-bottom: none;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 5px 21px 5px 2px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	padding: 5px 21px 5px 1px\r\n}\r\n\r\n#tabNavigation .fixTabsIE a, #tabNavigation .fixTabsIE a:link, #tabNavigation .fixTabsIE a:visited, #tabNavigation .fixTabsIE a:hover {\r\n	display: none;\r\n}\r\n<{elseif $block.tabskin==4}>		<{* Folders *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #C60;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0 0 0 20px\r\n}\r\n\r\n\\html #tabNavigation/* */ {\r\n	margin: 0;\r\n	padding: 3px 0 3px 20px\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 0 0 1px 20px\r\n}\r\n\r\n\\head+body #tabNavigation {\r\n	padding: 0 0 3px 20px\r\n}\r\n\r\nhtml>body ul[id] #tabNavigation {\r\n	padding: 0 0 0 20px\r\n}\r\n\r\n#tabNavigation li,  #subNavigation li {\r\n	display: inline;\r\n	list-style: none outside none\r\n}\r\n\r\n#tabNavigation .preloadUnselected {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif);\r\n}\r\n\r\n#tabNavigation .preloadSelected {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif);\r\n}\r\n\r\n#tabNavigation .preloadHover {\r\n	background: transparent url(<{$block.imagesurl}>hover.gif);\r\n}\r\n\r\n#tabNavigation .preloadActive {\r\n	background: transparent url(<{$block.imagesurl}>active.gif);\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif) no-repeat top left;\r\n	border-right: 1px solid #666;\r\n	display: block;\r\n	float: left;\r\n	height: 1em;\r\n	margin: 3px 5px 3px -15px;\r\n	padding: 3px 5px 5px 27px\r\n}\r\n\r\nhead:first-child+body #tabNavigation li {\r\n	background: none;\r\n	border-right: none;\r\n	display: inline;\r\n	float: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: transparent url(<{$block.imagesurl}>unselected.gif) no-repeat top left;\r\n	border-right: 1px solid #666;\r\n	color: #FFF;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	border-right: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation a, head:first-child+body #tabNavigation a:link, head:first-child+body #tabNavigation a:visited {\r\n	border-right: 1px solid #666;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	position: relative;\r\n	z-index: 50\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: transparent url(<{$block.imagesurl}>hover.gif) no-repeat top left;\r\n	border-right: 1px solid #333;\r\n	color: #FFF;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a:hover {\r\n	border-right: none;\r\n	text-decoration: underline\r\n}\r\n\r\nhead:first-child+body #tabNavigation a:hover {\r\n	border-right: 1px solid #333;\r\n	padding: 4px 5px 3px 27px;\r\n	position: relative;\r\n	text-decoration: none;\r\n	z-index: 5000\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: transparent url(<{$block.imagesurl}>active.gif) no-repeat top left;\r\n	color: #FFF;\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation a:active {\r\n	text-decoration: underline\r\n}\r\n\r\nhead:first-child+body #tabNavigation a:active {\r\n	text-decoration: none\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	display: block;\r\n	float: left;\r\n	height: 1em;\r\n	margin: 3px 5px 5px -15px;\r\n	padding: 3px 5px 5px 27px\r\n}\r\n\r\nhead:first-child+body #tabNavigation li.selectedTab {\r\n	background: none;\r\n	border-right: none;\r\n	display: inline;\r\n	float: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	color: #FFF;\r\n	cursor: text;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px\r\n}\r\n\r\nhtml>body #tabNavigation .selectedTab a, html>body #tabNavigation .selectedTab a:link, html>body #tabNavigation .selectedTab a:visited {\r\n	border-right: none;\r\n	margin: 0;\r\n	padding: 0\r\n}\r\n\r\nhead:first-child+body #tabNavigation .selectedTab a, head:first-child+body #tabNavigation .selectedTab a:link, head:first-child+body #tabNavigation .selectedTab a:visited, head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selected.gif) no-repeat top left;\r\n	border-right: 1px solid #C60;\r\n	margin: 0 0 0 -15px;\r\n	padding: 3px 5px 3px 27px;\r\n	position: relative;\r\n	z-index: 10000\r\n}\r\n\r\n\\html head:first-child+body #tabNavigation .selectedTab a, \\html head:first-child+body #tabNavigation .selectedTab a:link, \\html head:first-child+body #tabNavigation .selectedTab a:visited, \\html head:first-child+body #tabNavigation .selectedTab a:hover {\r\n	padding: 4px 5px 5px 27px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==5}>		<{* MacOs *}>\r\n#tabNavigation {\r\n	background: #CCC;\r\n	border-bottom: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 0;\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	display: inline;\r\n	line-height: 1em\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: inherit;\r\n	border-bottom: 1px solid #999;\r\n	border-left: 1px solid #FFF;\r\n	border-right: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: #000;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 6px 3px 6px;\r\n	text-decoration: none;\r\n	white-space: normal;\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	padding: 4px 6px 4px 6px\r\n}\r\n\r\n\\head+body #tabNavigation a, \\head+body #tabNavigation a:link, \\head+body #tabNavigation a:visited {\r\n	padding: 3px 6px 3px 6px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border-bottom: 1px solid #666;\r\n	border-left: 1px solid #CCC;\r\n	border-right: 1px solid #666;\r\n	border-top: 1px solid #CCC;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #CCC;\r\n	border-bottom: 1px solid #FFF;\r\n	border-left: 1px solid #999;\r\n	border-right: 1px solid #FFF;\r\n	border-top: 1px solid #999;\r\n	color: inherit\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: <{$block.color3}>;\r\n	border-bottom: 1px solid #999;\r\n	border-left: 1px solid #FFF;\r\n	border-right: 1px solid #999;\r\n	border-top: 1px solid #FFF;\r\n	color: #000;\r\n	cursor: text;\r\n	font-weight: bold\r\n}\r\n\r\n#tabNavigation .fixTabsIE a, #tabNavigation .fixTabsIE a:link, #tabNavigation .fixTabsIE a:visited {\r\n	visibility: hidden\r\n}\r\n\r\nhtml #tabNavigation .fixTabsIE a/* */, html #tabNavigation .fixTabsIE a:link/* */, html #tabNavigation .fixTabsIE a:visited/* */ {\r\n	background: #CCC;\r\n	border-bottom: none;\r\n	border-left: 1px solid #FFF;\r\n	border-right: none;\r\n	border-top: none;\r\n	color: inherit;\r\n	cursor: text;\r\n	margin: 0;\r\n	padding: 3px 6px 3px 6px;\r\n	visibility: visible\r\n}\r\n<{elseif $block.tabskin==6}>		<{* Plain *}>\r\n#tabNavigation {\r\n	border-bottom: 1px solid #000;\r\n	font: normal 11px Verdana, Geneva, Arial, Helvetica, sans-serif;\r\n	margin: 0;\r\n	padding: 0 0 18px 0;\r\n}\r\n\r\nul#tabNavigation li {\r\n	display: inline;\r\n	list-style-image: none;\r\n	list-style-position: outside;\r\n	list-style-type: none;\r\n}\r\n\r\nul#tabNavigation a, ul#tabNavigation a:link, ul#tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border: 1px solid #000;\r\n	color: #000;\r\n	float: left;\r\n	margin: 0 0 0 5px;\r\n	padding: 2px 6px 2px 6px;\r\n	text-decoration: none\r\n}\r\n\r\nul#tabNavigation a:hover, ul#tabNavigation a:focus {\r\n	background: <{$block.color5}>;\r\n	color: #FFF;\r\n}\r\n\r\nul#tabNavigation a:active {\r\n	background: #FFF;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #00F;\r\n	padding: 2px 6px 3px 6px\r\n}\r\n\r\nul#tabNavigation li.selectedTab a, ul#tabNavigation li.selectedTab a:link, ul#tabNavigation li.selectedTab a:visited {\r\n	background: <{$block.color3}>;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	color: #000;\r\n	cursor: text;\r\n	margin: 0 0 0 5px;\r\n	padding: 2px 6px 3px 6px\r\n}\r\n\r\nul#tabNavigation li.fixTabsIE {\r\n	display: none;\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==7}>		<{* Rounded *}>\r\n#tabNavigation {\r\n	background: #FFF;\r\n	border-bottom: 1px solid #000;\r\n	color: inherit;\r\n	list-style: none outside none;\r\n	margin: 1px 0 0 0;\r\n	padding: 0;\r\n}\r\n\r\nhtml #tabNavigation/* */ {\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\nhtml>body #tabNavigation {\r\n	margin: 0;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation li {\r\n	background: url(<{$block.imagesurl}>unselected_left.gif) #C60 no-repeat scroll top left;\r\n	color: inherit;\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0 0 0 2px;\r\n	padding: 0\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	margin: 0 0 0 -6px;\r\n	padding: 3px 0 3px 8px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li {\r\n	margin: 0 0 0 2px;\r\n	padding: 3px 0 3px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	border-bottom: 1px solid #000;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	height: 1em;\r\n	margin: -1px 0 -1px 0;\r\n	padding: 3px 8px 3px 8px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	border-bottom: none;\r\n	height: auto;\r\n	margin: 0 0 0 4px;\r\n	padding: 3px 8px 3px 4px\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	color: #FFF;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: transparent url(<{$block.imagesurl}>unselected_right.gif) no-repeat scroll top right;\r\n	color: #000;\r\n	text-decoration: underline\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: transparent url(<{$block.imagesurl}>selected_left_F90.gif) no-repeat scroll top left;\r\n	color: inherit;\r\n	padding: 0\r\n}\r\n\r\nhtml>body #tabNavigation li.selectedTab {\r\n	margin: 0 0 0 -6px;\r\n	padding: 4px 0 4px 8px\r\n}\r\n\r\nhtml>body ul[id]#tabNavigation li.selectedTab {\r\n	margin: 0 0 0 2px;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: transparent url(<{$block.imagesurl}>selected_right_F90.gif) no-repeat scroll top right;\r\n	border-bottom: none;\r\n	color: #000;\r\n	cursor: text;\r\n	padding: 4px 8px 4px 8px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	padding: 4px 8px 4px 4px\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{elseif $block.tabskin==8}>		<{* ZDnet *}>\r\n#tabNavigation {\r\n	list-style: none outside none;\r\n	margin: 0;\r\n	padding: 4px 0 3px 0\r\n}\r\n\r\n@media all {\r\n	#tabNavigation {\r\n		text-align: center\r\n	}\r\n}\r\n\r\n#tabNavigation li {\r\n	background: #000;\r\n	display: inline;\r\n	line-height: 1em;\r\n	margin: 0 4px 0 4px;\r\n	padding: 0;\r\n	position: relative;\r\n	top: 10px\r\n}\r\n\r\nhtml #tabNavigation li/* */ {\r\n	line-height: 1.2em;\r\n	top: 6px\r\n}\r\n\r\nhtml>body #tabNavigation li {\r\n	margin: 0 2px 0 4px;\r\n	padding: 4px 0 4px 0\r\n}\r\n\r\n#tabNavigation a, #tabNavigation a:link, #tabNavigation a:visited {\r\n	background: <{$block.color4}>;\r\n	border: 1px solid #FFF;\r\n	bottom: 2px;\r\n	color: #FFF;\r\n	cursor: pointer;\r\n	display: inline;\r\n	height: 1em;\r\n	margin: 0 4px 0 0;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 2px;\r\n	text-decoration: none\r\n}\r\n\r\nhtml #tabNavigation a/* */, html #tabNavigation a:link/* */, html #tabNavigation a:visited/* */ {\r\n	height: auto;\r\n	margin: 0 -4px 0 0\r\n}\r\n\r\nhtml>body #tabNavigation a, html>body #tabNavigation a:link, html>body #tabNavigation a:visited {\r\n	margin: 0\r\n}\r\n\r\n#tabNavigation a:hover {\r\n	background: <{$block.color5}>;\r\n	border: 1px solid #FFF;\r\n	bottom: 1px;\r\n	color: #FFF;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 1px\r\n}\r\n\r\n#tabNavigation a:active {\r\n	background: #666;\r\n	border: 1px solid #FFF;\r\n	bottom: 0;\r\n	color: #FFF;\r\n	padding: 3px 5px 3px 5px;\r\n	position: relative;\r\n	right: 0\r\n}\r\n\r\n#tabNavigation li.selectedTab {\r\n	background: <{$block.color3}>;\r\n	display: inline;\r\n	margin: 0 4px 0 4px;\r\n	position: relative;\r\n	top: 4px\r\n}\r\n\r\n#tabNavigation .selectedTab a, #tabNavigation .selectedTab a:link, #tabNavigation .selectedTab a:visited, #tabNavigation .selectedTab a:hover {\r\n	background: #F90;\r\n	border-bottom: none;\r\n	border-left: 1px solid #000;\r\n	border-right: 1px solid #000;\r\n	border-top: 1px solid #000;\r\n	bottom: 0;\r\n	color: #FFF;\r\n	cursor: text;\r\n	margin: 0 5px 0 0;\r\n	padding: 3px 5px 0 5px;\r\n	position: relative;\r\n	right: 0\r\n}\r\n\r\nhtml #tabNavigation .selectedTab a/* */, html #tabNavigation .selectedTab a:link/* */, html #tabNavigation .selectedTab a:visited/* */, html #tabNavigation .selectedTab a:hover/* */ {\r\n	margin: 0 -2px 0 0\r\n}\r\n\r\n.fixTabsIE {\r\n	visibility: hidden\r\n}\r\n<{/if}>\r\n</style>\r\n	<{* ************************************** Tabs creation ************************************** *}>\r\n<ul id="tabNavigation">\r\n<{foreach item=onetab from=$block.tabs}>\r\n	<{if $block.current_tab == $onetab.id}>\r\n	<li class="selectedTab"><a href=''#''><{$onetab.title}></a></li>\r\n	<{else}>\r\n	<li><a href="<{$block.url}>NewsTab=<{$onetab.id}>"><{$onetab.title}></a></li>\r\n	<{/if}>\r\n<{/foreach}>\r\n	<li class="fixTabsIE"><a href="javascript:void(0);">&nbsp;</a></li>\r\n</ul>\r\n\r\n<{if $block.current_is_spotlight}>\r\n	<div style="border-top: 1px solid rgb(0, 0, 0); background: <{$block.color1}> none repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial;"><{$block.spotlight.author}> <{$block.lang_on}> <{$block.spotlight.date}> <{if $block.use_rating}> - <{$block.spotlight.rating}>/10 (<{$block.spotlight.number_votes}>)<{/if}>, <{$block.spotlight.hits}> <{$block.lang_reads}><br /></div>\r\n<{else}>\r\n	<div style="border-top: 1px solid rgb(0, 0, 0); background: <{$block.color1}> none repeat scroll 0%; -moz-background-clip: initial; -moz-background-origin: initial; -moz-background-inline-policy: initial;">\r\n	<{foreach item=onesummary from=$block.smallheader}>\r\n		<{$onesummary}>&nbsp;\r\n	<{/foreach}>\r\n	<br /></div>\r\n<{/if}>\r\n	<{* ************************************** Body of the current tab ************************************** *}>\r\n<div id="fullSupport">\r\n	<{if $block.current_is_spotlight && $block.tabs.id==0}>\r\n		<table border=''0''>\r\n		<tr>\r\n			<td colspan=''2''>\r\n				<table border=''0''>\r\n				<tr><td><img src=''<{$block.spotlight.topic_image}>'' border=''0'' alt='''' /></td><td align=''left''><{$block.spotlight.topic_description}></td></tr>\r\n				</table>\r\n			<div class="itemBody"><ul><li><{$block.spotlight.title_with_link}></li></ul></div></td>\r\n		</tr>\r\n		<tr>\r\n			<td><{$block.spotlight.image}>&nbsp;</td><td><p class="note"><{$block.spotlight.text}></p></td>\r\n		</tr>\r\n		</table>\r\n		<br /><center><hr width=''85%'' /></center>\r\n		<ul>\r\n			<{foreach item=onenews from=$block.spotlight.news}>\r\n				<li><{$onenews.date}> - <{$onenews.title_with_link}></li>\r\n			<{/foreach}>\r\n		</ul>\r\n	<{else}>\r\n		<table border=''0''>\r\n		<tr><td><img src=''<{$block.topic_image}>'' border=''0'' alt='''' /></td><td align=''left''><{$block.topic_description}></td></tr>\r\n		</table>\r\n		<{foreach item=onenews from=$block.news}>\r\n			<div class="itemBody"><ul><li><{$onenews.title}></li></ul><span class="itemStats">&nbsp;&nbsp;<{$onenews.author}> <{$block.lang_on}> <{$onenews.date}> - <{if $block.use_rating}> <{$onenews.rating}>/10 (<{$onenews.number_votes}>)<{/if}>, <{$onenews.hits}> <{$block.lang_reads}></span></div>\r\n			<p class="note"><{$onenews.text}></p>\r\n		<{/foreach}>\r\n	<{/if}>\r\n</div>\r\n<{else}>	<{* ************************************** Classical view ************************************** *}>\r\n<table>\r\n	<{if $block.spotlight}>\r\n	<tr>\r\n		<td><table>\r\n		<tr>\r\n			<td colspan=''2''>\r\n				<table border=''0''>\r\n				<tr><td><img src=''<{$block.spotlight.topic_image}>'' border=''0'' alt=''''></td><td align=''left''><{$block.spotlight.topic_description}></td></tr>\r\n				</table>\r\n				<font color="#FF6600"><b><{$block.spotlight.title}></b></font> <{$block.spotlight.author}>\r\n			<{if $block.sort==''counter''}>\r\n				(<{$block.spotlight.hits}>)\r\n			<{elseif $block.sort==''published''}>\r\n				(<{$block.spotlight.date}>)\r\n			<{else}>\r\n				(<{$block.spotlight.rating}>)\r\n			<{/if}>\r\n			</td>\r\n		</tr>\r\n		<tr>\r\n			<td><{$block.spotlight.image}></td><td><{$block.spotlight.text}></td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=''2''>\r\n			<{if $block.spotlight.read_more}>\r\n				<hr width=''98%'' />\r\n				<div align=''right''><a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$block.spotlight.id}>"><{$block.lang_read_more}></a> &nbsp;&nbsp;&nbsp;</div>\r\n				<hr width=''98%'' />\r\n			<{/if}>\r\n			</td>\r\n		</tr>\r\n		</table></td>\r\n	</tr>\r\n	<{/if}>\r\n	<tr>\r\n		<td>\r\n			<ul>\r\n				<{foreach item=news from=$block.stories}>\r\n					<{if $news.id != $block.spotlight.id}>\r\n						<li>\r\n						<{if $block.sort==''counter''}>\r\n							[<{$news.hits}>]\r\n						<{elseif $block.sort==''published''}>\r\n							[<{$news.date}>]\r\n						<{else}>\r\n							[<{$news.rating}>]\r\n						<{/if}>\r\n						<a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$news.id}>" <{$news.infotips}>><{$news.title}></a> <br /><{$news.teaser}></li>\r\n					<{/if}>\r\n				<{/foreach}>\r\n			</ul>\r\n		</td>\r\n	</tr>\r\n</table>\r\n<{/if}>'),
(653, '<table class="outer" cellspacing="1">\r\n<tr>\r\n	<th align="left"><{$block.lang_story_title}></th>\r\n    <th align="left"><{$block.lang_story_topic}></th>\r\n    <th align="left"><{$block.lang_story_date}></th>\r\n    <th align="left"><{$block.lang_story_author}></th>\r\n    <th align="left"><{$block.lang_story_action}></th>\r\n</tr>\r\n<{foreach item=news from=$block.stories}>\r\n<tr class="<{cycle values="even,odd"}>">\r\n	<td align="left"><{$news.title}></td>\r\n    <td align="left"><{$news.topic_title}></td>\r\n    <td align="left"><{$news.date}></td>\r\n    <td align="left"><{$news.author}></td>\r\n    <td align="right"><{$news.action}></td>\r\n</tr>\r\n<{/foreach}>\r\n</table>'),
(654, '<table cellspacing="0">\r\n<tr>\r\n	<td id="mainmenu">\r\n    <{foreach item=topic from=$block.topics}>\r\n    	<a class="menuMain" href="<{$zarilia_url}>/addons/news/index.php?storytopic=<{$topic.id}>"><{$topic.title}> <{$topic.news_count}></a>\r\n	<{/foreach}>\r\n    </td>\r\n</tr>\r\n</table>'),
(655, '<table>\r\n<tr>\r\n	<td>\r\n    	<ul>\r\n        <{foreach item=news from=$block.stories}>\r\n			<li>\r\n            <{if $block.sort==''counter''}>\r\n            	[<{$news.hits}>]\r\n            <{elseif $block.sort==''published''}>\r\n            	[<{$news.date}>]\r\n            <{else}>\r\n            	[<{$news.rating}>]\r\n            <{/if}>\r\n            <{$news.topic_title}> - <a href="<{$zarilia_url}>/addons/news/article.php?storyid=<{$news.id}>" <{$news.infotips}>><{$news.title}></a> <br /><{$news.teaser}></li>\r\n		<{/foreach}>\r\n        </ul>\r\n	</td>\r\n</tr>\r\n</table>'),
(656, '<h2><{$smarty.const._NW_NEWSARCHIVES}></h2>\r\n<ul>\r\n<{foreach item=onedate from=$block.archives}>\r\n<li>\r\n    <a href="<{$zarilia_url}>/addons/news/archive.php?year=<{$onedate.year}>&amp;month=<{$onedate.month}>"><{$onedate.formated_month}> <{$onedate.year}></a></li>\r\n</li>\r\n<{/foreach}>\r\n</ul>'),
(657, '<div><h4><{$smarty.const._MD_ADS_INDEXHEADER}></h4></div>\r\n<div><{$welcomeuser}></div>\r\n\r\n<h4 style="text-align:left;"><{$smarty.const._MD_ADS_CONTACTINFO}></h4>\r\n<table width="" cellpadding="2" cellspacing="1" class="outer" >\r\n <tr>\r\n  <td style="width: 50%;">\r\n   <div><strong><{$smarty.const._MD_ADS_CONTACT}>:</strong> <{$member.contact}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_EMAIL}>:</strong> <{$member.email}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_TELEPHONE}>:</strong> <{$member.telephone}></div> \r\n  </td>\r\n <td>\r\n   <div><strong><{$smarty.const._MD_ADS_ID}>:</strong> <{$member.cid}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_NAME}>:</strong> <{$member.name}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_ADDRESS}>:</strong> <{$member.address}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_CITY}>:</strong> <{$member.city}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_STATE}>:</strong> <{$member.state}></div>\r\n   <div><strong><{$smarty.const._MD_ADS_COUNTRY}>:</strong> <{$member.country}></div> \r\n   <div><strong><{$smarty.const._MD_ADS_ZIPCODE}>:</strong> <{$member.zipcode}></div> \r\n  </td>\r\n </tr> \r\n</table>\r\n\r\n<h4 style="text-align:left;"><{$smarty.const._MD_ADS_INDEXHEADER}></h4>\r\n<div><{$tabmenu}></div>\r\n<div><{$tlist}></div>'),
(658, '<table class="mess_block" width="100%" border="0" cellspacing="1" cellpadding="2">\r\n  <tr>\r\n    <td class="title_msg"><{$block.lang_title}></td>\r\n  </tr>\r\n  <tr>\r\n    <td>\r\n	 <div class="create_msg"><img src="<{$zarilia_image}>/pointer.gif" width="8" height="8" alt="" />&nbsp;&nbsp;<a href="<{$zarilia_url}>/addons/messages/message.php?op=create"><{$smarty.const._MB_MESSAGE_CREATE}></a></div>\r\n	 <ul class="circle">\r\n	  <li><a href="<{$zarilia_url}>/addons/messages/index.php?op=inbox"><{$smarty.const._MB_MESSAGE_INBOX}></a></li>\r\n	  <li><a href="<{$zarilia_url}>/addons/messages/index.php?op=sent"><{$smarty.const._MB_MESSAGE_SENT}></a></li>\r\n	  <li><a href="<{$zarilia_url}>/addons/messages/index.php?op=msaved"><{$smarty.const._MB_MESSAGE_SAVED}></a></li>\r\n	  <li><a href="<{$zarilia_url}>/addons/messages/index.php?op=trashed"><{$smarty.const._MB_MESSAGE_TRASH}></a></li>\r\n	</ul>\r\n	<div class="create_msg"><img src="<{$zarilia_image}>/pointer.gif" width="8" height="8" alt="" />&nbsp;&nbsp;<a href="<{$zarilia_url}>/addons/messages/message_func.php?op=delall"><{$smarty.const._MB_MESSAGE_DELETEMSG}></a></div>\r\n	<div class="create_msg"><img src="<{$zarilia_image}>/pointer.gif" width="8" height="8" alt="" />&nbsp;&nbsp;<a href="<{$zarilia_url}>/addons/messages/message_buddy.php?op=edit_buddy"><{$smarty.const._MB_MESSAGE_BUDDYADD}></a></div>\r\n	 <ul class="circle">\r\n	  <li><a href="<{$zarilia_url}>/addons/messages/message_buddy.php"><{$smarty.const._MB_MESSAGE_BUDDY}></a></li>\r\n	</ul>\r\n	</td>\r\n  </tr>\r\n</table>'),
(706, '<form id="userlogin" action="<{$zarilia_url}>/index.php" method="post">\r\n  <div class="name"><{$smarty.const._USERNAME}></div>\r\n  <div class="field"><input type="text" name="uname" size="30" value="<{$usercookie}>" /></div>\r\n  <div class="name"><{$smarty.const._PASSWORD}></div>\r\n  <div class="field"><input type="password" name="pass" size="30" value="" /></div>\r\n  <{if $showimage}>\r\n    <div class="name"><{$smarty.const._MB_SYSTEM_LOGINCHECK}></div>\r\n    <div class="field"><input type="text" style=''vertical-align: middle;'' name="verification" size="5" maxlength="32" />&nbsp;<{$verification_image}>\r\n	  	<input type="hidden" name="verification_ver" value="<{$verification_ver}>" /></div>\r\n  <{/if}>\r\n  <div class="checkrow"><input type="checkbox" style='' vertical-align: middle;'' name="rememberme" value="1"/> <{$smarty.const._US_REMEBERME}></div>\r\n  <div class="checkrow"><input type="checkbox" style='' vertical-align: middle;'' name="loginanon" value="1"/> <{$smarty.const._US_LOGINANON}></div>\r\n  <div class="field"><input type="submit" class="formbutton" value="<{$smarty.const._LOGIN}>" />\r\n  <input type="button" class="formbutton" onclick="window.location.href=''<{$zarilia_url}>?page_type=register'';" value="<{$smarty.const._MB_SYSTEM_RNOW}>" />\r\n  <input type="button" class="formbutton" onclick="window.location.href=''<{$zarilia_url}>?page_type=user&act=lostpass'';" value="<{$smarty.const._MB_SYSTEM_LPASS}>" />\r\n  </div>\r\n  \r\n  <input type="hidden" name="page_type" value="user" />\r\n  <input type="hidden" name="act" value="dologin" />\r\n  <{if $redirect_page}>\r\n   <input type="hidden" name="zarilia_redirect" value="<{$redirect_page}>" />\r\n  <{/if}>\r\n  <div class="warning"><{$smarty.const._US_BROWSERCOOKIES}></div>\r\n</form>'),
(765, '<table width="100%" cellspacing="0">\r\n  <tr>\r\n    <td id="usermenu">\r\n	  <!-- start usermenu menu loop -->\r\n		<{foreach item=usermenu from=$block.usermenu}>\r\n			<{if  $usermenu.link == 0 }>\r\n				<a class="menuMain" href="<{$usermenu.directory}>" <{$usermenu.target}>>\r\n			      <{if $usermenu.image != '''' }>\r\n				    <img src=''<{$zarilia_uploads}>/<{$usermenu.image}>'' valign=''middle'' height=''16'' width=''16'' alt=''<{$usermenu.name}>'' />&nbsp;\r\n				  <{/if}>\r\n				<{$usermenu.name}></a>\r\n			<{else}>\r\n				<a class="menuSub" href="<{$usermenu.directory}>" <{$usermenu.target}>>\r\n			      <{if $usermenu.image != '''' }>\r\n				    <img src=''<{$zarilia_uploads}>/<{$usermenu.image}>'' valign=''middle'' height=''16'' width=''16'' alt=''<{$usermenu.name}>'' />&nbsp;\r\n				  <{/if}>\r\n				<{$usermenu.name}></a>\r\n			<{/if}>\r\n		<{/foreach}>\r\n      <!-- end usermenu loop --> </td>\r\n  </tr>\r\n</table>'),
(766, '<form style="margin: 0px;" action="<{$zarilia_url}>" method="post">\r\n    <{$block.lang_username}><br />\r\n    <input type="text" name="login" size="12" value="<{$block.unamevalue}>" maxlength="25" /><br />\r\n    <{$block.lang_password}><br />\r\n    <input type="password" name="pass" size="12" maxlength="32" /><br />\r\n    <{if $block.showimage }>\r\n	 <{$block.lang_verification}><br />\r\n	 <input type="text" name="verification" size="5" maxlength="5" />&nbsp;<{$block.verification_image}><br />\r\n     <input type="hidden" name="verification_ver" value="<{$block.verification_ver}>" />\r\n	<{/if}>\r\n	<input type="checkbox" name="rememberme" value="1" /><{$block.lang_rememberme}><br />\r\n	<input type="checkbox" name="logonanon" value="1" /><{$block.lang_logonanon}><br />\r\n  	<{if $zarilia_requesturi}>\r\n   		<input type="hidden" name="zarilia_redirect" value="<{$zarilia_requesturi}>" />\r\n  	<{/if}>\r\n  	<input type="hidden" name="page_type" value="user" />\r\n  	<input type="hidden" name="act" value="dologin" />\r\n    <input type="submit" class="formbutton" value="<{$block.lang_login}>" /><br />\r\n    <{$block.sslloginlink}>\r\n</form>\r\n<div style="text-align: right;"><a href="<{$zarilia_url}>/index.php?page_type=user&act=lostpass"><{$block.lang_lostpass}></a></div>\r\n<{if $block.allow_register }>\r\n	<div style="text-align: right;"><a href="<{$zarilia_url}>/index.php?page_type=register"><{$block.lang_registernow}></a></div>\r\n<{/if}>'),
(767, '<form style="margin-top: 0px;" action="<{$zarilia_url}>/search.php" method="get">\r\n  <input type="text" name="query" size="14" /><input type="hidden" name="op" value="results" /><br /><input type="submit" class="formbutton" value="<{$block.lang_search}>" />\r\n</form>\r\n<a href="<{$zarilia_url}>/search.php"><{$block.lang_advsearch}></a>'),
(768, '<table width="100%" class="outer"><tr><td>\r\n<{foreach item=feed from=$block.feeds}>\r\n <table width="100%"><tr><td>\r\n	<a href="<{$feed.site_url}>" target="_blank"><{$feed.site_name}></a><br />\r\n	<{if $feed.image.url != ""}>\r\n	  <img src="<{$feed.image.url}>" width="<{$feed.image.width|default:88}>" height="<{$feed.image.height|default:31}>" alt="<{$feed.image.title}>" /><br />\r\n	<{/if}>\r\n	<{section name=i loop=$feed.items}>\r\n	  <{if $feed.items[i].title != ""}>\r\n	  <div><img src="<{$zarilia_url}>/images/icons/xml.gif" align="absmiddle" width="14" height="14" alt="" />&nbsp;<span style="text-indent: 20px;"><a href="<{$feed.items[i].link}>" target="_blank"><{$feed.items[i].title}></a></span></div>\r\n	  <{/if}>\r\n	<{/section}>\r\n </td></tr></table><br />\r\n<{/foreach}>\r\n</td></tr></table>'),
(769, '<table width="100%" cellspacing="0">\r\n  <tr>\r\n    <td id="mainmenu">\r\n	  <!-- start mainmenu menu loop -->\r\n		<{foreach item=mainmenu from=$block.mainmenu}>\r\n			<{if  $mainmenu.link == 0 }>\r\n				<a class="<{$mainmenu.style}>" href="<{$mainmenu.directory}>" <{$mainmenu.target}>>\r\n			      <{if $mainmenu.image != '''' }>\r\n				    <img src=''<{$zarilia_uploads}>/<{$mainmenu.image}>'' valign=''middle'' height=''16'' width=''16'' alt=''<{$mainmenu.name}>'' />&nbsp;\r\n				  <{/if}>\r\n				<{$mainmenu.name}></a>\r\n			<{else}>\r\n				<a class="<{$mainmenu.style}>" href="<{$mainmenu.directory}>" <{$mainmenu.target}>>\r\n			      <{if $mainmenu.image != '''' }>\r\n				    <img src=''<{$zarilia_uploads}>/<{$mainmenu.image}>'' valign=''middle'' height=''16'' width=''16'' alt=''<{$mainmenu.name}>'' />&nbsp;\r\n				  <{/if}>\r\n				<{$mainmenu.name}></a>\r\n			<{/if}>\r\n		<{/foreach}>\r\n      <!-- end mainmenu loop --> </td>\r\n  </tr>\r\n</table>'),
(770, '<table width="100%" cellspacing="0">\r\n  <{if $block.showgroups == true}>\r\n  <!-- start group loop -->\r\n  <{foreach item=group from=$block.groups}>\r\n  <tr>\r\n    <th colspan="2"><{$group.name}></th>\r\n  </tr>\r\n  <!-- start group member loop -->\r\n  <{foreach item=user from=$group.users}>\r\n  <tr>\r\n    <td class="even" valign="middle" align="center">\r\n	 <{if $user.avatar != ""}>\r\n	  <img src="<{$user.avatar}>" alt="" width="32" /><br />\r\n	 <{/if}>\r\n	 <a href="<{$zarilia_url}>/userinfo.php?uid=<{$user.id}>"><{$user.name}></a>\r\n	</td>\r\n	<td class="odd" width="20%" align="right" valign="middle"><{$user.msglink}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n  <!-- end group member loop -->\r\n  <{/foreach}>\r\n  <!-- end group loop -->\r\n  <{/if}>\r\n</table>\r\n<div class="footer" style="text-align: center;"><{$block.logourl}></div>\r\n<div class="footer" style="text-align: center;"><{$block.recommendlink}></div>'),
(771, '<{$block.online_total}><br /><br /><{$block.lang_members}>: <{$block.online_members}><br /><{$block.lang_guests}>: <{$block.online_guests}><br /><br /><{$block.online_names}> <a href="javascript:openWithSelfMain(''<{$zarilia_url}>/misc.php?type=online'',''Online'',420,350);"><{$block.lang_more}></a>'),
(772, '<table width="100%" cellspacing="0">\r\n  <{foreach item=user from=$block.users}>\r\n  <tr class="<{cycle values="even,odd"}>" valign="middle">\r\n    <td><{$user.rank}></td>\r\n    <td align="center">\r\n      <{if $user.avatar != ""}>\r\n      <img src="<{$user.avatar}>" alt="" width="32" /><br />\r\n      <{/if}>\r\n      <a href="<{$zarilia_url}>/userinfo.php?uid=<{$user.id}>"><{$user.name}></a>\r\n    </td>\r\n    <td align="center"><{$user.posts}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n</table>'),
(773, '<table width="100%" cellspacing="0">\r\n  <{foreach item=user from=$block.users}>\r\n    <tr class="<{cycle values="even,odd"}>" valign="middle">\r\n      <td align="center">\r\n      <{if $user.avatar != ""}>\r\n      <img src="<{$user.avatar}>" alt="" width="32" /><br />\r\n      <{/if}>\r\n      <a href="<{$zarilia_url}>/userinfo.php?uid=<{$user.id}>"><{$user.name}></a>\r\n      </td>\r\n      <td align="center"><{$user.joindate}></td>\r\n    </tr>\r\n  <{/foreach}>\r\n</table>'),
(774, '<table width="100%" cellspacing="0">\r\n  <{foreach item=comment from=$block.comments}>\r\n  <tr class="<{cycle values="even,odd"}>">\r\n    <td align="center"><img src="<{$zarilia_url}>/images/subject/<{$comment.icon}>" alt="" /></td>\r\n    <td><{$comment.title}></td>\r\n    <td align="center"><{$comment.addon}></td>\r\n    <td align="center"><{$comment.poster}></td>\r\n    <td align="right"><{$comment.time}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n</table>'),
(775, '<form action="<{$block.target_page}>" method="post">\r\n<table width="100%" cellspacing="0">\r\n  <{foreach item=category from=$block.categories}>\r\n  <{foreach name=inner item=event from=$category.events}>\r\n  <{if $smarty.foreach.inner.first}>\r\n  <tr>\r\n    <td class="head" colspan="2"><{$category.title}></td>\r\n  </tr>\r\n  <{/if}>\r\n  <tr>\r\n    <td class="odd"><{counter assign=index}><input type="hidden" name="not_list[<{$index}>][params]" value="<{$category.name}>,<{$category.itemid}>,<{$event.name}>" /><input type="checkbox" name="not_list[<{$index}>][status]" value="1" <{if $event.subscribed}>checked="checked"<{/if}> /></td>\r\n    <td class="odd"><{$event.caption}></td>\r\n  </tr>\r\n  <{/foreach}>\r\n  <{/foreach}>\r\n  <tr>\r\n    <td class="foot" colspan="2"><input type="hidden" name="not_redirect" value="<{$block.redirect_script}>"><input type="submit" class="formbutton" name="not_submit" value="<{$block.submit_button}>" /></td>\r\n  </tr>\r\n</table>\r\n</form>'),
(776, '<div style="text-align: center;">\r\n<form action="index.php" method="post">\r\n<{$block.theme_select}>\r\n</form>\r\n</div>'),
(777, '<div class="blockContent"><{$block.content}></div>'),
(778, '<script type="text/javascript" src="<{$block.path}>/ufo.js"></script>\r\n<p id="player2"><a href="http://www.macromedia.com/go/getflashplayer">Get the Flash Player</a> to see this player.</p>\r\n<script type="text/javascript">\r\n	var FU = { 	movie:"<{$block.path}>/mediaplayer.swf",width:"170",height:"300",majorversion:"7",build:"0",bgcolor:"#FFFFFF",\r\n				flashvars:"file=<{$block.path}>/includes/playlist.php&displayheight=175&repeat=true&lightcolor=0xCC9900&backcolor=0x000000&frontcolor=0xCCCCCC&overstretch=true" };\r\n	UFO.create(	FU, "player2");\r\n</script>'),
(787, '<h2><{$smarty.const._AM_NEWS_WHOS_WHO}></h2>\r\n<br />\r\n<br />\r\n<h3><{$smarty.const._NW_NEWS_LIST_OF_AUTHORS}></h3>\r\n<br />\r\n<ul>\r\n<{foreach item=who from=$whoswho}>\r\n	<li><a href="<{$zarilia_url}>/addons/news/newsbythisauthor.php?uid=<{$who.uid}>"><{$who.name}></a></li>\r\n<{/foreach}>\r\n</ul>'),
(788, '<h2><{$smarty.const._AM_NEWS_TOPICS_DIRECTORY}></h2>\r\n<br />\r\n<ul>\r\n<{foreach item=topic from=$topics}>\r\n	<li><{$topic.prefix}><a href="<{$zarilia_url}>/addons/news/index.php?storytopic=<{$topic.id}>"><{$topic.title}></a> (<{$topic.news_count}>)</li>\r\n<{/foreach}>\r\n</ul>');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_trash`
--

CREATE TABLE `cztsd_trash` (
  `trash_id` int(11) unsigned NOT NULL auto_increment,
  `trash_sid` int(11) unsigned NOT NULL default '0',
  `trash_cid` int(11) unsigned NOT NULL default '0',
  `trash_uid` int(11) unsigned NOT NULL default '0',
  `trash_alias` varchar(100) NOT NULL default '',
  `trash_created` int(11) unsigned NOT NULL default '0',
  `trash_published` int(11) unsigned NOT NULL default '0',
  `trash_updated` int(11) unsigned NOT NULL default '0',
  `trash_expired` int(11) unsigned NOT NULL default '0',
  `trash_title` varchar(100) NOT NULL default '',
  `trash_subtitle` varchar(100) NOT NULL default '',
  `trash_intro` text NOT NULL,
  `trash_body` mediumtext NOT NULL,
  `trash_images` text NOT NULL,
  `trash_summary` text NOT NULL,
  `trash_counter` int(11) NOT NULL default '0',
  `trash_type` varchar(10) NOT NULL default 'static',
  `trash_hits` int(11) NOT NULL default '0',
  `trash_version` decimal(3,2) NOT NULL default '0.00',
  `trash_approved` int(1) NOT NULL default '0',
  `trash_meta` text NOT NULL,
  `trash_keywords` text NOT NULL,
  `trash_weight` tinyint(5) NOT NULL default '0',
  `trash_display` tinyint(1) NOT NULL default '1',
  `trash_spotlight` tinyint(1) NOT NULL default '0',
  `trash_spotlightmain` tinyint(1) NOT NULL default '0',
  `trash_date` int(11) unsigned NOT NULL default '0',
  `trash_userid` int(11) unsigned NOT NULL default '0',
  `trash_mid` mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (`trash_id`),
  KEY `idx_sid` (`trash_sid`),
  KEY `idx_cid` (`trash_cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_trash`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_userprofile`
--

CREATE TABLE `cztsd_userprofile` (
  `userprofile_id` mediumint(8) unsigned NOT NULL auto_increment,
  `userprofile_uid` smallint(8) NOT NULL default '0',
  `userprofile_cid` smallint(5) NOT NULL default '0',
  `userprofile_value` text NOT NULL,
  `userprofile_pid` smallint(8) NOT NULL default '0',
  `userprofile_name` varchar(60) NOT NULL default '',
  `userprofile_weight` mediumint(8) NOT NULL default '0',
  PRIMARY KEY  (`userprofile_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_userprofile`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_users`
--

CREATE TABLE `cztsd_users` (
  `uid` mediumint(8) unsigned NOT NULL auto_increment,
  `login` varchar(25) NOT NULL default '',
  `name` varchar(60) NOT NULL default '',
  `uname` varchar(25) NOT NULL default '',
  `email` varchar(60) NOT NULL default '',
  `url` varchar(100) NOT NULL default '',
  `user_avatar` varchar(30) NOT NULL default '',
  `user_regdate` int(10) unsigned NOT NULL default '0',
  `user_from` varchar(100) NOT NULL default '',
  `user_sig` tinytext NOT NULL,
  `user_viewemail` tinyint(1) unsigned NOT NULL default '0',
  `actkey` varchar(8) NOT NULL default '',
  `pass` varchar(32) NOT NULL default '',
  `posts` mediumint(8) unsigned NOT NULL default '0',
  `attachsig` tinyint(1) unsigned NOT NULL default '0',
  `rank` smallint(5) unsigned NOT NULL default '0',
  `level` tinyint(3) unsigned NOT NULL default '1',
  `theme` varchar(100) NOT NULL default '',
  `timezone_offset` float(3,1) NOT NULL default '0.0',
  `last_login` int(10) unsigned NOT NULL default '0',
  `umode` varchar(10) NOT NULL default '',
  `uorder` tinyint(1) unsigned NOT NULL default '0',
  `notify_method` tinyint(1) NOT NULL default '1',
  `notify_mode` tinyint(1) NOT NULL default '0',
  `user_mailok` tinyint(1) unsigned NOT NULL default '1',
  `ipaddress` varchar(20) NOT NULL default '',
  `user_coppa_dob` int(11) NOT NULL default '0',
  `user_coppa_agree` tinyint(1) NOT NULL default '0',
  `user_language` varchar(100) NOT NULL default '',
  `editor` varchar(60) NOT NULL default '',
  `user_usrlevel` smallint(2) NOT NULL default '0',
  `user_usrmedpref` smallint(2) NOT NULL default '0',
  `user_cookie` varchar(32) NOT NULL default '',
  `user_anon` smallint(1) NOT NULL default '0',
  `DC` varchar(60) NOT NULL default '0',
  PRIMARY KEY  (`uid`),
  KEY `uname` (`uname`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=61 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_users`
--

INSERT INTO `cztsd_users` (`uid`, `login`, `name`, `uname`, `email`, `url`, `user_avatar`, `user_regdate`, `user_from`, `user_sig`, `user_viewemail`, `actkey`, `pass`, `posts`, `attachsig`, `rank`, `level`, `theme`, `timezone_offset`, `last_login`, `umode`, `uorder`, `notify_method`, `notify_mode`, `user_mailok`, `ipaddress`, `user_coppa_dob`, `user_coppa_agree`, `user_language`, `editor`, `user_usrlevel`, `user_usrmedpref`, `user_cookie`, `user_anon`, `DC`) VALUES
(1, 'admin', 'Real Site Admin', 'Administrator', 'zarilia@info', '', 'cavt4721dd426fa31.jpg', 1183095911, '', '', 1, '', 'WoKfmZap', 6, 0, 6, 1, 'default', 2.0, 1194867703, '', 0, 1, 0, 1, '127.0.0.1', 0, 1, 'english', 'textarea', 0, 0, '60d0d92f2b61cfa5cc8f8a1b713517bf', 0, '0');

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_users_seq`
--

CREATE TABLE `cztsd_users_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_users_seq`
--

INSERT INTO `cztsd_users_seq` (`id`) VALUES
(60);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_zariliacomments`
--

CREATE TABLE `cztsd_zariliacomments` (
  `com_id` mediumint(8) unsigned NOT NULL auto_increment,
  `com_pid` mediumint(8) unsigned NOT NULL default '0',
  `com_rootid` mediumint(8) unsigned NOT NULL default '0',
  `com_modid` smallint(5) unsigned NOT NULL default '0',
  `com_itemid` mediumint(8) unsigned NOT NULL default '0',
  `com_icon` varchar(25) NOT NULL default '',
  `com_created` int(10) unsigned NOT NULL default '0',
  `com_modified` int(10) unsigned NOT NULL default '0',
  `com_uid` mediumint(8) unsigned NOT NULL default '0',
  `com_ip` varchar(15) NOT NULL default '',
  `com_title` varchar(255) NOT NULL default '',
  `com_text` text NOT NULL,
  `com_sig` tinyint(1) unsigned NOT NULL default '0',
  `com_status` tinyint(1) unsigned NOT NULL default '0',
  `com_exparams` varchar(255) NOT NULL default '',
  `dohtml` tinyint(1) unsigned NOT NULL default '0',
  `dosmiley` tinyint(1) unsigned NOT NULL default '0',
  `doxcode` tinyint(1) unsigned NOT NULL default '0',
  `doimage` tinyint(1) unsigned NOT NULL default '0',
  `dobr` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`com_id`),
  KEY `com_pid` (`com_pid`),
  KEY `com_itemid` (`com_itemid`),
  KEY `com_uid` (`com_uid`),
  KEY `com_title` (`com_title`(40))
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_zariliacomments`
--


-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_zariliacomments_seq`
--

CREATE TABLE `cztsd_zariliacomments_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_zariliacomments_seq`
--

INSERT INTO `cztsd_zariliacomments_seq` (`id`) VALUES
(7);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_zarilianotifications`
--

CREATE TABLE `cztsd_zarilianotifications` (
  `not_id` mediumint(8) unsigned NOT NULL auto_increment,
  `not_modid` smallint(5) unsigned NOT NULL default '0',
  `not_itemid` mediumint(8) unsigned NOT NULL default '0',
  `not_category` varchar(30) NOT NULL default '',
  `not_event` varchar(30) NOT NULL default '',
  `not_uid` mediumint(8) unsigned NOT NULL default '0',
  `not_mode` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`not_id`),
  KEY `not_modid` (`not_modid`),
  KEY `not_itemid` (`not_itemid`),
  KEY `not_class` (`not_category`),
  KEY `not_uid` (`not_uid`),
  KEY `not_event` (`not_event`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Sukurta duomenų kopija lentelei `cztsd_zarilianotifications`
--

INSERT INTO `cztsd_zarilianotifications` (`not_id`, `not_modid`, `not_itemid`, `not_category`, `not_event`, `not_uid`, `not_mode`) VALUES
(1, 7, 0, 'story', 'approve', 1, 1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `cztsd_zarilianotifications_seq`
--

CREATE TABLE `cztsd_zarilianotifications_seq` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `cztsd_zarilianotifications_seq`
--

INSERT INTO `cztsd_zarilianotifications_seq` (`id`) VALUES
(1);

-- --------------------------------------------------------

--
-- Sukurta duomenų struktūra lentelei `tpltpl_file_id_seq`
--

CREATE TABLE `tpltpl_file_id_seq` (
  `id` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Sukurta duomenų kopija lentelei `tpltpl_file_id_seq`
--

INSERT INTO `tpltpl_file_id_seq` (`id`) VALUES
(788);
